/**
 * $Id: SystemFixture.java 1066 2010-04-10 16:26:09Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.fixture;

import  java.lang.reflect.Method;
import  java.lang.reflect.UndeclaredThrowableException;
import  java.util.ArrayList;
import  java.util.Arrays;
import  java.util.Collections;
import  java.util.HashMap;
import  java.util.Hashtable;
import  java.util.LinkedList;
import  java.util.List;
import  java.util.Map;
import  java.util.Properties;
import  java.util.Vector;

/**
 * Facade to a set of global application fixture functions. The global
 * functions include:<ul>
 *   <li>Access to overlaid system properties</li>
 *   <li>Interface based factories for common Java collection types</li>
 *   <li>More memory-efficient StringBuffer constructors</li>
 * </ul>
 * First SystemFixture is a decorator for the System properties that
 * lets you override, and add properties without actually changing the
 * real System properties. Of course you must write your application to
 * use this class <em>instead of</em> System.[get|set]Property to
 * realize the benefits. Note that you cannot 'remove' a system property
 * using this class; however, you can set an existing property's value
 * to <i>null</i> which, in most cases, is effectively the same as removal.
 * <p/>
 * There is a single system fixture per VM classloader to mimic the 
 * singleton-ness of the system properties. All property methods are 
 * static. Typically a harness (or equivalent application bootstrap) 
 * mechanism would preload the overlaid properties into the system fixture.
 * <p/>
 * Next SystemFixture defines a collection of JWare-standard factory
 * methods for common Java data structures like Maps, Lists, and StringBuffers.
 * SystemFixture facilitates "interface-only" dependency in JWare classes.
 * Also, the JWare implementation codifies its synchronization requirements
 * explicitly by using either the regular unsynchronized factory method or
 * the synchronized variant.
 *
 * @since    JWare/internal 2.0
 * @author   ssmc, &copy;2004,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,helper
 * @see      FixtureProperties
 **/

public class SystemFixture
{
    /**
     * The VM classloader based singleton. Created on class load.
     * To be used by all static methods.
     **/
    static final SystemFixture INSTANCE = new SystemFixture();



    /**
     * Extension allowed for application-specific fixture
     * variants. Typical extensions will load up overrides based
     * on their own configuration requirements.
     **/
    protected SystemFixture()
    {
    }



    /**
     * Returns value of a named fixture property. Returns
     * <i>null</i> if property does not exist or cannot be read.
     * By default fixture properties are the same as
     * <span class="src">System</span> properties; subclasses
     * can extend or restrict this behavior.
     * @param name property name (non-null)
     **/
    public static String getProperty(String name)
    {
        return INSTANCE.properties.getProperty(name);
    }



    /**
     * Returns value of a named fixture property or a default
     * if no such property. By default fixture properties are
     * the same as <span class="src">System</span> properties.
     * @param name property name (non-null)
     * @param dfltResult default to return if no such property
     **/
    public static String getProperty(String name, String dfltResult)
    {
        return INSTANCE.properties.getProperty(name,dfltResult);
    }



    /**
     * Defines a named fixture property. <i>Null</i> values
     * are accepted and effectively block System properties of
     * the same name.
     * @param name property name (non-null)
     * @param value property value or <i>null</i>
     **/
    public static void setProperty(String name, String value)
    {
        INSTANCE.properties.setProperty(name,value);
    }



    /**
     * Undefines a named fixture property. This method will
     * remove a local fixture property that can hide a System
     * property of the same name.
     * @param name property name (non-null)
     **/
    public static void unsetProperty(String name)
    {
        INSTANCE.properties.remove(name);
    }



    /**
     * Undefines <em>ALL</em> local fixture overrides. On return
     * this fixture is equivalent to the System properties only.
     **/
    public static void unsetProperties()
    {
        INSTANCE.properties.clear();
    }



    /**
     * Returns an independent copy of base fixture's and
     * system properties. System properties are copied so
     * subsequent changes are <em>not</em> reflected in
     * returned properties. Never returns <i>null</i>. Useful for
     * capturing snapshots of environment.
     * @.caveat This returns a Properties object that wipes away
     *          the security checks that System would perform on
     *          each property's retrieval.
     **/
    public static Properties copyOfProperties()
    {
        Properties copy = new Properties((Properties)System.getProperties().clone());
        copy.putAll(INSTANCE.properties);
        return copy;
    }



    /**
     * Collection of overlaid fixture properties. Applications can
     * install, at bootstrap time, their own sets of System
     * property overrides without ever touching System properties.
     * Useful mechanims for test environments.
     **/
    final FixtureProperties properties= new FixtureProperties();




    /**
     * Attempts to return a clone of the incoming object by uding
     * the incoming object's own <span class="src">clone()</span> method.
     * Incoming object <em>must</em> implement the
     * <span class="src">Cloneable</span> interface at very least.
     * @param original original object to be cloned (non-null)
     * @throws UndeclaredThrowableException if unable to clone object.
     * @throws IllegalArgumentException if original object is
     *         <i>null</i> or not Cloneable.
     **/
    public static final Object newCopy(Object original)
    {
        if (!(original instanceof Cloneable)) {
            String classname= "null";
            if (original!=null) {
                classname = original.getClass().getName();
            }
            throw new IllegalArgumentException("Not cloneable:"+classname);
        }
        try {
            Method m = original.getClass().getMethod("clone", (Class[])null);
            return m.invoke(original,(Object[])null);
        } catch(Exception anyX) {
            throw new UndeclaredThrowableException(anyX);
        }
    }



    /**
     * Returns a new unsynchronized list backed by a standard Java array.
     * @param jlist the Java array (non-null)
     **/
    public static final List newList(Object[] jlist)
    {
        return Arrays.asList(jlist);
    }



    /**
     * Returns a new synchronized list backed by a standard Java
     * array.
     * @param jlist the Java array (non-null)
     **/
    public static final List newSynchronizedList(Object[] jlist)
    {
        return Collections.synchronizedList(Arrays.asList(jlist));
    }



    /**
     * Returns a new unsynchronized list of default initial capacity (10).
     **/
    public static final List newList()
    {
        return new ArrayList();
    }



    /**
     * Returns a new unsynchronized list of certain initial capacity.
     * @param initialCapacity list's initial capacity (gte 0)
     **/
    public static final List newList(int initialCapacity)
    {
        return new ArrayList(initialCapacity);
    }



    /**
     * Returns a new synchronized list of default initial capacity.
     **/
    public static final List newSynchronizedList()
    {
        return new Vector();
    }



    /**
     * Returns a new synchronized list of certain initial capacity.
     * @param initialCapacity list's initial capacity (gte 0)
     **/
    public static final List newSynchronizedList(int initialCapacity)
    {
        return new Vector(initialCapacity);
    }



    /**
     * Returns a new unsynchronized linked-list.
     **/
    public static final List newLinkedList()
    {
        return new LinkedList();
    }



    /**
     * Returns a new synchronized linked-list. Note that the returned
     * item may not be a direct <span class="src">LinkedList</span>
     * implementation.
     **/
    public static final List newSynchronizedLinkedList()
    {
        return Collections.synchronizedList(new LinkedList());
    }



    /**
     * Returns a clone of an existing list. This method expects the
     * incoming list to be <span class="src">Cloneable</span> and
     * support a public "<span class="src">clone()</span>" method.
     * @param list list to be cloned
     * @.safety special, this method is as safe as the original's method
     * @throws IllegalArgumentException if object is not Cloneable
     * @throws UndeclaredThrowableException for any other problem
     **/
    public static final List newListCopy(List list)
    {
        try {
            return (List)newCopy(list);
        } catch(IllegalArgumentException ix) {
        } catch(UndeclaredThrowableException cx) {
        }
        return new ArrayList(list);
    }



    /**
     * Returns a new unsynchronized map of default initial capacity
     * and load factor.
     **/
    public static final Map newMap()
    {
        return new HashMap();
    }



    /**
     * Returns a new unsynchronized map of certain initial capacity
     * and load factor.
     * @param initialCapacity map's initial capacity (gte 0)
     * @param loadFactor map's load factor
     **/
    public static final Map newMap(int initialCapacity, float loadFactor)
    {
        return new HashMap(initialCapacity, loadFactor);
    }



    /**
     * Returns a new synchronized map of default initial capacity
     * and load factor.
     **/
    public static final Map newSynchronizedMap()
    {
        return new Hashtable();
    }



    /**
     * Returns a new synchronized map of certain initial capacity
     * and load factor.
     * @param initialCapacity map's initial capacity (gte 0)
     * @param loadFactor map's load factor
     **/
    public static final Map newSynchronizedMap(int initialCapacity,
                                               float loadFactor)
    {
        return new Hashtable(initialCapacity, loadFactor);
    }



    /**
     * Returns a clone of an existing map. This method expects the
     * incoming map to be <span class="src">Cloneable</span> and
     * support a public "<span class="src">clone()</span>" method.
     * @param map existing, cloneable map (non-null)
     * @.safety special, this method is as safe as the original's method
     * @throws IllegalArgumentException if object is not Cloneable
     * @throws UndeclaredThrowableException for any other problem
     **/
    public static final Map newMapCopy(Map map)
    {
        try {
            return (Map)newCopy(map);
        } catch(IllegalArgumentException ix) {
        } catch(UndeclaredThrowableException cx) {
        }
        return new HashMap(map);
    }



    /**
     * Returns a new JWare-standard sized string buffer. The
     * returned buffer has a capacity of at least 40 characters.
     **/
    public static final StringBuffer newSmallStringBuffer()
    {
        return new StringBuffer(40);
    }



    /**
     * Returns a new JWare-standard sized string buffer. The
     * returned buffer has a capacity of at least 120 characters.
     **/
    public static final StringBuffer newStringBuffer()
    {
        return new StringBuffer(150);
    }



    /**
     * Returns a new large sized string buffer. The returned
     * buffer has a capacity of at least 512 characters.
     **/
    public static final StringBuffer newLargeStringBuffer()
    {
        return new StringBuffer(512);
    }



    /**
     * Write to standard "output" stream when <em>no other alternative
     * is available</em>. This is here only for truly bootstrapped classes
     * that can be used by projects outside the typical application
     * space (for example Ant-based projects).
     * @param lbl the marker label (like 'ALERT' or 'INFO')
     * @param msg the actual message (non-null)
     **/
    public static final void putout(String lbl, Object msg)
    {
        System.out.println(lbl+msg);
    }



    /**
     * Write to standard "error" stream when <em>no other alternative
     * is available</em>. This is here only for truly bootstrapped classes
     * that can be used by projects outside the typical application
     * space (for example Ant-based projects).
     * @param lbl the marker label (like 'ERROR' or 'FATAL')
     * @param msg the actual message (non-null)
     **/
    public static final void puterr(String lbl, Object msg)
    {
        System.err.println(lbl+msg);
    }
}

/* end-of-SystemFixture.java */
