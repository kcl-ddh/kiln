/**
 * $Id: UnmodifiableProperties.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.helpers;

import  java.io.InputStream;
import  java.util.Map;
import  java.util.Properties;

/**
 * Unmodifiable marker for a Properties object. This is not an empty properties object-- it
 * does not permit any form of modification.
 *
 * @since     JWare/internal 2.0
 * @author    ssmc, &copy;2007-2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    impl,helper
 **/

public class UnmodifiableProperties extends Properties
{
    public UnmodifiableProperties() {
    }

    public boolean isEmpty() {
        return true;
    }

    public Object setProperty(String key, String value) {
        throw new UnsupportedOperationException();
    }

    public void load(InputStream inStream) {
        throw new UnsupportedOperationException();
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public Object put(Object key, Object object) {
        throw new UnsupportedOperationException();
    }

    public void putAll(Map t) {
        throw new UnsupportedOperationException();
    }

    public Object remove(Object key) {
        throw new UnsupportedOperationException();
    }
}

/* end-of-UnmodifiableProperties.java */
