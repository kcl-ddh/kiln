/**
 * $Id: NothingIterator.java 390 2008-03-30 17:51:32Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

import  java.util.Enumeration;
import  java.util.NoSuchElementException;

/**
 * Iterator that iterates nothing&#150; <span class="src">hasNext()</span> is always
 * <i>false</i>. A NothingIterator instance can be used as an MT-safe singleton.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;1997-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,helper
 **/

public class NothingIterator extends NoRemoveIteratorSkeleton
    implements Enumeration
{
    /**
     * VM/ClassLoader-shareable singleton.
     **/
    public static final NothingIterator INSTANCE= new NothingIterator();


    /**
     * Creates new nothing iterator object to iterate nothing.
     **/
    public NothingIterator()
    {
    }



    /**
     * Nothing to return; always throws a
     * <span class="src">NoSuchElementException</span> exception.
     **/
    public Object next()
    {
        throw new NoSuchElementException();
    }


    /**
     * Nothing to return; always throws a
     * <span class="src">NoSuchElementException</span> exception.
     **/
    public Object nextElement()
    {
        throw new NoSuchElementException();
    }


    /**
     * Nothing to return; always returns <i>false</i>.
     **/
    public boolean hasMoreElements()
    {
        return false;
    }


    /**
     * Nothing to return; always returns <i>false</i>.
     **/
    public boolean hasNext()
    {
        return false;
    }
}

/* end-of-NothingIterator.java */
