/**
 * $Id: CollectionFunctionShortcutSkeleton.java 944 2010-01-05 01:11:59Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.collection;

import  java.util.Iterator;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Starter class for handlers that manipulate common collection types
 * like lists and maps. Provides support for a common set of operation
 * selectors and uri fragment parsing.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 **/

abstract class CollectionFunctionShortcutSkeleton extends FunctionShortcutSkeleton
{
    static final int UNKNOWN=-1;
    static final int SIZE=UNKNOWN+1;
    static final int KEYSET=SIZE+1;
    static final int VALUES=KEYSET+1;
    static final int LOOKUP=VALUES+1;
    static final int DUMP=LOOKUP+1;
    static final int CONCAT=DUMP+1;
    static final int ISEMPTY=CONCAT+1;


    /**
     * Initializes a new collection examiner function shortcut.
     **/
    protected CollectionFunctionShortcutSkeleton()
    {
        super();
    }


    /**
     * Returns the default operation if one is not set explicitly.
     * Will use "DUMP" by default.
     **/
    int getDefaultOp()
    {
        return DUMP;
    }



    /**
     * Extracts the bit of collection information requested. Currently
     * supports four special operations: dump (also default if no
     * fragment), keyset, values, and size.
     */
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        final Project P = clnt.getProject();

        String refid = uriFragment;
        int op = getDefaultOp();
        String key = null;
        String arg2 = null;

        int i = uriFragment.lastIndexOf(SCHEME_DELIMITER);
        if (i>=0) {
            refid = uriFragment.substring(0,i++);
            if (i<uriFragment.length()) {
                String instr = Tk.resolveString(P,uriFragment.substring(i),true);
                int j = instr.lastIndexOf(PARAMS_DELIMITER);
                if (j>=0) {
                    arg2  = instr.substring(j+2);
                    instr = instr.substring(0,j);
                }
                op = opFrom(instr);
                if (op==LOOKUP) {
                    key = instr;
                }
            }
        }
        refid = Tk.resolveString(P,refid,true);
        return valueFromTyped(refid,op,arg2,key,clnt);
    }



    /**
     * Does query work that is specific to the particular collection or
     * map that is being handled.
     * @param refid extracted (normalized) reference id (or inline collection)
     * @param op the determined operation from original URI fragment
     * @param arg2 the client-supplied 2nd arg or <i>null</i> if none in URI
     * @param key the client-supplied "key" or <i>null</i> if none in URI
     * @param clnt call controls (non-null
     * @return the handler's results or <i>null</i> if cannot determine.
     **/
    abstract String valueFromTyped(String refid, int op, String arg2, String key,
        Requester clnt);



    /**
     * Determine the requested collection operation for the handler.
     * @param opstring incoming operation or key value (non-null)
     * @return operation id
     **/
    int opFrom(String opstring)
    {
        if ("size".equals(opstring) || "len".equals(opstring)) {
            return SIZE;
        }
        if ("keys".equals(opstring)) {
            return KEYSET;
        }
        if ("values".equals(opstring)) {
            return VALUES;
        }
        if ("empty".equals(opstring) || "isempty".equals(opstring)) {
            return ISEMPTY;
        }
        if ("dump".equals(opstring)) {
            return DUMP;
        }
        if ("add".equals(opstring) || "concat".equals(opstring)) {
            return CONCAT;
        }
        return opstring.length()>0 ? LOOKUP : getDefaultOp();
    }



    /**
     * Generates a listing string of the items returned by
     * the given iterator. The listing elements are delimited
     * by the incoming marker string.
     * @param itr iterator that returns listing elements (non-null)
     * @param delim delimiter used between elements (non-null)
     * @return listing string (never <i>null</i>)
     **/
    final String listFrom(Iterator itr, String delim)
    {
        StringBuffer sb = new StringBuffer(100);
        int i=0;
        while (itr.hasNext()) {
            if (i>0) {
                sb.append(delim);
            }
            sb.append(itr.next());
            i++;
        }
        return sb.toString();
    }



    /**
     * Return second argument interpreted to be a delimiter.
     * @param arg2 [optional] second argument as passed via uri fragment
     * @return delimiter value (never <i>null</i>)
     **/
    final String delimFrom(String arg2)
    {
        String delim = arg2;
        if (arg2==null) {
            delim = AntX.DEFAULT_DELIMITER;
        } else if ("\\n".equals(delim)) {
            delim= Strings.NL;
        }
        return delim;
    }
}

/* end-of-CollectionFunctionShortcutSkeleton.java */