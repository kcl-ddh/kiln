/**
 * $Id: ProjectPropertiesNet.java 983 2010-02-27 12:43:10Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.ownhelpers;

import  java.util.Collections;
import  java.util.Hashtable;
import  java.util.Iterator;
import  java.util.Map;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.MagicNames;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.PropertyHelper;
import  org.apache.tools.ant.property.LocalProperties;
import  org.apache.tools.ant.property.NullReturn;

import  org.jwaresoftware.antxtras.behaviors.Nameable;
import  org.jwaresoftware.antxtras.behaviors.ProjectDependent;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;

/**
 * A <span class="src">ProjectPropertiesNet</span> is usually installed for a
 * well-defined "execution bubble" to block scoped changes from affecting the
 * caller's environment.
 * <p>
 * A ProjectPropertiesNet's name and project should be set once by the 
 * controlling task as these methods are not guarded against concurrent 
 * use and/or modification.
 *
 * @since     JWare/AntX 0.4
 * @author    ssmc, &copy;2004,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   guarded (client APIs only)
 * @.group    impl,helper
 * @.pattern  GoF.Proxy
 * @.caveat   This PropertyHelper extension must be installed by the
 *            controlling task.
 * @.caveat   As of Ant 1.8 custom PropertyHelper extensions are 
 *            <em>not</em> propagated to child projects.
 * @.caveat   Properties provided by any overlaid tasksets are not
 *            included in returned property sets (like {@linkplain #getProperties}).
 * @.impl     This net must be workable with our own {@linkplain ScopedProperties}!
 * @.impl     Direct access to project references map is intentional to avoid
 *            the spurious warnings about replaced references.
 **/

public final class ProjectPropertiesNet extends PropertyHelper
    implements ProjectDependent, Nameable
{
    private static final String IAM_ = AntX.utilities+"PropertiesNet";


    /**
     * Initializes a new properties net. This net's project
     * must be defined before it is installed.
     **/
    public ProjectPropertiesNet()
    {
        super();
    }



    /**
     * Initializes and installs a new properties net.
     * @param name [optional] this net's script-facing label
     * @param project associated project (non-null)
     * @throws IllegalStateException if this net is not associated
     *         with a project.
     **/
    public ProjectPropertiesNet(String name, Project project)
    {
        super();
        setProject(project);
        if (name!=null) {
            setName(name);
        }
        install(project);
    }



    /**
     * Set this net's initial set of overlayed properties en-masse.
     * This method should be called <em>before</em> this net is installed.
     * Net assumes ownership of incoming properties map. Like any property,
     * empty seeded values are writable once.
     * @param properties initial collection of property values (non-null)
     * @param control <i>true</i> if these are control properties (readonly implied)
     * @param readonly <i>true</i> if these should be immutable properties
     * @since JWare/AntX 0.5
     * @.safety single
     **/
    public void seedProperties(Map properties, boolean control, boolean readonly)
    {
        AntX.require_(properties!=null,IAM_,"seed- nonzro property set");
        if (!properties.isEmpty()) {
            if (control) {
                getInternalInheritedProperties().putAll(properties);
                getInternalUserProperties().putAll(properties);
            } else if (readonly) {
                getInternalUserProperties().putAll(properties);
            } else {
                Iterator itr= properties.entrySet().iterator();
                while (itr.hasNext()) {
                    Map.Entry e = (Map.Entry)itr.next();
                    String value = (String)e.getValue();
                    if (value==null || value.length()==0) {
                        e.setValue(EMPTY);
                    }
                }
                m_rwProperties = properties;
            }
            getInternalProperties().putAll(properties);
        }
    }



    /**
     * Associates this net with a project. This net still has
     * to be {@linkplain #install(Project) installed} explicitly.
     * @.safety single
     **/
    public void setProject(Project project)
    {
        super.setProject(project);
        m_project = project;
    }



    /**
     * Returns the project with which this net associated.
     * Can return <i>null</i> if not linked to any project.
     * @.safety single
     **/
    public Project getProject()
    {
        return m_project;
    }



    /**
     * Initializes this net's diagnostics-friendly name.
     * @param name net's name (non-null)
     * @.safety single
     **/
    public final void setName(String name)
    {
        AntX.require_(name!=null,IAM_,"setName- nonzro name");
        m_nameImpl = name;
    }



    /**
     * Returns this net's diagnostics label. Will return
     * "undefined" if never set explicitly.
     * @.safety single
     */
    public final String getName()
    {
        return m_nameImpl;
    }



    /**
     * Returns the helper that was original replaced by this 
     * one. Never returns <i>null</i> <em>when installed</em>.
     * @since JWare/AntXtras 3.0.0
     **/
    protected PropertyHelper getReplacedHelper()
    {
        return m_realPH;
    }



    /**
     * Ensure this net is not already installed as the given project's
     * property helper. Prevents infinite (circular) lookups.
     **/
    private void verifyNotInstalled(PropertyHelper ph, Project P)
    {
        AntX.verify_(ph!=null,IAM_,"install- Ant env inited");
        if (ph==this) {
            String error = AntX.uistrs().get("fixture.ph.install.once",getName());
            P.log(error,Project.MSG_ERR);
            throw new BuildException(error);
       }
    }



    /**
     * Installs this net as the given project's property helper.
     * @param project this net's associated project
     * @return <i>true</i> if net installed first time
     * @.safety single
     * @return <i>false</i> if already installed directly or indirectly
     **/
    public boolean install(Project project)
    {
        AntX.require_(project!=null,IAM_,"install- nonzro project");
        setProject(project);
        PropertyHelper current = PropertyHelper.getPropertyHelper(project);

        verifyNotInstalled(current,project);
        copyLocalsTracker();

        log("Installing...",Project.MSG_VERBOSE);        
        m_realPH = current;
        project.getReferences().put(MagicNames.REFID_PROPERTY_HELPER,this);

        AntX.verify_(PropertyHelper.getPropertyHelper(project)==this,
                     IAM_,"install- installed properly");
        return true;
    }



    /**
     * Uninstalls this net as its project's property helper.
     * Will reinstall the helper that was there when this net
     * was installed.
     * @param calr controlling component (non-null)
     * @throws BuildException if this net is not currently installed
     **/
    public void uninstall(Requester calr)
    {
        Project P = getProjectNoNull();
        PropertyHelper current = PropertyHelper.getPropertyHelper(P);
        if (current==this) {
            log("Uninstalling...",Project.MSG_VERBOSE);
            P.getReferences().put(MagicNames.REFID_PROPERTY_HELPER,m_realPH);
            m_realPH = null;
        } else if (current!=null) {
            String error = AntX.uistrs().get("fixture.ph.not.instald",getName());
            if (calr!=null) {
                calr.problem(error,Project.MSG_ERR);
            }
            throw new BuildException(error,calr.getLocation());
        }
    }



    /**
     * Installs a property definition if it isn't already installed from
     * the command or control context. Emulates the ordering of 'set' as
     * defined by the standard helper circa Ant 1&#46;8.
     * @.impl Because the standard helper calls installed setters ALWAYS
     *        first, we do this. However this might cause a "leak" as it's
     *        possible for an inner isolation bubble to allow a outer
     *        overlay to be updated (for instance).
     **/
    public boolean setProperty(String name, Object value, boolean verbose)
    {
        AntX.require_(name!=null,IAM_,"setProperty- nonzro name");
        boolean written = false;

        for (Iterator itr = getDelegates(PropertySetter.class).iterator(); itr.hasNext();) {
            PropertySetter setter = (PropertySetter) itr.next();
            if (setter.set(name, value, this)) {
                log("Set local hook property '"+name+
                    "' -> "+value, Project.MSG_DEBUG);
                written = true;
                break;
            }
        }
        if (!written) {
            synchronized(this) {
                if (getUserProperty0(name)==null) {
                    Object old = getInternalProperties().put(name,value);
                    if (old!=null && old!=EMPTY) {
                        log("Overwrote script property '"+name+"'");
                    }
                    else {
                        log("Set script property '"+name+
                            "' -> "+value, Project.MSG_DEBUG);
                    }
                    written = true;
                } else if (verbose) {
                    log("Ignored script definition of '"+name+"'");
                }
            }//lock-me
        }
        return written;
    }



    /**
     * Installs a new property iff it is not already defined in
     * any context. Never installs new properties to local hooks.
     **/
    public void setNewProperty(String name, Object value)
    {
        for (Iterator itr = getDelegates(PropertySetter.class).iterator(); itr.hasNext();) {
            PropertySetter setter = (PropertySetter) itr.next();
            if (setter.setNew(name, value, this)) {
                log("Set local hook NEW property '"+name+
                        "' -> "+value, Project.MSG_DEBUG);
                return;
            }
        }
        synchronized(this) {
            if (getProperty0(name)!=null) {
                log("Ignored new script definition of '"+name+"'");
            } else {
                getInternalProperties().put(name,value);
                log("Set script property '"+name+"' -> "+value,
                    Project.MSG_DEBUG);
            }
        }//lock-me
    }



    private Object readLocalFuncut(String name)
    {
        Project p = getProjectNoNull();
        if (FixtureExaminer.functionShortcutInterpreterInstalled(p)) {
            return null;
        }
        return FixtureExaminer.findValue(p,name,null);
    }



    /**
     * Return a property's definition from any context. Will
     * return <i>null</i> if item undefined <em>or</em>
     * cleared.
     */
    public synchronized Object getProperty(String name)
    {
        if (name==null) {
            return null;
        }
        for (Iterator itr=getDelegates(PropertyEvaluator.class).iterator(); itr.hasNext();) {
            Object o = ((PropertyEvaluator) itr.next()).evaluate(name,this);
            if (o!=null) {
                if (o instanceof NullReturn) {
                    o = null;
                }
                return o;
            }
        }
        Object o = readLocalFuncut(name);
        return o==null ? getProperty0(name) : o;
    }



    /**
     * Returns a command or control property's definition. Will
     * return <i>null</i> if item undefined <em>or</em> cleared.
     */
    public synchronized Object getUserProperty(String name)
    {
        return getUserProperty0(name);
    }



    /**
     * Returns a copy of this net's full collection of
     * properties. Never returns <i>null</i>.
     */
    public synchronized Hashtable getProperties()
    {
        Hashtable copy = m_realPH.getProperties();
        copy.putAll(getInternalProperties());
        return copy;
    }



    /**
     * Returns a copy of this net's command and control
     * properties. Never returns <i>null</i>.
     */
    public synchronized Hashtable getUserProperties()
    {
        Hashtable copy = m_realPH.getUserProperties();
        copy.putAll(getInternalUserProperties());
        return copy;
    }



    /**
     * Copies this net's control properties to another project.
     */
    public synchronized void copyInheritedProperties(Project other)
    {
        AntX.require_(other!=getProject(),IAM_,"copyInherited- not same");

        if (!getInternalInheritedProperties().isEmpty()) {
            Iterator itr = getInternalInheritedProperties().entrySet().iterator();
            while (itr.hasNext()) {
                Map.Entry mE = (Map.Entry)itr.next();
                String key = (String)mE.getKey();
                if (other.getUserProperty(key)==null) {
                    other.setInheritedProperty(key,(String)mE.getValue());
                }
            }
        }
        m_realPH.copyInheritedProperties(other);//NB: won't override ours!
    }



    /**
     * Copies this net's non-inherited command properties to
     * another project.
     */
    public synchronized void copyUserProperties(Project other)
    {
        m_realPH.copyUserProperties(other);
        Iterator itr= getInternalUserProperties().entrySet().iterator();
        Map controlProperties = getInternalInheritedProperties();
        while (itr.hasNext()) {
            Map.Entry mE= (Map.Entry)itr.next();
            if (!controlProperties.containsKey(mE.getKey())) {
                other.setUserProperty((String)mE.getKey(),(String)mE.getValue());
            }
        }
    }



    /**
     * Returns a a copy of the properties captured by this
     * net. Should be used <em>after</em> this net is uninstalled.
     * @param filtered <i>true</i> if results should be filtered
     *    using seed values
     * @param blocking <i>true</i> if the seed values should
     *    be removed; otherwise only seed values are returned.
     * @since JWare/AntX 0.5
     * @return final (optionally filtered) properties (non-null)
     **/
    public Map getFinalProperties(boolean filtered, boolean blocking)
    {
        Hashtable ht = new Hashtable(getInternalProperties());
        if (filtered) {
            if (blocking) {
                ht.keySet().removeAll(m_rwProperties.keySet());
            } else {
                ht.keySet().retainAll(m_rwProperties.keySet());
                Iterator itr= ht.values().iterator();
                while (itr.hasNext()) {
                    if (itr.next()==EMPTY) {
                        itr.remove();
                    }
                }
            }
        }
        return ht;
    }


    /**
     * Returns <i>true</i> if given string contains unresolved
     * property references. Passed through to pre-existing PH.
     * @since JWare/AntXtras 3.0.0
     */
    public boolean containsProperties(String value) 
    {
        return getReplacedHelper().containsProperties(value);
    }



    /**
     * Resolves all property references in given string and 
     * returns final output (or same input if no references found).
     * Passed through to pre-existing PH.
     * @since JWare/AntXtras 3.0.0
     */
    public Object parseProperties(String value)
    {
        return getReplacedHelper().parseProperties(value);
    }



    /**
     * Returns this net's project ensuring that value has been
     * defined.
     * @throws IllegalStateException if this net has no project
     */
    private Project getProjectNoNull()
    {
        Project P = getProject();
        AntX.verify_(P!=null,IAM_,"getProj- inited");
        return P;
    }


    /**
     * Internal command property getter. Synchronization must be
     * done by public-facing API.
     */
    private Object getUserProperty0(String name)
    {
        if (name==null) {
           return null;
        }
        Object o = getInternalUserProperties().get(name);
        if (o==null) {
            o = m_realPH.getUserProperty(name);
        }
        return o;
    }


    /**
     * Internal general property getter. Synchronization must be
     * done by public-facing API.
     */
    private Object getProperty0(String name)
    {
        if (name==null) {
            return null;
        }
        Object o = getInternalProperties().get(name);
        if (o==null) {
            o = m_realPH.getProperty(name);
        } else {
            if (o==EMPTY/*!*/) {//NB:allow for unset local properties!
                o = null;
            }
        }
        return o;
    }


    private void log(String msg, int noiselevel)
    {
        getProjectNoNull().log("PropertiesNet("+getName()+"): "+msg,
                               noiselevel);
    }


    private void log(String msg)
    {
        getProjectNoNull().log("PropertiesNet("+getName()+"): "+msg,
                               Project.MSG_VERBOSE);
    }

 
    private void copyLocalsTracker()
    {
        LocalProperties lp = (LocalProperties)getProject().getReference(MagicNames.REFID_LOCAL_PROPERTIES);
        if (lp!=null) { //bugger's been installed for current thread...make sure we get at stack
            this.add(lp);
        }
    }

    private static final String EMPTY= new String(""+"");//NB:unique emptystring
    private Project m_project;
    private PropertyHelper m_realPH;
    private String m_nameImpl="n/d";
    private Map m_rwProperties = Collections.EMPTY_MAP;//@since AntX-0.5
}


/* end-of-ProjectPropertiesNet.java */
