/**
 * $Id: IfDisabled.java 509 2008-11-16 17:51:52Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.go.Go.TestSkeleton;

/**
 * Test wrapper for the Iteration's <span class="src">isDisabled</span> method. Useful
 * test when need to conditionally re-install fixture information.
 *
 * @since     JWare/AntX 0.6
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   special(as guarded as Iteration.isDisabled())
 * @.group    impl,helper
 * @see       org.jwaresoftware.antxtras.core.Iteration#isDisabled(Project, String)
 **/

final class IfDisabled extends TestSkeleton
{
    /**
     * Initializes a new test for a specific fixture option.
     * @param uri description of fixture component to test (non-null)
     **/
    IfDisabled(String uri)
    {
        super(uri);
    }



    /**
     * Returns <i>true</i> if the named fixture option is not present
     * or is explicitly disabled.
     * @param P project to test (non-null)
     **/
    public boolean pass(Project P)
    {
        verifyInited();
        Boolean b = Iteration.get().isDisabled(P,getParameter());
        return Boolean.TRUE.equals(b) ? true : false;//NB: 'null' is defaulted to 'false'
    }



    /**
     * Returns "IfDisabled" always.
     **/
    public String getParameterName()
    {
        return "IfDisabled";
    }
}


/* end-of-IfDisabled.java */
