/**
 * $Id: Buildstrs.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.apis;

/**
 * Interface of a special JavaBean that contains product-build diagnostics information.
 * Buildstrs values are fixed per release and are usually generated at compile time.
 * Usually a Buildstr's contents are not for public end-user consumption. The information
 * is most often used for backend diagnostics and support. Buildstrs represent a birdseye
 * view of a family of related packages and can be used in conjunction with the JDK's
 * <span class="src">Package</span> class to retrieve more specific information.
 *
 * @since    JWare/internal 1.0
 * @author   ssmc, &copy;1997-2003,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface Buildstrs
{
    /**
     * Returns diagnostics name of build, for example
     * "<span class="src">JW/toolkit 1&#46;0b3_build123</span>".
     **/
    String getID();


    /**
     * If applicable, returns a displayable name for the product build; for
     * example, "<span class="src">Sandbox Software's JWare/CoreLib&#46;</span>".
     * Should return the {@linkplain #getID build name} if no there is no
     * specific display name.
     **/
    String getDisplayName();


    /**
     * Returns version information for the product build, for example
     * "<span class="src">1&#46;0&#46;0b3</span>". No particular format
     * is implied.
     **/
    String getVersion();


    /**
     * Returns this build's unique identifer, for example
     * "<span class="src">1&#46;0&#46;0b3_build3345.123</span>."
     **/
    String getBuildVersion();


    /**
     * Returns date of product build in an abbreviated format, for example
     * "<span class="src">Jan-01-2001,12:34GMT</span>".
     **/
    String getAbbrDate();


    /**
     * Returns date of product build in a verbose format, for example
     * "<span class="src">Monday 1 January 2001, 12:34:34 GMT</span>".
     **/
    String getLongDate();


    /**
     * Returns the product shorthand namespace prefix, for example
     * "<span class="src">jware</span>". Trailing dot is <em>not</em> included.
     **/
    String getNSPrefix();


    /**
     * Returns the product namespace URI, for example
     * "<span class="src">http://jwaresoftware&#46;org/xmlns</span>".
     **/
    String getNSURI();


    /**
     * Returns the product properties namespace prefix, for example
     * "<span class="src">PET&#46;</span>" as used in
     * "<span class="src">PET&#46;repository&#46;filesystem&#46;root&#46;</span>".
     * Any trailing dot should be included.
     **/
    String getPropertiesPrefix();


    /**
     * Returns the product builder's (system) identifier, for example
     * "<span class="src">bldadm02</span>".
     **/
    String getBuilderID();


    /**
     * If applicable, returns the product builder's common name, for example
     * "<span class="src">Build Administrator</span>". Should return the
     * {@linkplain #getBuilderID builder's id} if no CN defined.
     **/
    String getBuilderCN();


    /**
     * Returns OS on which product build generated, for example
     * "<span class="src">Fedora Core Linux 9 build25</span>".
     **/
    String getOS();


    /**
     * Returns host information for machine used for product build, for
     * example "<span class="src">bldmach01</span>".
     **/
    String getHostID();


    /**
     * Optionally returns various paths used when generating product build. For
     * example could return values for build's <span class="src">CLASSPATH</span>,
     * <span class="src">LIBPATH</span>, etc. No particular format is implied.
     **/
    String getUsedPaths();
}

/* end-of-Buildstrs.java */
