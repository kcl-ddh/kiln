/**
 * $Id: TransformHelper.java 1033 2010-03-20 10:12:00Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

import  java.text.DecimalFormat;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.util.FileUtils;

import  org.jwaresoftware.antxtras.helpers.DateTimeFormat;
import  org.jwaresoftware.antxtras.helpers.DurationFormat;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;


/**
 * Utilities to do simple formatting of (raw) string values based on our various
 * transform instructions.
 * <p>
 * <b>Example Usage:</b><pre>
 *     public class MyClass ...
 *     {
 *         private ValueTransform m_T= ValueTransform.NONE;
 *         private String m_value;
 *
 *         public final void setValue(String s) {
 *            m_value = s;
 *         }
 *         public final void setTransform(String t) {
 *            m_T = (t==null) ? ValueTransform.NONE : ValueTransform.from(t,m_T);
 *         }
 *
 *         public final String getValue() {
 *            return <b>TransformHelper.apply</b>(m_T,m_value,getProject());
 *         }
 *         ...
 *     }
 * </pre>
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004-2005,2007-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,helper
 * @see      ValueTransform
 **/

public final class TransformHelper
{
    /**
     * Converts a string value to a long number or returns a
     * symbolic {@linkplain Tk#NO_NUM NO_NUM} if string could
     * not be converted.
     * @param s number string (non-null)
     * @since JWare/AntX 0.4
     **/
    public static final long toNumber(String s)
    {
        return Tk.longFrom(s,Tk.NO_NUM);
    }



    /**
     * Like {@linkplain #toNumber toNumber(&#8230;)} except if
     * the incoming string equals "<span class="src">now</span>"
     * the system's current time is returned as a long
     * (milliseconds).
     * @param s number string or the value "now" (non-null)
     * @since JWare/AntX 0.5
     **/
    public static final long toTimeNumber(String s)
    {
        if (Strings.NOW.equals(s)) {
            return System.currentTimeMillis();
        }
        return Tk.longFrom(s,Tk.NO_NUM);
    }



    /**
     * Inverts the case of every character in a string. Will
     * invert characters according to current locale response
     * to 'isLowerCase' and 'isUpperCase'. Returns <i>null</i>
     * if incoming string is <i>null</i>.
     * @param s string to be inverted
     * @since JWare/AntX 0.4
     **/
    public static final String toInvertCase(String s)
    {
        if (s==null) {
            return s;
        }
        StringBuffer sb = new StringBuffer(s);
        for (int i=0,n=s.length();i<n;i++) {
            char c = s.charAt(i);
            if (Character.isLowerCase(c)) {
                sb.setCharAt(i,Character.toUpperCase(c));
            }
            else if (Character.isUpperCase(c)) {
                sb.setCharAt(i,Character.toLowerCase(c));
            }
        }
        s = sb.substring(0);
        return s;
    }



    /**
     * Short hand for transforming a file system path or file URL
     * into a normalized (possibly project-based) full path. Common
     * operation within AntX tools.
     * @param fileRef description of file (path or URL)
     * @param P project to use if fileref is not absolute
     * @return normalized absolute path (non-null)
     * @since JWare/AntX 0.5
     **/
    public static final String toPath(String fileRef, Project P)
    {
        return apply(ValueTransform.OSPATH,fileRef,P);
    }



    /**
     * Utility that implements simple interpretation of value
     * transformation instructions. Good as a generic fallback.
     * @param t the transform instruction (non-null)
     * @param s the value to be transformed
     * @param P controlling project for problem feedback (non-null)
     * @see DateTimeFormat
     * @see DurationFormat
     * @since JWare/AntX 0.4
     **/
    public static final String apply(ValueTransform t, String s, Project P)
    {
        if (t==null || P==null) {
            throw new IllegalArgumentException();
        }
        if (s==null || s.length()==0) {
            return s;
        }
        switch(t.getIndex()) {
            case ValueTransform.OSPATH_INDEX: {
                FileUtils fu= FileUtils.getFileUtils();
                if (s.startsWith("file:")) {
                    //conform for platform (undo FS#94)
                    if (Tk.onWindows && s.startsWith("file://") && !s.startsWith("file:///")) {
                        s = "file:/"+s.substring("file://".length());
                    }
                    s = fu.fromURI(s);
                } else {
                    s = P.resolveFile(s).getPath();
                }
                break;
            }
            case ValueTransform.OSPATHURL_INDEX: {
                FileUtils fu= FileUtils.getFileUtils();
                if (s.startsWith("file:")) {
                    //conform for platform (undo FS#94)
                    if (Tk.onWindows && s.startsWith("file://") && !s.startsWith("file:///")) {
                        s = "file:/"+s.substring("file://".length());
                    }
                    s = fu.fromURI(s);
                } else {
                    s = P.resolveFile(s).getPath();
                }
                s = fu.toURI(s);
                if (s.startsWith("file:/") && !s.startsWith("file://")) {//malformed URL fix FS#94
                    s = "file://"+s.substring("file:/".length());
                }
                break;
            }
            case ValueTransform.LOWERCASE_INDEX: {
                s = s.toLowerCase();
                break;
            }
            case ValueTransform.UPPERCASE_INDEX: {
                s = s.toUpperCase();
                break;
            }
            case ValueTransform.TRIM_INDEX: {
                s = s.trim();
                break;
            }
            case ValueTransform.STRIPWS_INDEX: {
                s = Tk.stripWhitespace(s);
                break;
            }
            case ValueTransform.DECIMAL_INDEX: {
                Number n = Tk.numberFrom(s);
                if (n==Tk.NO_NUM_NUM) {
                    P.log("Unable to convert '"+s+"' to decimal.",
                            Project.MSG_WARN);
                } else {
                    synchronized(DFI) {
                        s = DFI.format(n);
                    }
                }
                break;
            }
            case ValueTransform.DURATION_INDEX:  {
                long l= toNumber(s);
                if (l!=Tk.NO_NUM) {
                    s = DurationFormat.INSTANCE.format(l,true);
                } else {
                    P.log("Unable to convert '"+s+"' to time duration.",
                          Project.MSG_WARN);
                }
                break;
            }
            case ValueTransform.DATETIME_INDEX: {
                long l= toTimeNumber(s);
                if (l!=Tk.NO_NUM) {
                    s = DateTimeFormat.shortformat(l);
                } else {
                    P.log("Unable to convert '"+s+"' to datetime.",
                          Project.MSG_WARN);
                }
                break;
            }
            case ValueTransform.CHECKPOINT_INDEX:  {
                long l= toTimeNumber(s);
                if (l!=Tk.NO_NUM) {
                    s = DateTimeFormat.GMTformat(l);
                } else {
                    P.log("Unable to convert '"+s+"' to GMT timestamp.",
                          Project.MSG_WARN);
                }
                break;
            }
            case ValueTransform.LONGDATETIME_INDEX: {
                long l= toTimeNumber(s);
                if (l!=Tk.NO_NUM) {
                    s = DateTimeFormat.format(l);
                } else {
                    P.log("Unable to convert '"+s+"' to full datetime.",
                          Project.MSG_WARN);
                }
                break;
            }
            case ValueTransform.INVERTCASE_INDEX: {
                s = toInvertCase(s);
                break;
            }
        }
        return s;
    }

    private TransformHelper() { }

    private static final DecimalFormat DFI = new DecimalFormat("#.###");//NB:90+% expects
}

/* end-of-TransformHelper.java */
