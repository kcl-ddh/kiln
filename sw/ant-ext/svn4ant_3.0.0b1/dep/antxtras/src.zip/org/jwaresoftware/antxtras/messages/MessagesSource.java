/**
 * $Id: MessagesSource.java 618 2009-02-21 15:02:31Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.messages;

import  java.io.File;
import  java.net.URL;

import  org.jwaresoftware.antxtras.parameters.FlexSourceSupport;

/**
 * Source of a raw PropertyResourceBundle used to define a UIStringManager.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface MessagesSource extends FlexSourceSupport
{
    /**
     * Sets this source's resource bundle's location as a URL.
     * @param urlstr URL string representation (non-null)
     * @throws BuildException if this source is a reference or another
     *         or another bundle source has already been specified
     **/
    void setURL(String urlstr);


    /**
     * Returns this source's resource bundle's URL location. Returns
     * <i>null</i> if never set or was set to an invalid URL string.
     **/
    URL getURL();


    /**
     * Sets this source's resource bundle's location as a file.
     * @param filepath the readable file's path (non-null)
     * @throws BuildException if this source is a reference or another
     *         or another bundle source has already been specified
     **/
    void setFile(String filepath);


    /**
     * Returns this source's resource bundle's file location. Returns
     * <i>null</i> if never set (or determined from other source types).
     **/
    File getFile();


    /**
     * Sets this source's resource bundle's location as a classpath-based
     * resource name.
     **/
    void setResource(String rsrc);


    /**
     * Returns this source's resource bundle's classpath-based resource
     * name. Returns <i>null</i> if never set.
     **/
    String getResource();


    /**
     * Explicitly tells us the format of the source. Valid hint values
     * are "properties" or "xml".
     * @param hint format of source (non-null)
     * @since JWare/AntXtras 2.0.0
     **/
    void setFormat(String hint);
}

/* end-of-MessagesSource.java */
