/**
 * $Id: CPULoader.java 615 2009-02-17 00:16:13Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.construct;

import  org.apache.tools.ant.util.ClasspathUtils;

import  org.jwaresoftware.antxtras.core.AntX;

/**
 * Default implementation of a ClassLoader factory method that uses
 * a standard Ant ClasspathUtils Delegate helper.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,infra
 **/

public final class CPULoader implements CustomLoaderFactoryMethod
{
    /**
     * Initializes this adapter for an existing delegate.
     * @param cpud delegate (non-null)
     **/
    public CPULoader(ClasspathUtils.Delegate cpud)
    {
        AntX.require_(cpud!=null,AntX.utilities+"CPULoader:",
                      "ctor- nonzro util delegate");
        m_spi= cpud;
    }


    /**
     * Returns the underlying delegate's class loader. Never returns
     * <i>null</i>.
     **/
    public ClassLoader getClassLoader()
    {
        return m_spi.getClassLoader();
    }


    private final ClasspathUtils.Delegate m_spi;
}

/* end-of-CPULoader.java */
