/**
 * $Id: TruncateFunctionShortcut.java 766 2009-04-11 13:08:49Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.strings;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that will truncate a long string to some prescribed 
 * max length. The general form of the URI:
 * <span class="src"><nobr>$truncate:string[?[maxlength][,,[left|right]]]</nobr>
 * </span>.
 * <p>
 * <b>Example Usage:</b><pre>
 *    &lt;foreach i="path" files="myfileset"&gt;
 *       &lt;property name="next" value="${$basename:${path}|<b>$truncate:?21</b>|$lowercase:}.dat"/&gt;
 *       &lt;emit:show message="progress.next" arg0="${next}"/&gt;
 *       ...
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="truncate"
 *             value="${ojaf}.strings.TruncateFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 * @see       ShortenFunctionShortcut
 **/

public final class TruncateFunctionShortcut extends FunctionShortcutSkeleton
{

    /**
     * Default max threshold for truncated strings ({@value}).
     */
    public static final int MAXLEN= ShortenFunctionShortcut.MAXLEN;


    /**
     * Default minimum length for truncated strings (<i>1</i>).
     */
    public static final int MINLEN= 1;


    /**
     * Tries to truncate the incoming string as requested. If string does
     * not need shortening it is returned unchanged (property references
     * are resolved).
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        final Project P = clnt.getProject();
        int maxlength = MAXLEN;
        int dropped = ShortenFunctionShortcut.RIGHT;
        String longstring = uriFragment;

        int i = longstring.indexOf("?");
        if (i>=0) {
            longstring = longstring.substring(0,i++);
            if (i<uriFragment.length()) {
                String s;
                int j = uriFragment.indexOf(",,",i);
                if (j>=0) {
                    s = Tk.resolveString(P,uriFragment.substring(i,j),true);
                    maxlength = Tk.integerFrom(s,MAXLEN);
                    s = uriFragment.substring(j+2);
                    dropped = ShortenFunctionShortcut.leftOrRight(s,dropped,P);
                } else {
                    s = Tk.resolveString(P,uriFragment.substring(i),true);
                    maxlength = Tk.integerFrom(s,MAXLEN);
                }
            }
        }

        if (maxlength<MINLEN) {
            maxlength=MINLEN;
        }
        longstring = Tk.resolveString(P,longstring,true);
        final int strlen = longstring.length();
        if (strlen>maxlength) {
            switch (dropped) {
                case ShortenFunctionShortcut.LEFT: {
                    int from = strlen-maxlength;
                    longstring= longstring.substring(from);
                    break;
                }
                default: {
                    longstring = longstring.substring(0,maxlength);
                    break;
                }
            }
        }
        return longstring;
    }
}

/* end-of-TruncateFunctionShortcut.java */