/**
 * $Id: Chainable.java 1033 2010-03-20 10:12:00Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  java.util.Stack;


/**
 * Component whose definition can depend on others of the same type.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    impl,helper
 **/

public interface Chainable
{
    /**
     * Required method that ensures this item does not contain any
     * circular references in its definition.
     * @param chain stack of referred-to (or used) items (non-null)
     * @param clnt call controls (non-null)
     * @throws BuildException if circular dependency discovered
     **/
    void verifyNoCircularDependency(Stack chain, Requester clnt);
}

/* end-of-Chainable.java */