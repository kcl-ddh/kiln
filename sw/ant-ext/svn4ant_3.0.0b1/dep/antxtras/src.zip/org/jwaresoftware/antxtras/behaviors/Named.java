/**
 * $Id: Named.java 388 2008-03-30 15:44:14Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

/**
 * Mixin interface for an object that has been publicly named.
 * Whether an object can be unnamed (name is <i>null</i>) is determined by
 * the implementing class.
 *
 * @since    JWare/AntX 0.5 (Extracted from Nameable)
 * @author   ssmc, &copy;2002-2003,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,helper
 **/

public interface Named
{
    /**
     * Returns this object's name.
     **/
    String getName();
}

/* end-of-Named.java */
