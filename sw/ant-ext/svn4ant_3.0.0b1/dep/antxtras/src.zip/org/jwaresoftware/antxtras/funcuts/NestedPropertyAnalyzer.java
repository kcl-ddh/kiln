/**
 * $Id: NestedPropertyAnalyzer.java 965 2010-01-18 13:57:38Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts;

import  java.util.Collection;
import  java.util.Hashtable;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.PropertyHelper;

import  org.jwaresoftware.antxtras.behaviors.PropertyHelperWrap;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.starters.PropertyHelperSkeleton;

/**
 * PropertyHelper that handles nested property references correctly. Only the
 * property replacement method is er "replaced". All other methods are delegated
 * to the original property helper installed when this one was.
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   guarded (as inherited)
 * @.group    impl,infra
 * @see       ManageFuncutsTask
 * @see       RPParser
 * @.caveat   An instance of this class does not track any properties itself. All
 *            permanent changes are passed through to the original helper so if
 *            we're uninstalled, all of those changes to the fixture remain.
 **/

final class NestedPropertyAnalyzer extends PropertyHelperSkeleton 
    implements PropertyHelperWrap
{
    private static final String IAM_ = AntX.utilities+"NestedPropertyAnalyzer";

    NestedPropertyAnalyzer(Project project, Requester calr) {
        super(IAM_);
        install(project,calr);
    }

    public PropertyHelper getReplacedHelper()
    {
        return super.getReplacedHelper();
    }

// ---------------------------------------------------------------------------------------
//  Delegated APIs -- to originally installed helper.
// ---------------------------------------------------------------------------------------

    public void add(Delegate delegate) {
        if (isInstalled()) { getReplacedHelper().add(delegate); }
        else { super.add(delegate); }
    }

    public Collection getExpanders() {
        return getReplacedHelper().getExpanders();
    }

    public void copyInheritedProperties(Project other) {
        getReplacedHelper().copyInheritedProperties(other);
    }

    public void copyUserProperties(Project other) {
        getReplacedHelper().copyUserProperties(other);
    }

    public Hashtable getProperties() {
        return getReplacedHelper().getProperties();
    }

    public Object getProperty(String name) {
        return getReplacedHelper().getProperty(name);
    }

    public Hashtable getUserProperties() {
        return getReplacedHelper().getUserProperties();
    }

    public Object getUserProperty(String name) {
        return getReplacedHelper().getUserProperty(name);
    }

    public void setInheritedProperty(String name, Object value) {
        getReplacedHelper().setInheritedProperty(name,value);
    }

    public void setNewProperty(String name, Object value) {
        getReplacedHelper().setNewProperty(name,value);
    }

    public boolean setProperty(String name, Object value, boolean verbose) {
        return getReplacedHelper().setProperty(name,value,verbose);
    }

    public void setUserProperty(String name, Object value) {
        getReplacedHelper().setUserProperty(name,value);
    }
}

/* end-of-NestedPropertyAnalyzer.java */
