/**
 * $Id: EnumSkeleton.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.EnumeratedAttribute;

import  org.jwaresoftware.antxtras.behaviors.FlexStringFriendly;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Starter implementation for an enumeration attribute. This skeleton implements
 * the standard <span class="src">equals()</span> and <span class="src">hashCode()</span>
 * methods to support proper comparison.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   impl,helper
 **/

public abstract class EnumSkeleton extends EnumeratedAttribute
    implements FlexStringFriendly
{
    /**
     * Initializes an undefined Enum instance.
     **/
    protected EnumSkeleton()
    {
        super();
    }


    /**
     * Use to create public singletons. Ensures the enum
     * instance is initialized as with default Ant
     * Introspector helper thingy.
     **/
    protected EnumSkeleton(String v)
    {
        super();
        Tk.initEnum(this,v);
        this.index = getIndex();
    }


    /**
     * Returns <i>true</i> if this enumerated attribute
     * equals incoming object (also an enumerated attribute).
     **/
    public boolean equals(Object o)
    {
        if (o==this) { return true;  }
        if (o==null) { return false; }
        if (o.getClass()==getClass()) {
            return ((EnumSkeleton)o).getIndex()==this.getIndex();
        }
        return false;
    }


    /**
     * Returns this modification's hash value; fixed when
     * constructed.
     **/
    public int hashCode()
    {
        return this.value.hashCode();
    }


    /**
     * Returns this enum's string value as the property-value
     * friendly representation.
     * @since JWare/AntX 0.3
     **/
    public String stringFrom(Project p)
    {
        return getValue();
    }


    /**
     * For VM singletons, initialized to this enum's index
     * in values array. Is "-1" if undefined (as with default
     * Ant Introspector helper thingy).
     **/
    protected int index= -1;
}

/* end-of-EnumSkeleton.java */
