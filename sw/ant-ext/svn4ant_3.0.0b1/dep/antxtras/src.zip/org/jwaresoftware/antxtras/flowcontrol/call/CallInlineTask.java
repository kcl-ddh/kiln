/**
 * $Id: CallInlineTask.java 847 2009-11-08 19:25:26Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.call;

import  java.util.List;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.PropertySet;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.fixture.CopyPropertyTask;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Task that calls a set of targets <em>within</em> the enclosing project. A
 * new subproject is not created and any modifications to the current project
 * fixture are seen on return. 
 * <p>
 * How this task works is fairly straightforward: it just executes the targets 
 * <em>in the order you list them</em>. Note that the named targets are <em>not</em> 
 * checked for duplication (directly or indirectly). If you would like to 
 * execute the named targets in their own partitioned space, use the 
 * {@linkplain CallTask} instead.
 * <p>
 * If at least one of the named targets does not exist in the enclosing project,
 * <em>no</em> targets are run and a build exception is thrown.
 * <p>
 * <b>Example Usage:</b><pre>
 *    &lt;<b>callinline</b> targets="config-packages,deploy-scripts"/&gt;
 *
 *    &lt;<b>callinline</b> targets="pingmachine1,pingmachine1"
 *           haltiferror="no" tryeach="yes" failproperty="ping.incomplete"/&gt;
 *
 *    &lt;<b>callinline</b> super="common"/&gt;
 *    &lt;<b>callinline</b> super="sharedfixture" targets="labels,workspace"/&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.4
 * @author    ssmc, &copy;2004-2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    api,helper
 **/

public final class CallInlineTask extends CallerTask
{
    /**
     * Initializes a new CallInlineTask instance.
     **/
    public CallInlineTask()
    {
        super(AntX.flowcontrol+"CallInlineTask");
    }



    /**
     * Initializes a new enclosed CallInlineTask instance.
     * @param iam CV-label (non-null)
     **/
    public CallInlineTask(String iam)
    {
        super(iam);
    }

//  ---------------------------------------------------------------------------------------
//  Unique Script-facing Parameters:
//  ---------------------------------------------------------------------------------------


    /**
     * Initializes the names of targets to be executed inlined.
     * @param setOfTargetNames comma-delimited list of names (non-null)
     * @since JWare/AntX 0.4
     **/
    public void setTargets(String setOfTargetNames)
    {
        require_(setOfTargetNames!=null,"setTargets- nonzro names");
        m_targetNames = setOfTargetNames;
    }


    /**
     * Clearer synonymn for {@linkplain #setTargets(String) setTargets}
     * when only a single target is specified.
     * @param targetName the target name (non-blank)
     **/
    public final void setTarget(String targetName)
    {
        setTargets(targetName);
    }


    /**
     * Shorthand way to initialize the target name of a overridden,
     * imported target of the same name as this task's owning target
     * or (as of AntXtras 2.0.0) any imported target.
     * @param importedProjectName name of imported project whose target(s)
     *            we'd like to call (non-null)
     * @since JWare/AntX 0.5
     **/
    public final void setSuper(String importedProjectName)
    {
        require_(importedProjectName!=null,"setSuper- nonzro projectname");
        m_parentProjectName = importedProjectName;
    }



    /**
     * Returns the comma-delimited names of targets to be
     * executed inlined. Will return <i>null</i> if never
     * set explicitly. If called after execution, will contain the
     * fully qualified names of targets from imported projects.
     **/
    public final String getTargetNamesList()
    {
        return m_targetNames;
    }



    /**
     * Adds a new fixture overlay property to this task.
     * This property is automatically put in scope before
     * each target is executed.
     * @param param initialized property (non-null)
     * @since JWare/AntX 0.4
     **/
    public void addProperty(CopyPropertyTask param)
    {
        require_(param!=null,"addProperty- nonzro item");
        getParametersKeeper().addParameter(param);
    }



    /**
     * Adds a new fixture overlay propertyset to this task. The
     * properties named by the property set are automatically
     * put in scope before each named target is executed.
     * @param param property set information (non-null)
     * @since JWare/AntX 0.4
     **/
    public void addPropertySet(PropertySet param)
    {
        require_(param!=null,"addPropertySet- nonzro item");
        getParametersKeeper().addParameter(param);
    }



    /**
     * Ensures this task's list of targets is set and each target
     * exists in enclosing project.
     * @throws BuildException if target list is missing or at least
     *         one target does not exist.
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);

        unfoldImportedTargetNames();

        if (m_targetNames==null) {
            String error = uistrs().get(Errs.TNTA, getTaskName(),"targets|super");
            log(error,Project.MSG_ERR);
            throw new BuildException(error,getLocation());
        }

        List l= Tk.splitList(m_targetNames);
        m_targets = l;

        String tn;
        for (int i=0,N=l.size();i<N;i++) {
            tn = l.get(i).toString();
            if (!targetExists(tn)) {
                String error = uistrs().get
                    ("flow.steplaunch.missing.target",tn,getProject().getName());
                log(error,Project.MSG_ERR);
                throw new BuildException(error,getLocation());
            }
        }
    }


    /**
     * Returns a filled in list of target callers for this
     * task's list.
     * @throws BuildException if name list invalid or a called
     *         target fails.
     */
    protected List copyOfOrderedTargetCallers()
    {
        verify_(m_targets!=null,"copyOf- been verified");

        List l= m_targets;
        List callers= AntXFixture.newList(l.size());
        String tn;
        LocalTargetCaller caller;

        for (int i=0,N=l.size();i<N;i++) {
            tn = l.get(i).toString();
            caller = new LocalTargetCaller(this);
            caller.setTarget(tn);
            transferOverlayParameters(caller);
            callers.add(caller);
        }

        return callers;
    }


    /**
     * Determine fully-qualified inherited target names 
     * if we're calling imported targets.
     * @since JWare/AntXtras 2.0.0
     **/
    private void unfoldImportedTargetNames()
    {
        if (m_parentProjectName!=null) {
            if (m_targetNames==null) {
                verifyInTarget_("setsuper");
                m_targetNames = getOwningTarget().getName();
            }
            String prefix = m_parentProjectName;
            if (!prefix.endsWith(".")) { prefix += "."; }

            List l= Tk.splitList(m_targetNames);
            StringBuffer sb = new StringBuffer(m_targetNames.length()+(l.size()*prefix.length()));

            for (int i=0,N=l.size();i<N;i++) {
                String tn = l.get(i).toString();
                if (i>0) { sb.append(","); }
                sb.append(prefix);
                sb.append(tn);
            }
            
            m_targetNames = sb.substring(0);
        }
    }


    private String m_targetNames;
    private List m_targets;
    private String m_parentProjectName;
}

/* end-of-CallInlineTask.java */
