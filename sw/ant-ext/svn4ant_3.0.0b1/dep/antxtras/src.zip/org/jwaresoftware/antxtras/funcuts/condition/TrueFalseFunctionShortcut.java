/**
 * $Id: TrueFalseFunctionShortcut.java 584 2009-02-07 21:26:16Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.condition;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that tries to normalize an Ant-friendly boolean string to either
 * "<span class="src">true</span>" or "<span class="src">false</span>". Usually called
 * <span class="src">$truefalse:</span>. You can also specify your own true and false
 * normalized strings by setting two fragment parameters (separated by
 * "<span class="src">,,</span>"). The first argument is the true string, the second 
 * is the false string.
 * <p>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;domatch value="${<b>$truefalse:</b>${flag}}" haltifnomatch="yes"&gt;
 *       &lt;equals value="true"&gt;
 *          ...
 *       &lt;equals value="false"&gt;
 *          ...
 *    &lt;/domatch&gt;
 *
 * <b>2)</b> &lt;customertests status="${$isset:incomplete|$truefalse:?PASS,,FAIL}"/&gt;
 *
 * <b>3)</b> -- To Install and Enable --
 *    &lt;managefuncuts action="install"&gt;
 *       &lt;parameter name="truefalse"
 *             value="${ojaf}.condition.TrueFalseFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class TrueFalseFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new truefalse function shortcut.
     **/
    public TrueFalseFunctionShortcut()
    {
        super();
    }


    /**
     * Converts a Ant-isque boolean string into a normalized
     * "<span class="src">true</span>" or "<span class="src">false</span>".
     * If a custom pair of true/false strings specified as query parameters,
     * one of these strings will be returned instead.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        String truefalse = uriFragment;
        String T = Strings.TRUE;
        String F = Strings.FALSE;

        int i= uriFragment.lastIndexOf("?");
        if (i>=0) {
            truefalse = uriFragment.substring(0,i++);
            if (i<uriFragment.length()) {
                String TF = uriFragment.substring(i);
                int j = TF.lastIndexOf(",,");
                if (j>=0) {//NB: allow for empty true strings!
                    T = TF.substring(0,j);
                    j += 2;
                    F = TF.substring(j);
                } else {
                    T = TF;
                }
            }
        }
        truefalse = Tk.resolveString(clnt.getProject(),truefalse,true);
        Boolean B = Tk.string2PosBool(truefalse);
        if (B==null) {
            return null;//NB: is all whitespace
        }
        if (B==Boolean.FALSE) {
            B = Tk.string2NegBool(truefalse);
            if (B==Boolean.TRUE) {
                return null;//NB: unrecognized as a boolean value!
            }
        }
        return B!=null && B.booleanValue() ? T : F;
    }
}


/* end-of-TrueFalseFunctionShortcut.java */