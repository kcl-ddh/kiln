/**
 * $Id: PropertyHelperWrap.java 960 2010-01-09 20:00:26Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  org.apache.tools.ant.PropertyHelper;

/**
 * Service interface to any AntXtras-based PropertyHelper
 * that wraps or decorates the standard Ant helper. Used by
 * generic utilities to get the "real" helper for access 
 * to delegates and such.
 *
 * @since     JWare/AntXtras 3.0.0
 * @author    ssmc, &copy;2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    impl,helper
 **/

public interface PropertyHelperWrap
{
    /**
     * Returns <i>true</i> if we're installed.
     * @since JWare/AntXtras 3.0.0
     **/
    boolean isInstalled();


    /**
     * Returns the helper that was original replaced by this 
     * one. Should not return <i>null</i> once wrap is installed.
     **/
    PropertyHelper getReplacedHelper();
}


/* end-of-PropertyHelperWrap.java */
