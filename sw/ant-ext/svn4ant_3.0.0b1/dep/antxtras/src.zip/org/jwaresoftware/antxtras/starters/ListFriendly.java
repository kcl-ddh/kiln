/**
 * $Id: ListFriendly.java 410 2008-04-20 17:33:55Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.starters;

import  java.util.Iterator;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.FlexStringFriendly;

/**
 * A component that can expose its state as an iterable list of strings.
 * This is a readonly interface; you cannot modify the underlying data
 * object using it.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    impl,helper
 **/

public interface ListFriendly extends FlexStringFriendly
{
    /**
     * Returns an iterator for a <em>snapshot</em> of this item's
     * current contents. Modifications via the returned iterator are
     * <em>not</em> reflected in this item.
     * @param project [optional] source project for property resolution
     **/
    Iterator readonlyStringIterator(Project project);



    /**
     * Returns <i>true</i> if this iterable item is empty.
     **/
     boolean isEmpty();



    /**
     * Returns the number of elements in this iterable item. Returned
     * number should be zero or greater.
     **/
     int size();
}


/* end-of-ListFriendly.java */