/**
 * $Id: Mkdirs.java 425 2008-04-27 02:31:31Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.filesystem;

import  java.io.File;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.parameters.FeedbackLevel;

/**
 * Wrapper utility to create a collection of directories using the Java mkdirs API.
 * Copied from JWare/SAMS (BaseUrlsTools).
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    impl,helper
 **/

final class Mkdirs
{
    /**
     * Ensures the named path refers to a readable directory. Will create directory
     * (including all parent directories) if necessary.
     * @param dir directory to be created (or checked) (non-null)
     * @param haltiferror set true if this method should signal error when cannot
     *             complete request.
     * @param fb problem reporting level (non-null)
     * @param clnt problem reporting conduit (non-null)
     * @throws BuildException if unable to create directories or non-directory
     *             already exists.
     **/
    static boolean run(File dir, boolean haltiferror, FeedbackLevel fb, Requester clnt)
        throws BuildException
    {
        boolean okidoki=true;
        if (!dir.exists()) {
            try {
                dir.mkdirs();
                if (fb.getIndex()<FeedbackLevel.QUIET_INDEX) {
                    clnt.log("Directory created: "+dir.getPath(),
                              Project.MSG_INFO);
                }
            }
            catch (SecurityException secX) {
                String message = Iteration.uistrs().get("task.cant.access.dir",
                                                        dir.getPath());
                if (haltiferror) {
                    clnt.problem(message, Project.MSG_ERR);
                    throw new BuildException(message, secX, clnt.getLocation());
                }
                if (fb.getIndex()<FeedbackLevel.QUIET_INDEX) {//not-none|*quiet
                    clnt.problem(message, Project.MSG_WARN);
                }
                okidoki=false;
            }
        }
        else if (!dir.isDirectory() || !dir.canWrite() || !dir.canRead()) {
            String message;
            if (!dir.isDirectory()) {
                message = "mktemp.mkdirs.file.exists";
            } else {
                message = "task.cant.access.dir";
            }
            message = Iteration.uistrs().get(message,dir.getPath());
            if (haltiferror) {
                clnt.problem(message, Project.MSG_ERR);
                throw new BuildException(message, clnt.getLocation());
            }
            if (fb.getIndex()<=FeedbackLevel.QUIET_INDEX) {//not-none|veryquiet
                clnt.problem(message, Project.MSG_WARN);
            }
            okidoki=false;
        }
        return okidoki;
    }


    private Mkdirs()
    {
    }
}


/* end-of-Mkdirs.java */