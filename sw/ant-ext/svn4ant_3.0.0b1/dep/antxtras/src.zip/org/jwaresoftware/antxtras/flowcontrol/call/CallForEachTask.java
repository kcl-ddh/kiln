/**
 * $Id: CallForEachTask.java 1007 2010-03-11 13:23:42Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.call;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.PropertySet;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.fixture.CopyPropertyTask;
import  org.jwaresoftware.antxtras.fixture.CopyReferenceTask;
import  org.jwaresoftware.antxtras.helpers.InnerNameValuePair;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.ExecutionMode;
import  org.jwaresoftware.antxtras.parameters.FixturePassthru;

/**
 * Task that calls a set of named targets or macros each in an independent
 * copy of the current project. The CallForEachTask allows only
 * &lt;propertyset&gt;, &lt;[copy]property&gt;, and &lt;[copy]reference&gt;
 * declarations to be nested within it as fixture instructions for the
 * cloned project.
 * <p>
 * <b>Example Usage:</b><pre>
 *  &lt;<b>callforeach</b> i="package" list="${packages}"
 *                  targets="deploy,smoketest,signoff"/&gt;
 *
 *  &lt;<b>callforeach</b> i="next.d" dirs="projdirs"
 *                  macros="proj-commit,proj-label,proj-cleanup"/&gt;
 *
 *  &lt;<b>callforeach</b> i="testgroup" list="baseline,junit,soapui"
 *                  targets="runcheck,uploadreport"/&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.4
 * @author    ssmc, &copy;2004-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    api,infra
 **/

public final class CallForEachTask extends ForEachTaskSkeleton
{
    /**
     * Initializes a new CallForEachTask instance.
     **/
    public CallForEachTask()
    {
        super(AntX.flowcontrol+"CallForEachTask:");
    }



    /**
     * Initializes a new helper CallForEachTask instance.
     * @param iam CV-label (non-null)
     **/
    public CallForEachTask(String iam)
    {
        super(iam);
    }


//  ---------------------------------------------------------------------------------------
//  Unique Script-facing Parameters:
//  ---------------------------------------------------------------------------------------

    /**
     * Adds a new fixture overlay property to this task.
     * This property is automatically passed to each target's
     * environment as it is executed.
     * @param param initialized property (non-null)
     * @since JWare/AntX 0.4
     **/
    public void addProperty(CopyPropertyTask param)
    {
        require_(param!=null,"addProperty- nonzro item");
        getParametersKeeper().addParameter(param);
    }



    /**
     * Adds a new fixture overlay property set to this task. The
     * properties named by the property set are automatically
     * copied to  each target's environment before it is executed.
     * @param param property set information (non-null)
     * @since JWare/AntX 0.4
     **/
    public void addPropertySet(PropertySet param)
    {
        require_(param!=null,"addPropertySet- nonzro item");
        getParametersKeeper().addParameter(param);
    }


    /**
     * Adds a new configuration reference to this task. This
     * reference is automatically copied to each target's
     * environment as each is executed.
     * @param param reference information (non-null)
     * @since JWare/AntX 0.4
     **/
    public void addReference(CopyReferenceTask param)
    {
        require_(param!=null,"addReference- nonzro item");
        getParametersKeeper().addParameter(param);
    }



    /**
     * Adds a new macro attribute default value to this task.
     * This attribute is automatically passed to <em>each</em>
     * macro when it is executed.
     * @param attr initialized macro attribute (non-null)
     * @since JWare/AntX 0.5
     * @throws BuildException if this caller is not setup for macros.
     **/
    public void addConfiguredAttribute(InnerNameValuePair attr)
    {
        require_(attr!=null,"addAttribute- nonzro item");
        if (getMacroNamesList()==null) {
            String err = getAntXMsg("flow.attritem.formacros");
            log(err,Project.MSG_ERR);
            throw new BuildException(err,getLocation());
        }
        getParametersKeeper().addParameter(attr);
    }



    /**
     * Instructs this task what kinds of fixture informaton
     * should be passed to the child project. By default only
     * properties are passed on.
     * @since JWare/AntX 0.4
     **/
    public void setPassthru(FixturePassthru passthru)
    {
        require_(passthru!=null,"setPassthru- nonzro option");
        m_passthru = FixturePassthru.from(passthru.getIndex());//NB:normalize
    }



    /**
     * Returns the fixture passthru setting to be used when this
     * caller runs its targets. Never returns <i>null</i>;
     * will return <span class="src">PROPERTIES</span> if
     * not set explicitly.
     * @since JWare/AntX 0.4
     **/
    public final FixturePassthru getPassthruOption()
    {
        return m_passthru;
    }



    /**
     * Sets this task's list of targets. These targets will
     * be called in order from a partitioned clone project
     * when this task is executed.
     * @param setOfTargetNames the comma-delimited list of names
     **/
    public void setTargets(String setOfTargetNames)
    {
        require_(!Tk.isWhitespace(setOfTargetNames),
                 "setTargets- nonwhitespace list");
        m_targetNames = setOfTargetNames;
    }


    /**
     * Clearer synonymn for {@linkplain #setTargets(String) setTargets}
     * when only a single target is specified.
     * @param targetName the target name (non-blank)
     * @since JWare/AntXtras 2.0.0
     **/
    public final void setTarget(String targetName)
    {
        setTargets(targetName);
    }


    /**
     * Returns this task's comma-delimited list of target names.
     * Will return <i>null</i> if never set.
     **/
    public String getTargetNamesList()
    {
        return m_targetNames;
    }



    /**
     * Sets this task's list of macros. These macros will be
     * called in order from the current project's partition when
     * this task is executed.
     * @param setOfMacroNames the comma-delimited list of macros
     * @since JWare/AntX 0.5
     * @.sideeffect Will default mode to "local" if not set.
     **/
    public void setMacros(String setOfMacroNames)
    {
        require_(!Tk.isWhitespace(setOfMacroNames),
                 "setMacros- nonwspc list");
        m_macroNames = setOfMacroNames;
        if (!m_modeInited) {
            setMode(ExecutionMode.LOCAL.getValue());
        }
    }


    /**
     * Clearer synonymn for {@linkplain #setMacros(String) setMacros}
     * when only a single macrodef is specified.
     * @param macroName the macrodef name (non-blank)
     * @since JWare/AntXtras 2.0.0
     **/
    public final void setMacro(String macroName)
    {
        setMacros(macroName);
    }


    /**
     * Returns this task's comma-delimited list of macro names.
     * Will return <i>null</i> if never set. By default, all
     * macros must exist within the same project as this task.
     * @since JWare/AntX 0.5
     **/
    public String getMacroNamesList()
    {
        return m_macroNames;
    }



    /**
     * Tells this tasks to execute items locally (within current
     * project) or isoloated (within a cloned independent project).
     * @param Xmodestring either "local" or "isolated"
     * @since JWare/AntX 0.4
     **/
    public void setMode(String Xmodestring)
    {
        require_(Xmodestring!=null,"setMode- nonzro string");
        m_Xmode = ExecutionMode.from(Xmodestring,m_Xmode);
        m_modeInited = true;
    }



    /**
     * Returns this task's execution mode. Never returns <i>null</i>;
     * will return <span class="src">ISOLATED</span> if never set.
     * @since JWare/AntX 0.4
     **/
    public ExecutionMode getMode()
    {
        return m_Xmode;
    }



    //Required sequence of steps (can be specified by subclass "later")
    //Default way of specifying a set of steps is using a comma-delimited list
    //in "steps" or "targets" attribute.
    private String m_targetNames;
    private String m_macroNames;
    private FixturePassthru m_passthru = FixturePassthru.PROPERTIES;/* NB: Ant dflt */
    private ExecutionMode m_Xmode= ExecutionMode.ISOLATED;
    private boolean m_modeInited;
}

/* end-of-CallForEachTask.java */
