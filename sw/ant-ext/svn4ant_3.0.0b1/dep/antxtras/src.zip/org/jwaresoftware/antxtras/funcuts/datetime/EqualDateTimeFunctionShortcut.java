/**
 * $Id: EqualDateTimeFunctionShortcut.java 766 2009-04-11 13:08:49Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.datetime;

import  java.text.ParseException;
import  java.text.SimpleDateFormat;
import  java.util.Date;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.DateTimeFormat;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that compares two timestamps for equality. Both 
 * timestamps must be supplied (or implied); otherwise the handler 
 * returns <i>null</i>.
 * <p/>
 * <b>Example Usage:</b><pre>
 *  1) &lt;do true="${$<b>equaldate:</b>${crdate1},,${crdate2}}"&gt;
 *
 *  2) &lt;do true="${$<b>equaldate:</b>${crdate1},,${crdate2}?yyyyMMddZZ}&gt;
 *
 *  3) &lt;do true="${$<b>equaldate:</b>${crdate1},,${crdate2}?millis}&gt;
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="equaldate"
 *             value="${ojaf}.datetime.EqualDateTimeFunctionShortcuts"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 * @see       OlderDateTimeFunctionShortcut
 * @see       NewerDateTimeFunctionShortcut
 **/

public class EqualDateTimeFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new same datetime value comparer handler.
     **/
    public EqualDateTimeFunctionShortcut()
    {
        super();
    }


    /**
     * Converts the comparision operation into a normalized true|false
     * string. Will return <i>null</i> if uri is malformed or unable to
     * parse date information.
     */
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        uriFragment = Tk.resolveString(clnt.getProject(),uriFragment,true);

        String ds1=null,ds2=null;
        final int N = uriFragment.length();
        int j,i;
        String fs = null;

        i = uriFragment.indexOf(",,");
        if (i>0) {
            ds1 = uriFragment.substring(0,i);
            i += 2;
            if (i<N) {
                j = uriFragment.indexOf("?",i);
                if (j<0) {
                    ds2 = uriFragment.substring(i);
                } else {
                    ds2 = uriFragment.substring(i,j);
                    j++;
                    if (j<N) {
                        fs = uriFragment.substring(j);
                    }
                }
            }
        }
        if (ds1!=null && ds2!=null) {
            Date d1=null,d2=null;
            if ("millis".equals(fs)) {
                long ms;
                ms = Tk.longFrom(ds1, -1L);
                if (ms>0L) { d1 = new Date(ms); }
                ms = Tk.longFrom(ds2,-1L);
                if (ms>0L) { d2 = new Date(ms); }
            } else {
                SimpleDateFormat df = DateTimeFormat.CHANGELOG;
                if (fs!=null) {
                    df = new SimpleDateFormat(fs);
                }
                synchronized(df) {
                    try {
                        d1 = df.parse(ds1);
                    } catch(ParseException px) {/*burp*/}
                    try {
                        d2 = df.parse(ds2);
                    } catch(ParseException px) {/*burp*/}
                }
                df = null;
            }
            if (d1!=null && d2!=null) {
                return String.valueOf(compare(d1,d2));
            }
        }
        return null;
    }


    /**
     * Perform the comparision operation and return value as a match
     * or not. Will do an equality test by default; subclasses should
     * override to be perform other comparison tests.
     * @param d1 first date in uri (non-null)
     * @param d2 second date in uri (non-null)
     * @return <i>true</i> if comparision condition met.
     */
    protected boolean compare(Date d1, Date d2)
    {
        return d1.equals(d2);
    }
}

/* end-of-EqualDateTimeFunctionShortcut.java */