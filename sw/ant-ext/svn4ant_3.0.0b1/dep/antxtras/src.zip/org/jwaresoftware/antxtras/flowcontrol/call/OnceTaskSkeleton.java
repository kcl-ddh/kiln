/**
 * $Id: OnceTaskSkeleton.java 697 2009-03-07 19:51:29Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.call;

import  java.util.List;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.ExecutionMode;
import  org.jwaresoftware.antxtras.parameters.FixturePassthru;

/**
 * A caller implementation that runs a set of nested tasks or top-level targets
 * once. This task is the internal implementation; the script-facing interface
 * must be provided by a subclass like {@linkplain CallTask}. For a looping
 * construct around the OnceTaskSkeleton, see the {@linkplain ForEachTaskSkeleton}.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,infra
 **/

public abstract class OnceTaskSkeleton extends CallerTask
{
    /**
     * Initializes a new OnceTaskSkeleton.
     **/
    protected OnceTaskSkeleton()
    {
        super(AntX.flowcontrol+"OnceTaskSkeleton:");
    }


    /**
     * Initializes a new CV-labeled OnceTaskSkeleton.
     * @param iam CV-label (non-null)
     **/
    protected OnceTaskSkeleton(String iam)
    {
        super(iam);
    }

// ---------------------------------------------------------------------------------------
// Optional Script-facing Parameters:
// ---------------------------------------------------------------------------------------

    /**
     * Returns the fixture passthru setting to be used when this
     * caller runs its targets. Never returns <i>null</i>;
     * will return <span class="src">PROPERTIES</span> if
     * not set explicitly.
     * @since JWare/AntX 0.4
     **/
    public FixturePassthru getPassthruOption()
    {
        return FixturePassthru.PROPERTIES;
    }


    /**
     * Returns this task's comma-delimited list of target names.
     * Will return <i>null</i> if never set.
     **/
    public String getTargetNamesList()
    {
        return null;
    }


    /**
     * Returns this task's comma-delimited list of macrodef names.
     * Will return <i>null</i> if never set. By default, all
     * macrodefs must exist within the same project as this task.
     * @since JWare/AntX 0.5
     **/
    public String getMacroNamesList()
    {
        return null;
    }



    /**
     * Returns this task's execution mode. Never returns <i>null</i>;
     * will return <span class="src">ISOLATED</span> if never set.
     * @since JWare/AntX 0.4
     **/
    public ExecutionMode getMode()
    {
        return ExecutionMode.ISOLATED;
    }


// ---------------------------------------------------------------------------------------
// Execution:
// ---------------------------------------------------------------------------------------

    /**
     * Returns the number of kinds-of runnables specified (basically
     * whether one or more of targets or macrodefs have been requested).
     **/
    protected int getKindOfRunnablesSpecified()
    {
        int N=0;
        if (getTargetNamesList()!=null) { N++; }
        if (getMacroNamesList()!=null)  { N++; }
        return N;
    }


    /**
     * Ensures that either a named set of steps, targets, or macros
     * has been specified (not both and not none).
     * @param calr calling method's identifier
     * @throws BuildException if verification fails
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);

        int Nr= getKindOfRunnablesSpecified();

        if ((Nr==0) || (Nr>1)) { //only one targetlist -or- macrolist
            String ermsg = uistrs().get("flow.targets.or.steps");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }

        if (getMacroNamesList()!=null && getMode()!=ExecutionMode.LOCAL) {
            String ermsg = getAntXMsg("flow.macro.islocal");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
    }



    /**
     * Returns list of configured {@linkplain TargetCaller
     * target callers} for either the requested macrodefs or targets.
     * Returns an empty list of no macrodefs or targets defined.
     * @throws BuildException if unable to create target callers
     **/
    protected List copyOfOrderedTargetCallers()
        throws BuildException
    {
        String targetNames;

        targetNames = getTargetNamesList();
        if (targetNames!=null) {
            if (getMode()==ExecutionMode.LOCAL) {
                return createLocalTargetCallers(targetNames);
            }
            return createIsolatedTargetCallers(targetNames);
        }

        targetNames = getMacroNamesList();
        if (targetNames!=null) {
            return createMacroInstanceCallers(targetNames);
        }

        return AntXFixture.newList();
    }



    /**
     * Returns a filled in list of pre-configured isolated target
     * to callers for this task's list.
     * @throws BuildException if a requested target does not exist
     **/
    private List createIsolatedTargetCallers(String targetNames)
    {
        List wanted = Tk.splitList(targetNames);
        List callers= AntXFixture.newList(wanted.size());

        IsolatedTargetCaller caller;
        String targetName;

        for (int i=0,N=wanted.size();i<N;i++) {
            targetName = (String)wanted.get(i);
            if (!targetExists(targetName)) {
                String ermsg = uistrs().get("flow.steplaunch.missing.target",
                                            targetName, getProject().getName());
                log(ermsg, Project.MSG_ERR);
                throw new BuildException(ermsg,getLocation());
            }
            caller = new IsolatedTargetCaller(this, targetName);
            transferOverlayParameters(caller);
            callers.add(caller);
        }

        wanted.clear();
        return callers;
    }



    /**
     * Returns a filled in list of local target callers for this
     * task's list.
     * @throws BuildException if a requested target does not exist
     * @since JWare/AntX 0.4
     */
    private List createLocalTargetCallers(String targetNames)
    {
        List wanted= Tk.splitList(targetNames);
        List callers= AntXFixture.newList(wanted.size());

        LocalTargetCaller caller;
        String targetName;

        for (int i=0,N=wanted.size();i<N;i++) {
            targetName = wanted.get(i).toString();
            caller = new LocalTargetCaller(this);
            caller.setTarget(targetName);
            transferOverlayParameters(caller);
            callers.add(caller);
        }

        wanted.clear();
        return callers;
    }




    /**
     * Returns a filled in list of local macro instance callers
     * for this task's list.
     * @throws BuildException if a requested macrodef does not exist
     * @since JWare/AntX 0.5
     */
    private List createMacroInstanceCallers(String nameList)
    {
        List wanted= Tk.splitList(nameList);
        List callers= AntXFixture.newList(wanted.size());

        MacroInstanceCaller caller;
        String targetName;

        for (int i=0,N=wanted.size();i<N;i++) {
            targetName = wanted.get(i).toString();
            caller = new MacroInstanceCaller(this);
            caller.setTarget(targetName);
            transferOverlayParameters(caller);
            callers.add(caller);
        }

        wanted.clear();
        return callers;
    }
}
/* end-of-OnceTaskSkeleton.java */
