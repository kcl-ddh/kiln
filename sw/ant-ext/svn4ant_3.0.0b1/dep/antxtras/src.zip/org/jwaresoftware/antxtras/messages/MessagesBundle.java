/**
 * $Id: MessagesBundle.java 618 2009-02-21 15:02:31Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.messages;

import  java.util.Locale;
import  java.util.ResourceBundle;

import  org.apache.tools.ant.AntClassLoader;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.ProblemHandler;
import  org.jwaresoftware.antxtras.construct.PropertiesLoaderDef;
import  org.jwaresoftware.antxtras.core.AntX;

/**
 * Type that maintains the definition of a properties-based resource 
 * bundle for a UIStringManager. Usually defined &lt;messagesbundle&gt;. 
 * MessagesBundles are also used by all tasks that generate 
 * UIStringManagers from MessagesSources. Note if you specify a resource 
 * for a messages bundle, this class will assume (first) that the 
 * resource refers to a TRUE Java ResourceBundle baseName; i.e. it will  
 * go through the standard Locale-based lookup mechanism for the data.
 * Only if that mechanism fails does it look for a direct resource 
 * match with the value passed in.
 * <p>
 * MessagesBundles are usually defined as part of a build-iterations's 
 * fixture and referred-to by target-based configuration tasks.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;<b>messagesbundle</b> id="compile.msgs"
 *          resource="META-INF.compile-messages"/&gt;
 *
 *   &lt;<b>messagesbundle</b> id="subbuild.msgs" 
 *          mustexist="yes"
 *          file="${build.d}/${module}/msgs.properties"/&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,infra
 * @.caveat  For URL-based data files, assumes the Ant runtime is authorized on
 *           the targeted server(s).
 * @see      ManageMessagesTask
 **/

public final class MessagesBundle extends PropertiesLoaderDef implements MessagesSource
{
    /**
     * Initializes a new MessagesBundle instance. The new 
     * instance is equivalent to an empty Properties file.
     **/
    public MessagesBundle()
    {
        super(AntX.messages+"MessagesBundle:");
    }



    /**
     * Initializes a new MessagesBundle instance with its
     * diagnostics category and 'mustexist' option predefined.
     * Useful constructor when this item is embedded in 
     * another object.
     * @param iam [optional] overriding cv-label
     * @param mustexist <i>true</i> if source must exist
     **/
    public MessagesBundle(String iam, boolean mustexist)
    {
        super(iam,mustexist);
    }



    /**
     * Our implementation data type name is 'messagesbundle'  
     * not 'propertiesdef' (as inherited).
     */
    protected String getCN()
    {
        return "messagesbundle";
    }


    /**
     * Returns the MessagesBundle referenced by this instance.
     * @throws BuildException if reference is not valid.
     **/
    protected PropertiesLoaderDef getSourceRef()
    {
        return (PropertiesLoaderDef)getCheckedRef
                    (MessagesBundle.class, getCN());
    }

// ---------------------------------------------------------------------------------------
// Factory methods for Resource Bundles
// ---------------------------------------------------------------------------------------

    /**
     * Returns a new ResourceBundle based on this bundle's source
     * contents. Never returns <i>null</i>. A resource based source
     * is a one-to-one assignment; a file or URL require a resource
     * bundle wrapper around the source stream (which is assumed to
     * conform to a standard Java Properties file format).
     * @param errH [optional] callback if load problem occurs
     * @throws BuildException if unable to load resource-bundle information.
     **/
    public synchronized ResourceBundle newBundle(ProblemHandler errH)
    {
        ResourceBundle rb;
 
        if  (isReference()) {
            MessagesBundle otherMB = (MessagesBundle)getSourceRef(); 
            rb = otherMB.newBundle(errH);
            if (!triedLoadOnce()) {
                setTriedLoadOnce(otherMB.isWellFormed());//Flip MY flag.
            }
        } else {
            if (!triedLoadOnce()) {
                tryLoadSource(errH);
            }
            rb = this.m_rb;
            if (rb==null) {
                rb = super.newBundleWrap(errH);
            }
        }
        return rb;
    }

// ---------------------------------------------------------------------------------------
// Datasources as (TRUE) Resource Bundles
// ---------------------------------------------------------------------------------------

    /**
     * Shared grunt work for specify-by-resource-bundle-name. Main 
     * complication is figuring out which if any class loader we should 
     * use to find the resource bundle; choices (in precedence): custom 
     * classpath, controller classpath, own class's loader. If we do
     * not find a bundle (assuming a base name), we try the inherited
     * load method which assumes a direct resource path; this allows us
     * to support both bundles and resource path names.
     * @param baseName the base name of the resource bundle (non-null)
     **/
    protected final boolean handleThisResource(String baseName)
    {
        boolean OK = false;
        AntClassLoader AcL = null;
        ClassLoader cL = null;

        if (getProject()!=null && getOwnCLSpi()!=null) {
            AcL = (AntClassLoader)getOwnCLSpi().getClassLoader();
            cL = AcL;
        } else if (getController()!=null) {
            cL = getController().getClassLoader();
        }
        if (cL==null) {
            cL = this.getClass().getClassLoader();//NB: can be null
        }
        try {
            if (cL==null) {
                m_rb = ResourceBundle.getBundle(baseName);
            } else {
                m_rb = ResourceBundle.getBundle(baseName,Locale.getDefault(),cL);
            }
            log("Resource bundle '"+baseName+"' loaded", Project.MSG_DEBUG);
            OK = true;
        } catch(Exception anyX) {
            OK = handleThisResource(baseName, cL);
            if (!OK) {
                log(uistrs().get("task.uism.err.bad.resource",baseName), 
                    Project.MSG_ERR);
            }
        }

        if (AcL!=null) {
            if (getOwnCLSpi().getClassLoadId()==null) {
                AcL.cleanup();
            }
            AcL=null;
        }
        return OK;
    }

    private ResourceBundle m_rb;
}

/* end-of-MessagesBundle.java */
