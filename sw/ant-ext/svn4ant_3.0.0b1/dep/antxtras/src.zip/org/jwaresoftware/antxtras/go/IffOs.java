/**
 * $Id: IffOs.java 407 2008-04-19 16:52:08Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.go;

import  java.util.List;
import  java.util.Locale;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.condition.Os;

import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Implementation of the general <i>if-os</i> test for all conditional components.
 * The <span class="src">IffOs</span> criteria passes if the current Ant runtime's
 * operating system definition matches the given selection criteria. The selection
 * criteria is based on the standard Ant <span class="src">&lt;os&gt;</span> condition.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004-2006,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,helper
 * @.pattern GoF.Strategy
 * @see      Go
 * @see      IffAnt
 * @see      org.jwaresoftware.antxtras.parameters.PlatformConditional PlatformConditional
 **/

public final class IffOs
{
    /**
     * Returns <i>true</i> if the current Ant runtime's operating
     * system definition matches the selection criteria. The general form
     * of the input string is:
     * <span class="src">[family|*],[name|*],[arch|*],[version|*]</span>.
     * Allows selectors like: <pre>
     *    ifOs="windows,*,*,5.0.0.1"
     *    ifOs="unix,*,SunOS"
     * </pre>
     * @param string comma-delimited list of selection fields in order
     * @param P project from which properties read
     * @param ifNot <i>true</i> if test should be for no-match
     **/
    public static boolean pass(String string, Project P, boolean ifNot)
    {
        if (Tk.isWhitespace(string)) {
            return false;
        }

        string = Tk.resolveString(P,string);

        List l= Tk.splitList(string);
        String family = null;
        String next = l.get(0).toString();
        if (!ignore(next)) {
            family = field(next);
        }
        String name = null;
        if (l.size()>1) {
            next = l.get(1).toString();
            if (!ignore(next)) {
                name= field(next);
            }
        }
        String arch = null;
        if (l.size()>2) {
            next= l.get(2).toString();
            if (!ignore(next)) {
                arch = field(next);
            }
        }
        String vers = null;
        if (l.size()>3) {
            next = l.get(3).toString();
            if (!ignore(next)) {
                vers = field(next);
            }
        }
        boolean is= false;
        try {
            is=Os.isOs(family,name,arch,vers);
        } catch(Exception unknownOS) {
            /*burp => unknown => isNot */
        }
        return ifNot ? !is : is;
    }


    /**
     * Execute test for an "if-os" conditional parameter.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class Is extends Go.TestSkeleton {
        public Is() {
        }
        public Is(String choice) {
            super(choice);
        }
        public boolean pass(Project P) {
            verifyInited();
            return IffOs.pass(getParameter(),P,false);
        }
        public String getParameterName() {
            return "ifOS";
        }
    }



    /**
     * Execute test for an "unless-os" conditional parameter.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsNot extends Go.TestSkeleton {
        public IsNot() {
        }
        public IsNot(String choice) {
            super(choice);
        }
        public boolean pass(Project P) {
            verifyInited();
            return IffOs.pass(getParameter(),P,true);
        }
        public String getParameterName() {
            return "unlessOS";
        }
    }


    private static boolean ignore(String s)
    {
        return Tk.isWhitespace(s) || "*".equals(s.trim());
    }


    private static String field(String s)
    {
        return s.toLowerCase(Locale.US);
    }


    /**
     * Prevent; only helpers public.
     **/
    private IffOs() {
    }
}

/* end-of-IffOs.java */
