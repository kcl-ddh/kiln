/**
 * $Id: PrintErrorTask.java 548 2009-01-03 04:42:08Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.print;

import  java.io.IOException;
import  java.io.OutputStream;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.ErrorSnapshot;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.EchoThingTask;

/**
 * Helper task that displays the contents of an {@linkplain ErrorSnapshot} or
 * any Throwable. Useful for displaying errors caught by the &lt;protect&gt;
 * wrapper task.
 * <p>
 * <b>Examples:</b><pre>
 *   &lt;<b>printerror</b> message="Error:" snapshot="javadoc-error"/&gt;
 *
 *   &lt;<b>printerror</b> message="Unexpected Error:" thrown="last.error"/&gt;
 *
 *   &lt;<b>printerror</b> if="log.errors"
 *       snapshot="javadoc-error" messageid="err.javadoc"
 *       tofile="${logs.d}/javadoc.err" append="true"/&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,helper
 **/

public final class PrintErrorTask extends EchoThingTask
{
    /**
     * Initializes new print error task.
     **/
    public PrintErrorTask()
    {
        super(AntX.print);
    }


    /**
     * Initializes a CV-labeled print error task.
     **/
    public PrintErrorTask(String iam)
    {
        super(iam);
    }


    /**
     * Sets the error snapshot reference id for this task. This 
     * reference is evaluated when the task is executed.
     **/
    public void setSnapshot(String refId)
    {
        setThingRefId(refId);
    }


    /**
     * Returns the error snapshot's reference id; can be <i>null</i>
     * if never set. Required for task to execute properly.
     **/
    public final String getSnapshotRefId()
    {
        return getThingRefId();
    }


    /**
     * Sets the throwable reference id for this task. This 
     * reference is evaluated when the task is executed.
     * @since JWare/AntX 0.3
     **/
    public void setThrown(String refId)
    {
        setThingRefId(refId);
    }


    /**
     * Returns the throwable's reference id; can be <i>null</i>
     * if never set. Required for task to execute properly.
     * @since JWare/AntX 0.3
     **/
    public final String getThrownRefId()
    {
        return getThingRefId();
    }


    /**
     * Returns the names of our refid parameters. Returns
     * "<span class="src">thrownid|snapshotid</span".
     * @since JWare/AntX 0.4
     **/
    protected String getThingRefParameterName()
    {
        return "thrown|snapshot";
    }


    /**
     * Verifies that referred-to thing is either a Throwable or
     * an {@linkplain ErrorSnapshot}. Returns the generic object
     * reference if ok. Never return <i>null</i>.
     * @throws BuildException if refid undefined or does not
     *         refer to either a Throwable or an ErrorSnapshot
     * @.sideeffect Also verifies this task is in a valid project
     **/
    public final Object getReferencedErrorThing()
        throws BuildException
    {
        verifyInProject_("getErrorRef");

        String refid = getThingRefId();
        String error = null;

        Object o = getProject().getReference(refid);

        if (o==null) {
            error = uistrs().get(Errs.TMR, refid);
        }
        else if (!(o instanceof Throwable) && !(o instanceof ErrorSnapshot)) {
            error = uistrs().get(Errs.TBR, refid,
                                 Throwable.class.getName()+"|"+ErrorSnapshot.class.getName(),
                                 o.getClass().getName());
        }
        if (error!=null) {
            log(error,Project.MSG_ERR);
            throw new BuildException(error,getLocation());
        }
        return o;
    }


    /**
     * Sets the list of captured properties to include in the output.
     * Use '<i>all</i>' to display all captured properties. Use '<i>none</i>'
     * to skip outputing properties altogether. By default will dump all
     * captured properties. Using the empty string is same as using '<i>none</i>.'
     * @param nameList comma-delimited list of property names (non-null)
     **/
    public void setProperties(String nameList)
    {
        require_(nameList!=null,"setprops- nonzro list");
        m_propertiesList= nameList;
    }


    /**
     * Returns list of captured properties to be output. Returns
     * "<i>all</i>" if all properties will be output. Returns
     * "<i>none</i>" or the empty string if no properties will be output.
     **/
    public final String getPropertiesNameList()
    {
        return m_propertiesList;
    }


    /**
     * Writes diagnostic contents of an ErrorSnapshot or Throwable
     * to this task's specified output stream (file|Ant-log).
     **/
    protected void echoThing()
    {
        OutputStream out= getOutputStream();
        try {
            Object thing = getReferencedErrorThing();

            String name;
            if (thing instanceof ErrorSnapshot) {
                name = ((ErrorSnapshot)thing).getName();
            } else {
                name = Tk.leafNameFrom(thing.getClass());
            }

            DisplayRequest dr= new DisplayRequest(getProject(),name,thing);
            dr.setFilter(getPropertiesNameList());

            m_displayWorker.print(dr,out);

            if (tryAntLog(out)) {
                log(getAntLogString(out),getNoiseLevel().getNativeIndex());
            }

        } catch(IOException ioX) {
            String ermsg = uistrs().get("task.echo.unable");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());

        } finally {
            Tk.closeQuietly(out);
            out=null;
        }
    }


    /**
     * Ensures we're in a valid target/project and have a valid snapshot
     * reference id.
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);
        getReferencedErrorThing();//NB: ensures refid -> ErrorSnapshot|Throwable
    }


    private String m_propertiesList= Strings.ALL;
    private final ErrorPrinter m_displayWorker = new ErrorPrinter();
}

/* end-of-PrintErrorTask.java */
