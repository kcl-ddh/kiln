/**
 * $Id: Identified.java 524 2008-12-16 13:13:09Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

/**
 * Mixin interface for a component that can be uniquely identified
 * using an 'id' parameter. By mixing in this interface, the component
 * declares that its id can be revealed by printers, fixture readers,
 * etc. Unlike {@linkplain Named} custom JWare types can use this 
 * interface to reveal their ids.
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    api,helper
 * @see       Named
 **/

public interface Identified
{
    String getId();
}

/* end-of-Identified.java */
