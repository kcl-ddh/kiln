/**
 * $Id: MalformedCheckEnabled.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for any item that supports the standard
 * '<span class="src">malformed=[ignore|accept|balk|inherit]</span>'
 * parameter.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface MalformedCheckEnabled
{
    /**
     * Sets this item's expected response for malformed information.
     * @param response the response (non-null)
     **/
    void setMalformed(Handling response);


    /**
     * Returns this item's expected handling of malformed information.
     **/
    Handling getMalformedHandling();
}

/* end-of-MalformedCheckEnabled.java */
