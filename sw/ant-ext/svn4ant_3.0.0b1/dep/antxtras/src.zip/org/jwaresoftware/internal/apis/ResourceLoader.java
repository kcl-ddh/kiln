/**
 * $Id: ResourceLoader.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.apis;

import  java.io.IOException;
import  java.util.Properties;

/**
 * Fixture Resource Load Strategy.
 *
 * @since     JWare/internal 1.2
 * @author    ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    api,helper
 * @.pattern  GoF.Strategy
 **/
public interface ResourceLoader
{
    /**
     * Symbolic integer that means "NO SIZE LIMIT" on load.
     **/
    static final int NOLIMIT= Integer.MAX_VALUE;


    /**
     * Symbolic boolean that means "NO CACHED DATA" on load.
     **/
    static final boolean NOCACHE= false;


    /**
     * Load all contents of a class-based resource. Can fall back to the
     * system class path if the resource is not found in given class's
     * package. If no class is given, only top-level resources checked.
     * @param resource name of resource (non-null)
     * @param forClass the resource-owning starting class
     * @param limit limit on amount of data to load (see {@linkplain #NOLIMIT})
     * @throws java.io.FileNotFoundException if unable to find resource
     * @throws IOException if unable to completely load resource's contents
     **/
    byte[] loadResource(String resource, Class forClass, int limit)
        throws IOException;


    /**
     * Load all contents of a classpath-based resource.
     * @param resource name of resource (non-null)
     * @param limit limit on amount of data to load (see {@linkplain #NOLIMIT})
     * @throws java.io.FileNotFoundException if unable to find resource
     * @throws IOException if unable to completely load resource's contents
     **/
    byte[] loadResource(String resource, int limit)
        throws IOException;


    /**
     * Load all contents of a class-based properties resource. Can fall
     * back to the system class path if the resource is not found in
     * given class's package or if no class is given.
     * @param resource name of resource (non-null)
     * @param forClass the resource-owning starting class
     * @param properties [optional] properties to be updated (use <i>null</i> for new)
     * @throws java.io.FileNotFoundException if unable to find resource
     * @throws IOException if unable to completely load resource's contents
     **/
    Properties loadProperties(String resource, Class forClass,
                              Properties properties)
        throws IOException;


    /**
     * Load all contents of a classpath-based properties resource.
     * @param resource name of resource (non-null)
     * @param properties [optional] properties to be updated (use <i>null</i> for new)
     * @throws java.io.FileNotFoundException if unable to find resource
     * @throws IOException if unable to completely load resource's contents
     **/
    Properties loadProperties(String resource, Properties properties)
        throws IOException;
}

/* end-of-ResourceLoader.java */
