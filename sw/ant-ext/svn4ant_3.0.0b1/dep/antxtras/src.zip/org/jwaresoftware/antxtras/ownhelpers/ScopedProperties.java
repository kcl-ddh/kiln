/**
 * $Id: ScopedProperties.java 983 2010-02-27 12:43:10Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.ownhelpers;

import  java.util.Hashtable;
import  java.util.Iterator;
import  java.util.Map;
import  java.util.Properties;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.PropertyHelper;
import  org.apache.tools.ant.property.LocalPropertyStack;
import  org.apache.tools.ant.taskdefs.Property;
import  org.apache.tools.ant.types.PropertySet;

import  org.jwaresoftware.antxtras.behaviors.Nameable;
import  org.jwaresoftware.antxtras.behaviors.ProjectDependent;
import  org.jwaresoftware.antxtras.behaviors.PropertiesFactoryMethod;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.helpers.GenericParameters;

/**
 * Common implementation of the {@linkplain org.apache.tools.ant.DynamicConfigurator
 * DynamicConfigurator} interface.
 *
 * @since     JWare/AntX 0.4
 * @author    ssmc, &copy;2004,2006-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   guarded
 * @.group    impl,helper
 * @see       org.jwaresoftware.antxtras.fixture.wrap.OverlayTaskSet OverlayTaskSet
 **/

public class ScopedProperties extends Hashtable
    implements ProjectDependent, Nameable
{
    private static final String IAM_= AntX.utilities+"ScopedProperties:";


    /**
     * Initializes a new supplemental properties dictionary. This
     * dictionary's project must be defined before it is installed.
     * @param commandProperties <i>true</i> if this helper's properties
     *        act like command properties
     **/
    public ScopedProperties(boolean commandProperties)
    {
        super();
        m_commandProperties = commandProperties;
    }



    /**
     * Initializes a new project-bound supplemental properties dictionary.
     * @param project owning project (non-null)
     * @param commandProperties <i>true</i> if this helper's properties
     *        act like command properties
     **/
    public ScopedProperties(Project project, boolean commandProperties)
    {
        this(commandProperties);
        setProject(project);
    }



    /**
     * Initializes this dictionary's enclosing project. Must be
     * called by this dictionary's controlling task <em>before</em>
     * {@linkplain #install install}.
     **/
    public void setProject(Project project)
    {
        m_project = project;
    }


    /**
     * Returns this dictionary's enclosing project. Will return
     * <i>null</i> if never set.
     **/
    public Project getProject()
    {
        return m_project;
    }



    /**
     * Initializes this dictionary's diagnostic label.
     * @param name the label (non-null)
     **/
    public final void setName(String name)
    {
        m_label = name;
    }



    /**
     * Returns this dictionary's diagnostic label. Will
     * return the empty string if never defined explicitly.
     **/
    public final String getName()
    {
        return m_label;
    }



    /**
     * Tells this dictionary whether <em>standalone</em> keys
     * should be filtered and any underscores replaced with periods.
     * @param swapEm <i>true</i> to swap underscores.
     * @since JWare/AntX 0.5
     **/
    public final void swapUnderscores(boolean swapEm)
    {
        m_swapUnderscores = swapEm;
    }



    /**
     * Installs this dictionary as a supplemental set of project
     * properties until uninstalled. When this method returns, this
     * dictionary will be at the front of the evaluator chain.
     * @param calr calling component (non-null)
     * @see #shouldInstall
     **/
    public final void install(Requester calr)
    {
        AntX.verify_(m_conduit==null,IAM_,"install- not installed");
        AntX.verify_(getProject()!=null,IAM_,"install- in project");

        if (shouldInstall()) {
            PropertyHelper pH = PropertyHelper.getPropertyHelper(getProject()); 
            Conduit c = new Conduit(m_commandProperties, pH, calr);
            pH.add(c);
            m_conduit = c;
        }
    }



    /**
     * Uninstalls this dictionary as a supplemental set of project
     * properties. This method works even if other evaluators have 
     * been installed ahead of this dictionary in the helper.
     * @param calr calling component (non-null)
     **/
    public final void uninstall(Requester calr)
    {
        if (m_conduit!=null) {
            Conduit c = (Conduit)m_conduit;
            m_conduit = null;
            PropertyHelper ph = PropertyHelper.getPropertyHelper(getProject());
            if (FixtureExaminer.unsetDelegate(ph,c,calr)<=0) {
                String warning= AntX.uistrs().get("fixture.supPh.not.instald",getName());
                calr.problem(warning,Project.MSG_WARN);
            }
        }
    }



    /**
     * Adds the given attribute to this dictionary ensuring all
     * underscores in <span class="src">key</span> have been
     * replaced by dots.
     **/
    public final Object put(Object key, Object value)
    {
        AntX.require_((key instanceof String),IAM_,"put- nonzro name");
        String s = (String)key;
        if (m_swapUnderscores) {
            s = s.replace('_','.');
        }
        return super.put(s,value);
    }



    /**
     * Convenient variant of {@linkplain #put(Object,Object)
     * put(&#8230;)} that processes a standard Ant property set.
     **/
    public final void put(PropertySet ps)
    {
        AntX.require_(ps!=null,IAM_,"put- nonzro propertyset");
        this.put(ps.getProperties());
    }



    /**
     * Convenient variant of {@linkplain #put(Object,Object)
     * put(&#8230;)} that processes a standard Ant property declaration.
     * Only works for simple, single-value properties.
     **/
    public final void put(Property p)
    {
        AntX.require_(p!=null,IAM_,"put- nonzro property");
        String name  = p.getName();
        String value = p.getValue();
        if (name!=null && value!=null) {
            super.put(name,value);//NB:skip name swapping
        }
    }



    /**
     * Convenient variant of {@linkplain #put(Object,Object)
     * put(&#8230;)} that processes a standard AntX property list.
     * @param params generic parameter name-value pairs
     * @since JWare/AntX 0.5
     **/
    public final void put(GenericParameters params)
    {
        AntX.require_(params!=null,IAM_,"put- nonzro parameterset");
        this.put(params.copyOfSimpleKeyValues(getProject(),true));
    }



    /**
     * Convenient variant of {@linkplain #put(Object,Object)
     * put(&#8230;)} that processes a standard AntXtras properties factory.
     * @param factory factory of a single <span class="src">Properties</span> object.
     * @since JWare/AntXtras 2.0.0
     **/
    public final void put(PropertiesFactoryMethod factory)
    {
        AntX.require_(factory!=null,IAM_,"put- nonzro factorymethod object");
        this.put(factory.toProperties(getProject()));
    }



    /**
     * Convenient variant of {@linkplain #put(Object,Object)
     * put(&#8230;)} that processes a standard Java <span class="src">Properties</span>.
     * Allows a link to {@linkplain FixtureExaminer#getReferencedProperties(Project, String, Properties)}.
     * @param properties single properties object.
     * @since JWare/AntXtras 2.0.0
     **/
    public final void put(Properties properties)
    {
        AntX.require_(properties!=null,IAM_,"put- nonzro Properties object");
        Iterator itr= properties.entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry e= (Map.Entry)itr.next();
            super.put(e.getKey(),e.getValue());//NB:skip name swapping
        }
    }



    /**
     * Ensure a "get" handles the AntXtras funcut URI format for values.
     * @param name the property to lookup (non-null)
     **/
    final Object lookup(String name)
    {
        String s = (String)get(name);
        if (s!=null) {
            String actual = FixtureExaminer.findValue(getProject(),s,name);
            if (actual!=null) {
                s = actual;
            }
        }
        return s;
    }



    /**
     * Return <i>true</i> if this scoped properties can go ahead
     * and install itself into the Ant property lookup chain. By
     * default will return <i>true</i> if not empty.
     * @since JWare/AntXtras 2.1.0
     **/
    protected boolean shouldInstall()
    {
        return !isEmpty();
    }



    /**
     * ScopedProperties hook into the standard Ant project property framework.
     * This class must play nice with other installed delegates. Redone
     * as of AntXtras 3.0.0 to implement Ant 1.8 PropertyEvaluator+PropertySetter 
     * instead of pre-Ant1.8's propertyHooks. This class needs to be aware of
     * the stack of locals declared "above" it and "below" it on the execution
     * stack. For locals below it, the overlay lets the the local properties
     * mechanism work its magic; for locals above the overlay is activated as
     * if the user had explicitly done &lt;property/&gt; calls.
     *
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  guarded (inherited)
     * @.group   impl,helper
     * @.impl    Depends on working knowledge about the LocalProperties class
     *           and the (current) fact that property helper delegates like
     *           local properties are installed ONCE per thread and NEVER 
     *           uninstalled (no notion of 'scope' for the delegate itself). 
     *           If these implementation details change we will need to update!
     */
    private class Conduit 
        implements PropertyHelper.PropertyEvaluator,PropertyHelper.PropertySetter
    {
        /**
         * Initializes a new conduit (adapter from PH to Scoped).
         * @param commandProperties <i>true</i> if properties are control ones
         **/
        Conduit(boolean commandProperties, PropertyHelper pH, Requester calr) {
            m_rqlink      = calr;
            m_allowEdits  = !commandProperties;
            m_scopesEnter = FixtureExaminer.litecopyOfLocals(pH,calr);
        }


        /**
         * Returns an overlaid property if matched.
         **/
        public Object evaluate(String name, PropertyHelper fromPH) {
            Object value = null;
            if (!allowLocalOverride(name,fromPH)) {
                value = ScopedProperties.this.lookup(name);
            }
            return value;
        }


        /**
         * Updates an overlaid property if matched.
         **/
        public boolean set(String name, Object value, PropertyHelper fromPH) {
            boolean hit = false;
            if (ScopedProperties.this.containsKey(name)) {
                if (!allowLocalOverride(name,fromPH)) {
                    if (m_allowEdits) {
                        ScopedProperties.this.put(name,value);
                    }
                    hit = true;//Stop lookup chain right here...
                }
            }
            return hit;
        }


        /**
         * Same as {@linkplain #set}.
         **/
        public boolean setNew(String name, Object value, PropertyHelper fromPH) {
            return set(name,value,fromPH);
        }


        private boolean allowLocalOverride(String name, PropertyHelper fromPH)
        {
            boolean allow=false;
            LocalPropertyStack scopesNow = FixtureExaminer.currentLocals(fromPH);
            Map current = FixtureExaminer.findLocalScope(scopesNow,name,m_rqlink);
            Map before  = FixtureExaminer.findLocalScope(m_scopesEnter,name,m_rqlink);
            if (current!=null && current!=before) {
                allow=true;
            }
            return allow;
        }

        private final Requester m_rqlink;
        private final boolean m_allowEdits;
        private LocalPropertyStack m_scopesEnter;//NB:Declared scopes on entry
    }


    private boolean m_commandProperties;
    private Project m_project;
    private Object  m_conduit;
    private String  m_label="n/d";
    private boolean m_swapUnderscores;//NB: NO (as of AntX 0.5!)
}

/* end-of-ScopedProperties.java */
