/**
 * $Id: IffAny.java 407 2008-04-19 16:52:08Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.go;

import  java.util.Iterator;
import  java.util.List;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Implementation of the general <i>ifAny</i>, <i>ifAnyTrue</i>, <i>unlessAny</i>,
 * and <i>unlessAnyTrue</i> tests for all conditional components. The
 * <span class="src">IffAny</span> criteria passes if any of the named properties in
 * a list exist within a specified project. It fails if none exist.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,helper
 * @.pattern GoF.Strategy
 * @see      Go
 * @see      IffAll
 **/

public final class IffAny
{
    /**
     * Returns <i>true</i> if any of the named properties in given
     * list exist in project.
     * @param list comma-delimited list of property names
     * @param P project from which properties read
     * @param onlyIfTrue <i>true</i> if the property must also be
     *        a valid positive boolean string
     **/
    public static boolean pass(String list, Project P, boolean onlyIfTrue)
    {
        if (Tk.isWhitespace(list)) {
            return false;
        }
        List l= Tk.splitList(list);
        Iterator itr= l.iterator();
        while (itr.hasNext()) {
            if (Iff.allowed(itr.next().toString(),P,onlyIfTrue)) {
                return true;
            }
        }
        return false;
    }


    /**
     * Execute test for an "if-any" conditional parameter. Null
     * name lists are not allowed.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class Exists extends Go.TestSkeleton {
        public Exists() {
        }
        public Exists(String list) {
            super(list);
        }
        public boolean pass(Project P) {
            verifyInited();
            return IffAny.pass(getParameter(),P,false);
        }
        public String getParameterName() {
            return "ifAny";
        }
    }


    /**
     * Execute test for an "unless-any" conditional parameter. Null
     * name lists are not allowed.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class NotExists extends Go.TestSkeleton {
        public NotExists() {
        }
        public NotExists(String list) {
            super(list);
        }
        public boolean pass(Project P) {
            verifyInited();
            return !IffAny.pass(getParameter(),P,false);
        }
        public String getParameterName() {
            return "unlessAny";
        }
    }


    /**
     * Execute test for an "if-any-true" conditional parameter.
     * Null name lists are not allowed.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsTrue extends Go.TestSkeleton {
        public IsTrue() {
        }
        public IsTrue(String list) {
            super(list);
        }
        public boolean pass(Project P) {
            verifyInited();
            return IffAny.pass(getParameter(),P,true);
        }
        public String getParameterName() {
            return "ifAnyTrue";
        }
    }


    /**
     * Execute test for an "unless-any-true" conditional parameter.
     * Null name lists are not allowed.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsNotTrue extends Go.TestSkeleton {
        public IsNotTrue() {
        }
        public IsNotTrue(String list) {
            super(list);
        }
        public boolean pass(Project P) {
            verifyInited();
            return !IffAny.pass(getParameter(),P,true);
        }
        public String getParameterName() {
            return "unlessAnyTrue";
        }
    }


    /**
     * Prevent; only helpers public.
     **/
    private IffAny() {
    }
}

/* end-of-IffAny.java */
