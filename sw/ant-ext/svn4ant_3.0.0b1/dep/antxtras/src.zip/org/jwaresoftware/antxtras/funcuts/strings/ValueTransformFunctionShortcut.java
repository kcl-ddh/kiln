/**
 * $Id: ValueTransformFunctionShortcut.java 1038 2010-03-20 19:03:33Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.strings;

import  java.util.Map;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.TransformHelper;
import  org.jwaresoftware.antxtras.parameters.ValueTransform;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that applies the builtin AntXtras {@linkplain ValueTransform} 
 * to a given string. The allowed inputs are determined by what's legitimate for
 * the indicated scheme. Note that date/time transforms are usually handled by 
 * the general date function shortcut, not this class.
 * <p/>
 * <b>Example Usage:</b><pre>
 *    &lt;property name="build.id" value="${<b>$uppercase:</b>${build.name}}"/&gt;
 *    &lt;property name="userscratch.url" value="${<b>$ospathurl:</b>${TMP.d}}"/&gt;
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="transform"
 *             value="${ojaf}.strings.ValueTransformFunctionShortcut"/&gt;
 *       &lt;parameter name="ospath"
 *             value="${ojaf}.strings.ValueTransformFunctionShortcut"/&gt;
 *       &lt;parameter name="lowercase"
 *             value="${ojaf}.strings.ValueTransformFunctionShortcut"/&gt;
 *       &#8230;<i>[All other transform shortcuts like uppercase, etc.]</i>
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 **/

public class ValueTransformFunctionShortcut extends FunctionShortcutSkeleton
{
    private static final Map LINKS = AntXFixture.newMap();
    static {
        //NB: long-winded and uglee but obvious. Also not
        //    likely to change anytime soon...
        LINKS.put("$transform:",null);
        LINKS.put("$ospath:",ValueTransform.OSPATH);
        LINKS.put("$path:",ValueTransform.OSPATH);
        LINKS.put("$ospathurl:",ValueTransform.OSPATHURL);
        LINKS.put("$pathurl:",ValueTransform.OSPATHURL);
        LINKS.put("$uppercase:",ValueTransform.UPPERCASE);
        LINKS.put("$lowercase:",ValueTransform.LOWERCASE);
        LINKS.put("$trim:",ValueTransform.TRIM);
        LINKS.put("$stripws:",ValueTransform.STRIPWS);
        LINKS.put("$decimal:",ValueTransform.DECIMAL);
    }



    /**
     * Initializes a new transform function shortcut.
     **/
    public ValueTransformFunctionShortcut()
    {
        super();
    }



    /**
     * Returns the best fit value tranform for the format directive
     * embedded in a given value uri. You can use the general "$transform:"
     * scheme can name a transform that does not have a shorthand scheme.
     * For example: <span class="src">$transform:${crdate}?longdatetime</span>.
     * @param fullUri the full uri (including the '$scheme:' prefix)
     * @param clnt problem handler (non-null)
     * @return the formatter or <i>null</i> if no match found.
     **/
    public static ValueTransform defaultTransform(String fullUri, Requester clnt)
    {
        ValueTransform valfmt= null;
        int i= fullUri.indexOf(':');
        if (i>0) {
            String which= fullUri.substring(0,++i);
            valfmt = (ValueTransform)LINKS.get(which);
            if (valfmt==null && (i=fullUri.indexOf("?",i))>0) {
                i++;
                if (i<fullUri.length()-1) {
                    String byname = Tk.resolveString(clnt.getProject(),
                        fullUri.substring(i),true);
                    valfmt = ValueTransform.from(byname);
                }
            }
        }
        return valfmt;
    }



    /**
     * Programmatic extension point that allows subclasses to add
     * own protocol names and value transform enum. Can also use to override
     * the default formats associated with our standard names.
     * @param name protocol marker string (non-null)
     * @param valfmt ValueTransform enum value (non-null)
     **/
    public static void addMapping(String name, ValueTransform valfmt)
    {
        AntX.require_(name!=null&&valfmt!=null, 
                     "ValueTransformFunctionShortcut:",
                     "addMapping- nonzro args");
        synchronized(LINKS) {
            LINKS.put(name,valfmt);
        }
    }



    /**
     * Tries to transform a script-supplied string as instructed. The
     * result is returned as a string. If an exception was thrown by
     * the transformation and the current cycle is not set to halt
     * funcut problems, this method returns <i>null</i>.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        ValueTransform vt = defaultTransform(fullUri,clnt);
        if (vt!=null) {
            int i = uriFragment.lastIndexOf('?');
            if (i>0) {
                uriFragment = Tk.resolveString(clnt.getProject(),
                    uriFragment.substring(0,i), true);
            } else {
                uriFragment = Tk.resolveString(clnt.getProject(),
                    uriFragment, true);
            }
            try {
                return TransformHelper.apply(vt,uriFragment,clnt.getProject());
            } catch(RuntimeException anyX) {
                clnt.problem(anyX.getMessage(),Project.MSG_WARN);
                if (isHaltIfError(clnt)) {
                    throw anyX;
                }
            }
        }
        return null;
    }
}

/* end-of-ValueTransformFunctionShortcut.java */