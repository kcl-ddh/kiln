/**
 * $Id: PasswordFunctionShortcut.java 1038 2010-03-20 19:03:33Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.info;

import  java.io.File;
import  java.util.Properties;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.core.FunctionShortcut;
import  org.jwaresoftware.antxtras.helpers.InputFileLoader;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.TransformHelper;
import  org.jwaresoftware.antxtras.parameters.ValueTransform;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that lets a script reference a password without 
 * embedding the password directly in script. Whether the referred to 
 * password is clear text or cipher text is application dependent.
 * <p/>
 * The handler looks for a set of properties of username=password settings.
 * It looks for these properties in several places:<ol>
 *   <li>A <span class="src">passwordfile</span> artifact (derived by an
 *       installed '<span class="src">$artifact:</span>' function shortcut. 
 *       If available, the artifact must specify either a file path or a 
 *       file path URL.</li>
 *   <li>A local <span class="src">&lt;propertyset&gt;</span> or 
 *       <span class="src">&lt;properties&gt;</span> object under refid
 *       '<span class="src">run&#46;passwords</span>'. <i>This option exists 
 *       primarily to aid debugging and script development.</i></li>
 *   <li>The file named in the default iteration password file property. See
 *       {@linkplain org.jwaresoftware.antxtras.core.Defaults#passwordFileLocation
 *        Defaults.passwordFileLocation} for more information.</li>
 *   <li>A <span class="src">run&#46;passwords</span> file stored under the
 *       directory <span class="src">${user&#46;home}/&#46;ant/&#46;private</span>.</li>
 *   <li>A defaults password returned by the builtin $default: function
 *       shortcut.</li>
 * </ol>
 * At least <em>one</em> of these places must contain a valid set of properties.
 * If no properties are found or if there is not a match for the given key, this 
 * funcut returns <i>null</i> if its haltIfError setting is disabled; otherwise,
 * it signals an error. 
 * <p/>
 * <b>Example Usage:</b><pre>
 *    &lt;baseurl name="data" uri="http://qalab.mysoft.com/myproject/data/"&gt;
 *       &lt;parameter name="auth:username" value="nightlybuild"/&gt;
 *       &lt;parameter name="auth:password" value="${<b>$password:</b>nightlybuild}"/&gt;
 *    &lt;/baseurl&gt;
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="password"
 *             value="${ojaf}.info.PasswordFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntXtras 0.5
 * @author    ssmc, &copy;2004-2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    helper,example
 * @.caveat   The password file is loaded <em>everytime</em> a handler is
 *            asked for a value. Nothing is cached.
 **/

public final class PasswordFunctionShortcut extends FunctionShortcutSkeleton
{
    private static final boolean OPTIONAL= true;
    static final String  STORENAME= "run.passwords";

    /**
     * Tries to load the passwords &#46;properties file to search for
     * a single entry. Only handles old-style properties file format.
     * @param f password file
     * @param optional <i>true</i> if file does not have to exist.
     * @param clnt problem handler (non-null)
     * @return password file as Properties object (null if optional
     *         and cannot find/load file).
     * @throws BuildException if unable to load file as properties
     *         file for any reason and is not optional
     **/
    private Properties readFile(File f, boolean optional, Requester clnt)
    {
        try {
            return InputFileLoader.loadProperties
                (AntXFixture.fileUtils().getFileURL(f), null);
        } catch(Exception anyX) {
            clnt.problem(anyX.getMessage(),
                optional? Project.MSG_WARN : Project.MSG_ERR);
            if (!optional) {
                throw new BuildException(anyX,clnt.getLocation());
            }
        }
        return null;
    }



    /**
     * Get password file according to our search algorithm. First we
     * look for an artifact "<span class="src">passwordfile</span>".
     * Next we look for a local propertyset (or properties) called
     * "<span class="src">run&#46;passwords</span>". Next we look
     * for a client-supplied file using the iteration's passwordfile
     * configuration setting. If no such setting, we look for a file
     * <span class="src">run&#46;passwords</span> in the user's ant
     * directory at <span class="src">${user&#46;home}/&#46;ant</span>.
     * @param clnt error handler (non-null)
     * @return username/password pairs as a properties object.
     **/
    private Properties getPWFile(Requester clnt)
    {
        Project project = clnt.getProject();
        AntX.verify_(project!=null, AntX.funcuts+"Password:",
                     "valueFrom- called from project");

        String generated = Iteration.funcutHandler("artifact").valueFrom
            ("passwordfile","$artifact:passwordfile",clnt);
        if (generated!=null) {
            File f = new File(TransformHelper.apply
                (ValueTransform.OSPATH,generated, project));
            return readFile(f,!OPTIONAL,clnt);
        }

        Properties passwords = FixtureExaminer.getReferencedProperties
            (project, STORENAME, null);
        if (passwords!=null) {
            return passwords;
        }
        Object o = project.getReference(STORENAME);
        if (o!=null) {
            clnt.problem("Unrecognized data under '"+STORENAME+"': "+
                o.getClass().getName(), Project.MSG_WARN);
        }

        String filename = Iteration.defaultdefaults().passwordFileLocation(project);
        if (filename!=null) {
            File f = project.resolveFile(filename);
            return readFile(f,!OPTIONAL,clnt);
        }

        filename = Tk.getTheProperty(project,"user.home");
        File f = new File(filename);
        f = new File(f,".ant"+File.separator+".private"+File.separator+STORENAME);
        return readFile(f,OPTIONAL,clnt);
    }



    /**
     * Tries to extract the named password from the current iteration's
     * password file. The password file is loaded everytime a request is
     * evaluated (yick but safe).
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        String value = null;
        Properties pwfile = getPWFile(clnt);
        if (pwfile!=null) {
            String owner = Tk.resolveString(clnt.getProject(),uriFragment,true);
            value = pwfile.getProperty(owner);
            pwfile.clear();
            pwfile= null;
        }
        if (value==null) {
            FunctionShortcut helper = Iteration.funcutHandler("default");
            value = helper.valueFrom("password","$default:password",clnt);
            if (value==null && isHaltIfError(clnt)) {
                String error = AntX.uistrs().get("fc.passwordfile.notfound");
                clnt.problem(error, Project.MSG_ERR);
                throw new BuildException(error,clnt.getLocation());
            }
        }
        return value;
    }
}

/* end-of-PasswordFunctionShortcut.java */