/**
 * $Id: RequesterShortcuts.java 768 2009-04-19 23:54:55Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.info;

import  java.io.File;

import  org.apache.tools.ant.Location;
import  org.apache.tools.ant.Target;
import  org.apache.tools.ant.Task;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.FunctionShortcut;

/**
 * Collection of short funcuts all related to a single bit
 * of information about a {@linkplain Requester}.
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    impl,infra,helper
 **/

public final class RequesterShortcuts
{
    /**
     * Starting implementation for our shortcuts. Common behavior.
     *
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     **/
    private abstract static class InnerFuncut implements FunctionShortcut 
    {
        protected InnerFuncut() {
            super();
        }

        public String getDefaultValue(String fullUri, Requester clnt)
        {
            return "";
        }

        final boolean hasLocation(Requester clnt)
        {
            Location loc = clnt!=null ? clnt.getLocation() : null;
            return (loc!=null && loc!=Location.UNKNOWN_LOCATION);
        }

        final Target getTarget(Requester clnt)
        {
            Target tgt = clnt.getSourceTarget();
            if (tgt==null && clnt.getProject()!=null) {
                Task t = clnt.getProject().getThreadTask(Thread.currentThread());
                if (t!=null) {
                    tgt = t.getOwningTarget();
                }
            }
            return tgt;
        }
    }



    /**
     * Return the requester's target's name or the empty string.
     *
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     **/
    public final static class GetTargetName extends InnerFuncut
    {
        public String valueFrom(String uriFragment, String fullUri, Requester clnt)
        {
            String s = null;
            Target t = getTarget(clnt);
            if (t!=null) {
                s = t.getName();
            }
            return s==null ? getDefaultValue(fullUri,clnt) : s;
        }
    }



    /**
     * Return the requester's project's name or the empty string.
     *
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     **/
    public final static class GetProjectName extends InnerFuncut
    {
        public String valueFrom(String uriFragment, String fullUri, Requester clnt)
        {
            String s = null;
            if (clnt.getProject()!=null) {
                s = clnt.getProject().getName();
            }
            return s==null ? getDefaultValue(fullUri,clnt) : s;
        }
    }



    /**
     * Return the requester's location's short file name or the
     * empty string if no location.
     *
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     **/
    public final static class GetFileName extends InnerFuncut
    {
        public String valueFrom(String uriFragment, String fullUri, Requester clnt)
        {
            String s = null;
            if (hasLocation(clnt)) {
                File f = new File(clnt.getLocation().getFileName());
                s = f.getName();
            }
            return s==null ? getDefaultValue(fullUri,clnt) : s;
        }
    }


    /**
     * Return the requester's location's line number or the
     * empty string if no location.
     *
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     **/
    public final static class GetFileLine extends InnerFuncut
    {
        public String valueFrom(String uriFragment, String fullUri, Requester clnt)
        {
            String s = null;
            if (hasLocation(clnt)) {
                s = String.valueOf(clnt.getLocation().getLineNumber());
            }
            return s==null ? getDefaultValue(fullUri,clnt) : s;
        }
    }



    /**
     * Return the requester's location's short description in
     * form &lt;file&gt;@&lt;linenumber&gt;. Returns the empty
     * string if no location.
     *
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     **/
    public final static class GetFileLocation extends InnerFuncut
    {
        public String valueFrom(String uriFragment, String fullUri, Requester clnt)
        {
            String s = null;
            if (hasLocation(clnt)) {
                File f = new File(clnt.getLocation().getFileName());
                s = f.getName() + "@" + clnt.getLocation().getLineNumber();
            }
            return s==null ? getDefaultValue(fullUri,clnt) : s;
        }
    }



    /**
     * Return the requester's target location's short description 
     * in form &lt;file&gt;:&lt;targetname&gt;@&lt;linenumber&gt;. 
     * Returns the empty string if no location or target.
     *
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     **/
    public final static class GetTargetLocation extends InnerFuncut
    {
        public String valueFrom(String uriFragment, String fullUri, Requester clnt)
        {
            String targetname = null;
            Target t = getTarget(clnt);
            if (t!=null) {
                targetname = t.getName();
            }
            String s = null;
            if (hasLocation(clnt)) {
                File f = new File(clnt.getLocation().getFileName());
                if (targetname!=null) {
                    s = f.getName()+":"+targetname;
                } else {
                    s = f.getName();
                }
                s += "@" + clnt.getLocation().getLineNumber();
            } else {
                s = targetname;
            }
            return s==null ? getDefaultValue(fullUri,clnt) : s;
        }
    }



    /**
     * Return the requester's thread's name. Returns the empty
     * string if current thread has no explicit name.
     *
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     **/
    public final static class GetThreadName extends InnerFuncut
    {
        public String valueFrom(String uriFragment, String fullUri, Requester clnt)
        {
            Thread t = Thread.currentThread();
            String s = t.getName();
            return s==null ? getDefaultValue(fullUri,clnt) : s;
        }
    }



    /** 
     * Not Allowed.
     **/
    private RequesterShortcuts() { }
}

/* end-of-RequesterShortcuts.java */
