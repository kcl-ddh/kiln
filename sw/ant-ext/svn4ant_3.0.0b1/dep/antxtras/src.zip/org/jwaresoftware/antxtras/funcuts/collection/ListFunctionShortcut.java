/**
 * $Id: ListFunctionShortcut.java 944 2010-01-05 01:11:59Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.collection;

import  java.util.Iterator;
import  java.util.List;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.ResourceCollection;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.ListFriendly;

/**
 * Function shortcut that lets you extract information from a list friendly
 * data object. This shortcut is installed automatically by the AntXtras
 * antlib. List value shortcuts are often linked to the
 * <span class="src">$list:</span> scheme. The general form of the shortcut:
 * <span class="src"><nobr>$list:listrefid|comma-delimited-list[?[values|size|dump|<i>index</i>][,,delim]]</nobr></span>.
 * The delim option is only relevant to the values operation.
 * <p/>
 * This shortcut assumes that the named item is a reference to a list-friendly
 * data object unless the name is surrounded by square brackets or no such reference
 * exists. If not a reference, this handler treats the name as an inlined comma-
 * delimited list(as would be the case for a list stored in a property value).
 * <p/>
 * You can use this shortcut to extract a particular string from the targetted
 * list. Set the URI's query string (the bit after the "&#63;") to the item's
 * 0-based index; for example: <span class="src">$list:javadoc.servers?3</span>.
 * You can also extract the size of a list by setting the query string to
 * "<span class="src">size</span>" like: <span class="src">$list:logs?size</span>.
 * <p>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;urls id="doc.links" prefix="http://" suffix="/apis/package-list"&gt;
 *       &lt;url value="${oja.org}/thirdparty/junit"/&gt;
 *       &lt;url value="${oja.org}/canary/latest"/&gt;
 *       ...
 *    &lt;/urls&gt;
 *    ...
 *    &lt;show message="There are ${<b>$list:</b>doc.links?size}" packages"/&gt;
 *    &lt;doforeach i="link" list="${<b>$list:</b>doc.links}"&gt;
 *       ...
 *    &lt;/doforeach&gt;
 *
 * <b>2)</b> &lt;macrodef name="run-programmertests"&gt;
 *       &lt;attribute name="jvm.args" default=""/&gt;
 *       ...
 *       &lt;do true="${$isdefined:@{jvm.args}}"&gt;
 *          &lt;doforeach i="i" in="0,${<b>$list:</b>@{jvm.args}?size}"&gt;
 *             &lt;altertask name="myjunit" resolveproperties="yes"&gt;
 *                &lt;jvmarg value="${<b>$list:</b>@{jvm.args}?${i}}"/&gt;
 *             &lt;/altertask&gt;
 *          &lt;/doforeach&gt;
 *       &lt;/do&gt;
 *
 * <b>3)</b> -- To Install --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="list"
 *            value="${ojaf}.collection.ListFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class ListFunctionShortcut extends CollectionFunctionShortcutSkeleton
{
    /**
     * Initializes a new list function shortcut.
     **/
    public ListFunctionShortcut()
    {
        super();
    }


    /**
     * Returns "VALUES" always.
     */
    int getDefaultOp()
    {
        return VALUES;
    }


    /**
     * Extracts the bit of list information requested. Currently supports
     * three special operations: dump, values (also default if no fragment),
     * and size. Any other query string is considered the lookup index.
     **/
    String valueFromTyped(String refid, int op, String arg2, String key,
        Requester clnt)
    {
        final Project P = clnt.getProject();

        Object o;
        if (refid.startsWith("[") && refid.endsWith("]")) {
            refid = refid.substring(1,refid.length()-1);
            o = null;
        } else {
            o = FixtureExaminer.trueReference(P,refid);
        }
        if (o instanceof ListFriendly) {
            ListFriendly l = (ListFriendly)o;
            switch(op) {
                case SIZE: {
                    return String.valueOf(l.size());
                }
                case ISEMPTY: {
                    return String.valueOf(l.isEmpty());
                }
                case VALUES:
                case KEYSET: {
                    if (arg2!=null) {
                        return listFrom(l.readonlyStringIterator(P),arg2);
                    }
                    return l.stringFrom(P);
                }
                case LOOKUP: {
                    int i = Tk.integerFrom(key,-1);
                    if (i>=0) {
                        Iterator itr= l.readonlyStringIterator(P);
                         int n=0;
                         while (itr.hasNext()) {
                             String s = itr.next().toString();
                             if (n==i) {
                                 return s;
                             }
                             n++;
                         }
                    }
                    break;
                }
                case CONCAT: {
                    return merged(l.stringFrom(P),arg2,clnt);
                }
                case DUMP: {
                    return String.valueOf(o);
                }
            }
        } else if (o instanceof ResourceCollection) {

            return valueFromCollection(o,op,arg2,key,clnt);

        } else if (o==null || (o instanceof List)) {
            List l = o==null ? Tk.splitList(refid.trim()) : (List)o;
            switch(op) {
                case SIZE: {
                    return String.valueOf(l.size());
                }
                case ISEMPTY: {
                    return String.valueOf(l.isEmpty());
                }
                case LOOKUP: {
                    int i = Tk.integerFrom(key,-1);
                    if (i>=0 && i<l.size()) {
                        return (String)l.get(i);
                    }
                    break;
                }
                case VALUES:
                case KEYSET: {
                    return listFrom(l.iterator(),delimFrom(arg2));
                }
                case CONCAT: {
                    return merged(listFrom(l.iterator(),delimFrom(null)),arg2,clnt);
                }
                default: {
                    return String.valueOf(l);
                }
            }
        }
        return null;
    }




    /**
     * Extracts the resource collection information requested. Like
     * valueFromTyped but for ResourceCollection type specifically.
     * @since JWare/AntXtras 2.0.0
     **/
    private String valueFromCollection(Object o, int op, String arg2,
        String key, Requester clnt)
    {
        ResourceCollection l = (ResourceCollection)o;
        switch(op) {
            case SIZE: {
                return String.valueOf(l.size());
            }
            case ISEMPTY: {
                return String.valueOf(l.size()<=0);
            }
            case VALUES:
            case KEYSET: {
                return listFrom(l.iterator(),delimFrom(arg2));
            }
            case LOOKUP: {
                int i = Tk.integerFrom(key,-1);
                if (i>=0) {
                    Iterator itr= l.iterator();
                     int n=0;
                     while (itr.hasNext()) {
                         Object r = itr.next();
                         if (n==i) {
                             return String.valueOf(r);
                         }
                         n++;
                     }
                }
                break;
            }
            case CONCAT: {
                return merged(listFrom(l.iterator(),delimFrom(null)),arg2,clnt);
            }
            case DUMP: {
                return String.valueOf(o);
            }
        }
        return null;
    }


    /**
     * Creates combination of two list strings. Second list is optional.
     **/
    private String merged(final String list1, final String arg2, Requester clnt)
    {
        String both = list1;
        if (arg2!=null) {
            String list2 = this.valueFromTyped(arg2,VALUES,null,null,clnt);
            if (list2!=null && list2.length()>0) {
                both += delimFrom(null)+list2;
            }
        }
        return both;
    }
}

/* end-of-ListFunctionShortcut.java */