/**
 * $Id: LocalPropertyExaminer.java 415 2008-04-22 02:08:37Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.FlexString;
import  org.jwaresoftware.antxtras.helpers.NameValuePair;
import  org.jwaresoftware.antxtras.ownhelpers.PropertyExaminer;
import  org.jwaresoftware.antxtras.ownhelpers.UnresolvedProperty;

/**
 * A utility singleton that examines flexvalue properties to
 * unresolved bits.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,helper
 **/

final class LocalPropertyExaminer
{
    /**
     * Worker bee.
     **/
    private static final PropertyExaminer EXAMINER
        = new PropertyExaminer();
    static {
        EXAMINER.setCheckBrokenSubstitution();
    }


    /**
     * Verify a property definition's current value.
     **/
    static boolean verifyProperty(Project P, FlexString propertydef) {
        String name  = propertydef.sourceString(P);
        String value = propertydef.targetString(P,name);
        boolean ok = value!=null && value!=UnresolvedProperty.VALUE;
        if (ok) {
            NameValuePair nvp= new NameValuePair();
            nvp.setName(name);
            nvp.setValue(value);
            ok = EXAMINER.verifiedPropertyValue(nvp,P)!=null;
        }
        return ok;
    }


    /**
     * Verify a project property's current value.
     **/
    static boolean verifyProperty(Project P, String property) {
        String value = P.getProperty(property);
        boolean ok = value!=null;
        if (ok) {
            NameValuePair nvp= new NameValuePair();
            nvp.setName(property);
            nvp.setValue(value);
            ok = EXAMINER.verifiedPropertyValue(nvp,P)!=null;
        }
        return ok;
    }


    /**
     * Verify an in-place "literal" value.
     **/
    static boolean verifyLiteral(Project P, String literal) {
        return EXAMINER.verifiedLiteral(literal,P);
    }


    /**
     * Verify an in-place "literal" definition.
     **/
    static boolean verifyLiteral(Project P, FlexString literaldef) {
        return EXAMINER.verifiedLiteral(literaldef.sourceString(P),P);
    }


    /**
     * Prevented.
     **/
    private LocalPropertyExaminer()
    {
    }
}

/* end-of-LocalPropertyExaminer.java */
