/**
 * $Id: RandomFunctionShortcut.java 857 2009-11-15 17:35:56Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.construct;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.SIDs;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that generates a {@linkplain SIDs random value}. Very useful
 * in tests and SAMS artifact definition methods. There are four types of pseudo-random
 * values: b[oolean], s[tring], i[nteger], and l[ong]. The string and integer options
 * also support a single parameter that is used as a prefix in case of string and as
 * an upper bound in case of integer. The long and boolean funcuts do not support
 * any parameters. Note that the returned values for random integer and long number  
 * can be positive, zero, or negative! For integers, if you specify a bounds, that
 * will limit the results to (0-N] where N is the upper bound you specified.
 * <p/>
 * If you are generating a value to be used as a reference identifier
 * in a particular project, use the complementary 
 * {@linkplain NewRefIdFunctionShortcut $newrefid:} shortcut instead.
 * <p/>
 * Be careful when using this function shortcut as part of an overlaid property's 
 * value&#8212; the value <em>will change everytime</em> the property is dereferenced!
 * <p/>
 * <b>Example Usage:</b><pre>
 *  &lt;assign var="key" value="${<b>$random:str?key</b>}"/&gt;
 *  &lt;assign var="waitms" value="${<b>$random:int?9999</b>}"/&gt;
 *  &lt;assign var="flag" value="${<b>$random:bool</b>}"/&gt;
 *
 * -- To Install and Enable --
 *  &lt;managefuncuts action="enable"&gt;
 *     &lt;parameter name="random"
 *           value="${ojaf}.construct.RandomFunctionShortcut"/&gt;
 *  &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 * @see       NewRefIdFunctionShortcut
 **/

public final class RandomFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initalizes a new pseudo-random value generator.
     **/
    public RandomFunctionShortcut()
    {
        super();
    }


    /**
     * Returns a pseudo-random value based on the incoming instruction.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        if (uriFragment.length()==0) {
            return SIDs.next();
        }
        String adjustment = "";
        int i = uriFragment.indexOf("?");
        if (i>0) {
            if (i<uriFragment.length()-1) {
                adjustment = uriFragment.substring(i+1);
            }
            uriFragment = uriFragment.substring(0,i);
        }
        uriFragment = Tk.lowercaseFrom(uriFragment);
        switch (uriFragment.charAt(0)) {
            case 's': {
                return SIDs.next(adjustment/*prefix*/);
            }
            case 'i': {
                int limit = Tk.NO_INT;
                if (adjustment.length()>0) {
                    limit = Tk.integerFrom(adjustment,Tk.NO_INT);
                }
                if (limit!=Tk.NO_INT) {
                    return String.valueOf(SIDs.nextInt(limit));
                }
                return String.valueOf(SIDs.nextInt());
            }
            case 'l': {
                return String.valueOf(SIDs.nextLong());
            }
            case 'b': {
                int value = SIDs.nextInt(2);
                return String.valueOf(value!=0);
            }
        }
        return getDefaultValue(fullUri,clnt);
    }
}

/* end-of-RandomFunctionShortcut.java */