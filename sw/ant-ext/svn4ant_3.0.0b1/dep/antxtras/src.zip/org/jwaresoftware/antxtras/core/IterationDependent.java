/**
 * $Id: IterationDependent.java 1034 2010-03-20 15:05:26Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

/**
 * Marker interface for any component that either exists at the
 * execution iteration scope or relies on the execution iteration
 * object to perform its responsibilities.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    api,infra
 * @see       org.jwaresoftware.antxtras.behaviors.ProjectDependent
 **/

public interface IterationDependent
{
}


/* end-of-IterationDependent.java */