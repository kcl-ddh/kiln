/**
 * $Id: DoInlineTaskSet.java 1007 2010-03-11 13:23:42Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.fixture;

import  org.apache.tools.ant.Task;
import  org.apache.tools.ant.TaskContainer;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableLibDefinition;
import  org.jwaresoftware.antxtras.ownhelpers.TaskExaminer;
import  org.jwaresoftware.antxtras.starters.TaskSet;

/**
 * A taskset that is defined as part of a standard Ant library. The taskset's nested
 * elements are <em>automatically executed</em> when the library is installed which can
 * be immediate or delayed if the library is installed using the special "antlib:" XML
 * namespace construct (typical).
 * <p>
 * Do not use a doinline taskset to replace the standard
 * <span class="src">&lt;import&gt;</span> task. Inline scriptlets are most useful
 * for adhoc decoration of existing build or test scripts where the tasks run a simple
 * fixture configuration instructions (particularly if the setup spans projects).
 * <p>
 * You should pay careful attention to the tasks you include for inline execution.
 * Generally, data object declarations, execution fixture initializers, and other
 * simple configuration tasks are the best components to include in an antlib
 * (aside from the other Ant definition tasks like presetdef and macrodef).
 * <p>
 * <b>Example Usage:</b><pre>
 *  &lt;?xml version="1.0" encoding="UTF-8"?&gt;
 *  &lt;antlib xmlns:l="ant:current"&gt;
 *    &lt;<b>l:doinline</b>&gt;
 *      &lt;l:managemessages resource="build-messages"/&gt;
 *      &lt;l:tempdir pathproperty="TMP.d" urlproperty="TMP.url"/&gt;
 *    &lt;/l:doinline&gt;
 *    ...
 *  &lt;/antlib&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    api,infra
 * @.pattern  GoF.Adapter
 * @see       org.jwaresoftware.antxtras.behaviors.AntLibFriendly
 **/

public class DoInlineTaskSet extends AssertableLibDefinition
    implements TaskContainer
{
    /**
     * Initializes a new doinline taskset instance.
     **/
    public DoInlineTaskSet()
    {
        this(AntX.fixture+"DoInlineTaskSet:");
    }



    /**
     * Initializes a new doinline taskset instance from subclass.
     * @param iam CV-label (non-null)
     **/
    public DoInlineTaskSet(String iam)
    {
        super(iam);
    }



    /**
     * Initializes this taskset's internal helper. All add
     * requests are delegated to this helper.
     */
    protected void initonce()
    {
        super.initonce();
        if (m_impl==null) {
            m_impl = new TaskSet();
            TaskExaminer.initTaskFrom(m_impl,this);
         }
    }



    /**
     * Adds a new task to this task set. The new task is
     * actually added to the underlying taskset for later execution.
     */
    public void addTask(Task task)
    {
        m_impl.addTask(task);
    }



    /**
     * Performs all of this task's nested elements.
     * @throws org.apache.tools.ant.BuildException if any nested task does
     */
    public void execute()
    {
        verifyCanExecute_("exec");
        m_impl.perform();
    }



    private TaskSet m_impl;
}

/* end-of-DoInlineTaskSet.java */