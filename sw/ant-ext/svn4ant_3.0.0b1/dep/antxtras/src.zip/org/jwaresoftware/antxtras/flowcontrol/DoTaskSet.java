/**
 * $Id: DoTaskSet.java 983 2010-02-27 12:43:10Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.parameters.FlexConditional;
import  org.jwaresoftware.antxtras.rules.RulesTk;
import  org.jwaresoftware.antxtras.starters.ConditionalTaskSet;

/**
 * Taskset that has builtin support for conditional execution. Implements
 * basic support for both the standard '<i>if</i>' and '<i>unless</i>' control
 * options as well as several other AntXtras-specific variants like 
 * '<i>ifAll</i>', '<i>ifOs</i>', '<i>true</i>', '<i>false</i>', and 
 * '<i>ifAnt</i>'. Also supports the Ant &lt;locals&gt; scoping mechanism. 
 * See the {@linkplain FlexConditional} interface for the complete list 
 * of supported execution conditions.
 * <p/>
 * <b>Example Usage:</b><pre>
 *    &lt;do test="some-condition-id"&gt;
 *        <i>[Your tasks here&#8230;]</i>
 *    &lt;/do&gt;
 *
 *    &lt;do ifAntLike=".*\1\.6.*"&gt;
 *        <i>[Your tasks here&#8230;]</i>
 *    &lt;/do&gt;
 *
 *    &lt;do ifAllTrue="a,b,c" unless="no-alpabet"&gt;
 *        <i>[Your tasks here&#8230;]</i>
 *    &lt;/do&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.5
 * @author   ssmc, &copy;2002-2005,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,infra
 **/

public class DoTaskSet extends ConditionalTaskSet
    implements FlexConditional
{
    /**
     * Initializes a new empty do taskset.
     **/
    public DoTaskSet()
    {
        this(AntX.flowcontrol+"DoTaskSet:");
    }


    /**
     * Initializes a new CV-labeled empty do taskset.
     * @param iam CV-label (non-null)
     **/
    protected DoTaskSet(String iam)
    {
        super(iam);
        setWithLocals(true);
    }



    /**
     * Initializes new configuration-delaying taskset.
     * @param iam CV-label (non-null)
     * @param delayConfigure <i>true</i> if nested tasks configured
     *        when they're actually executed
     **/
    protected DoTaskSet(String iam, boolean delayConfigure)
    {
        super(iam,delayConfigure);
        setWithLocals(true);
    }



    /**
     * Adds the if-condition-is-true to this taskset.
     * A property value is considered <i>true</i> if it
     * is one of: "true","on", or "yes".
     **/
    public void setIfTrue(String property)
    {
        m_guard.setIfTrue(property);
    }

    public void setTrue(String booleanString)
    {
        m_guard.setTrue(booleanString);
    }

    public void setFalse(String booleanString)
    {
        m_guard.setFalse(booleanString);
    }


    public void setIfAll(String properties)
    {
        m_guard.setIfAll(properties);
    }

    public void setIfAllTrue(String properties)
    {
        m_guard.setIfAllTrue(properties);
    }

    public void setIfOS(String choice)
    {
        m_guard.setIfOS(choice);
    }

    public void setIfAntLike(String version)
    {
        m_guard.setIfAntLike(version);
    }



    /**
     * Adds the unless-condition-is-true to this taskset.
     * A property value is considered <i>true</i> if it is
     * one of: "true", "on", or "yes".
     **/
    public final void setUnlessTrue(String property)
    {
        m_guard.setUnlessTrue(property);
    }


    public void setUnlessAll(String properties)
    {
        m_guard.setUnlessAll(properties);
    }

    public void setUnlessAllTrue(String properties)
    {
        m_guard.setUnlessAllTrue(properties);
    }

    public void setUnlessOS(String choice)
    {
        m_guard.setUnlessOS(choice);
    }

    public void setUnlessAntLike(String version)
    {
        m_guard.setUnlessAntLike(version);
    }


    /**
     * Assigns this taskset a named condition execution guard. If the
     * referenced condition evaluates <i>true</i> this taskset's
     * contents will be performed.
     * @param testRef reference to test definition (non-null)
     * @since JWare/AntX 0.5
     **/
    public void setCriteria(Reference testRef)
    {
        require_(testRef!=null,"setTest: nonzro test refid");
        m_conditionId = testRef;
    }



    /**
     * Synonym for {@linkplain #setCriteria(Reference) setCriteria}.
     * @param testRef reference to test definition (non-null)
     * @since JWare/AntX 0.5
     **/
    public final void setTest(Reference testRef)
    {
        setCriteria(testRef);
    }



    /**
     * Adds a disabled check to this conditional task's if conditions.
     * @param uri fixture option to check (non-null)
     * @since JWare/AntX 0.6
     **/
    public void setDisabled(String uri)
    {
        require_(uri!=null,"setDisabled- nonzro uri");
        m_guard.addIfTest(new IfDisabled(uri));
    }



    /**
     * Returns <i>true</i> if either this taskset's named condition test
     * passes or all of its individual if tests pass.
     * @return <i>true</i> if all execution conditions met
     * @since JWare/AntX 0.5
     **/
    public boolean testIfCondition()
    {
        if (m_conditionId!=null) {
            String testId = m_conditionId.getRefId();
            boolean passIf = true;
            if (!RulesTk.evalTest(testId, m_rqlink)) {
                m_guard.setLastFailure("$test:"+testId);
                passIf = false;
            }
            log("Conditional execution (test="+testId+") is "+passIf, Project.MSG_DEBUG);
            return passIf;
        }
        return m_guard.testIfCondition();
    }



    /**
     * Ensures that for conditional execution either a single named
     * condition has been defined or a combination of if/unless options.
     * @throws BuildException if a test condition has been named well
     *   as other if/unless conditions.
     * @throws BuildExceptionif a referred-to test object is not a
     *   valid condition object.
     * @since JWare/AntX 0.5
     */
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);

        if (m_conditionId!=null) {
            if (!m_guard.isEmpty()) {
                String e = getAntXMsg("flow.only.test.param",m_conditionId.getRefId());
                log(e, Project.MSG_ERR);
                throw new BuildException(e, getLocation());
            }
            RulesTk.verifyTest(m_conditionId.getRefId(), m_rqlink);
        }
    }



    private Requester m_rqlink = new Requester.ForComponent(this);
    private Reference m_conditionId;
}

/* end-of-DoTaskSet.java */
