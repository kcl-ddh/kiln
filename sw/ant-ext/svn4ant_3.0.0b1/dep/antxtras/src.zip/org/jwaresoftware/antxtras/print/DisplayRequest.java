/**
 * $Id: DisplayRequest.java 544 2008-12-27 02:21:13Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.print;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.ProjectComponent;

import  org.jwaresoftware.antxtras.behaviors.Identified;
import  org.jwaresoftware.antxtras.behaviors.Nameable;
import  org.jwaresoftware.antxtras.behaviors.Named;
import  org.jwaresoftware.antxtras.behaviors.ProjectDependent;
import  org.jwaresoftware.antxtras.behaviors.Requester;

/**
 * Information to be displayed by a {@linkplain DisplayStrategy display strategy}.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,helper
 * @see      DisplayStrategy
 **/

public final class DisplayRequest implements Nameable, ProjectDependent
{
    /**
     * Initializes a new empty display request.
     **/
    public DisplayRequest()
    {
    }


    /**
     * Initializes a new display request for given <i>thing</i>.
     * @param thing thing to be displayed
     **/
    public DisplayRequest(Object thing)
    {
        setObjectToBeDisplayed(thing);
    }


    /**
     * Initializes a new display request for given named
     * object in project.
     * @param p enclosing project
     * @param id the thing's identifier (in build script)
     * @param thing thing to be displayed
     **/
    public DisplayRequest(Project p, String id, Object thing)
    {
        setObjectToBeDisplayed(thing);

        setProject(p); //IMPORTANT:do these *after* setting obj!
        setName(id);
    }


    /**
     * Returns the thing-to-be-displayed's identifier.
     * Will return <i>null</i> if never set.
     **/
    public String getName()
    {
        return m_Id;
    }


    /**
     * Sets the thing-to-be-displayed's identifier. Use <i>null</i>
     * to reset name to default setting.
     * @param name thing's name
     **/
    public void setName(String name)
    {
        m_Id = name;
    }


    /**
     * Returns the thing-to-be-displayed. Will return <i>null</i>
     * if never set.
     **/
    public Object getObjectToBeDisplayed()
    {
        return m_thing;
    }


    /**
     * Sets the thing-to-be-displayed.
     * @param thing the ting
     * @.sideeffect (Re)Sets this request's project if thing is a ProjectComponent
     * @.sideeffect (Re)Sets this request's name  if thing is a Named thing
     **/
    public void setObjectToBeDisplayed(Object thing)
    {
        m_thing = thing;

        if (thing instanceof ProjectComponent) {
            setProject(((ProjectComponent)thing).getProject());
        }
        if (thing instanceof Identified) {//NB:ordering explicit
            setName(((Identified)thing).getId());
        } else if (thing instanceof Named) {
            setName(((Named)thing).getName());
        }
    }


    /**
     * Returns the filtering information for this request.
     * Will return <i>null</i> if never set or was reset.
     **/
    public String getFilter()
    {
        return m_filter;
    }


    /**
     * Sets the filtering information for this request. Exactly
     * how this information is used depends on the strategy being
     * used and the thing-to-be-displayed. Use <i>null</i> to
     * unset a filter for a reused request.
     * @param filter the opaque filter information
     **/
    public void setFilter(String filter)
    {
        m_filter = filter;
    }


    /**
     * Returns this request's enclosing project. Will return
     * <i>null</i> if never defined and no callback information
     * set.
     **/
    public Project getProject()
    {
        Project project = m_project;
        if (project==null && m_rqlink!=Requester.ANONYMOUS) {
            project = m_rqlink.getProject();
        }
        return project;
    }


    /**
     * Sets this request's enclosing project.
     * @param project the enclosing project
     **/
    public void setProject(Project project)
    {
        m_project = project;
        if (project!=null && m_rqlink==Requester.ANONYMOUS) {
            m_rqlink = new Requester.ForProject(project);
        }
    }



    /**
     * Returns caller information if available. If never set explicitly,
     * returns either an anonymous caller or a caller based on this
     * request's project. Never returns <i>null</i>.
     * @since JWare/AntX 0.5
     **/
    public Requester getCaller()
    {
        return m_rqlink;
    }



    /**
     * Sets this request's user's callback information.
     * @param clnt [optional] caller information.
     * @since JWare/AntX 0.5
     **/
    public void setCaller(Requester clnt)
    {
        if (clnt!=null) {
            m_rqlink = clnt;
        } else {
            m_rqlink = Requester.ANONYMOUS;
        }
    }


    private Project   m_project;
    private Object    m_thing;
    private String    m_filter;
    private String    m_Id;
    private Requester m_rqlink = Requester.ANONYMOUS;
}

/* end-of-DisplayRequest.java */
