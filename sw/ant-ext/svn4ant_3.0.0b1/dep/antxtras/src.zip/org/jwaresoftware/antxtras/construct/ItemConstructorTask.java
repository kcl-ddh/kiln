/**
 * $Id: ItemConstructorTask.java 423 2008-04-27 01:31:09Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.construct;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Nameable;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.parameters.FeedbackLevel;
import  org.jwaresoftware.antxtras.parameters.OptionalOverwriteSupport;

/**
 * Fixture configuration instruction that creates a new Ant item and installs it as
 * a top-level project reference. Unless told otherwise, a constructor will overwrite
 * an existing reference with its nested object's definition.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    impl,helper
 **/

public abstract class ItemConstructorTask extends AssertableTask
    implements Nameable, OptionalOverwriteSupport
{
    /**
     * Initializes a new item constructor instance.
     **/
    protected ItemConstructorTask(String iam)
    {
        super(iam);
    }


//  ---------------------------------------------------------------------------------------
//  Script-facing Parameters:
//  ---------------------------------------------------------------------------------------

    /**
     * Set the target reference's identifier (non-null)
     * @param dstRefId reference id to install item under (non-null)
     * @see #setHaltIfExists setHaltIfExists(&#8230;)
     **/
    public void setName(String dstRefId)
    {
        require_(dstRefId!=null, "setName- nonzro refid");
        m_toRefId = dstRefId;
    }




    /**
     * Returns the (new) target reference's identifer.
     * Returns <i>null</i> if never set and source never
     * set.
     **/
    public final String getName()
    {
        return m_toRefId;
    }



    /**
     * Sets if this task will generate a build error if the
     * destination reference id already exists within its project.
     * Trumps the 'overwrite' option.
     * @param halt <i>true</i> to throw build exception
     * @see #setName setName
     * @see #setOverwrite setOverwrite
     **/
    public void setHaltIfExists(boolean halt)
    {
        m_haltIfExists = halt ? Boolean.TRUE : Boolean.FALSE;
    }



    /**
     * Returns this task's haltifexists option. Will return
     * <i>null</i> if never set explicitly.
     * @see #isHaltIfExists()
     **/
    public final Boolean getHaltIfExistsFlag()
    {
        return m_haltIfExists;
    }



    /**
     * Returns <i>true</i> if this task will generate a build error
     * if the destination reference id already exists within its
     * project. Defaults <i>false</i> (supports overwrites).
     **/
    public final boolean isHaltIfExists()
    {
        Boolean b = getHaltIfExistsFlag();
        return b==null ? false : b.booleanValue();
    }



    /**
     * Sets if this task will overwrite an existing reference.
     * This option is ignored if the 'haltiferror' option
     * is turned on.
     * @see #setHaltIfExists
     * @param allowOverwrite <i>true</i> if can overwrite old reference
     **/
    public void setOverwrite(boolean allowOverwrite)
    {
        m_allowOverwrite = allowOverwrite ? Boolean.TRUE : Boolean.FALSE;
    }



    /**
     * Returns this task's overwrite option. Will return <i>null</i>
     * if never set explicitly.
     * @see #willAllowOverwrite()
     **/
    public Boolean getOverwriteFlag()
    {
        return m_allowOverwrite;
    }



    /**
     * Returns <i>true</i> if this task will overwrite an existing
     * reference. Defaults <i>true</i>. Ignored if 'haltiferror'
     * option is turned on.
     **/
    public final boolean willAllowOverwrite()
    {
        Boolean b = getOverwriteFlag();
        return b==null ? true : b.booleanValue();
    }



    /**
     * Tells this task how much non-diagnostic feedback to generate.
     * Really only has "loud" vs. "quiet-ish" interpretation. If
     * set quiet, this task will not issue a warning if it overwrites
     * an existing reference.
     * @param level feedback level (non-null)
     **/
    public void setFeedback(String level)
    {
        require_(level!=null,"setFeedback- nonzro level");
        FeedbackLevel fbl = FeedbackLevel.from(level);
        if (fbl==null) {
            String e = getAntXMsg("task.illegal.param.value",
                           getTaskName(), level, "feedback");
            log(e, Project.MSG_ERR);
            throw new BuildException(e, getLocation());
        }
        m_fbLevel = fbl;
    }



    /**
     * Returns this task's assigned feedback level. Will return
     * <i>Feedback.NORMAL</i> by default.
     **/
    public final FeedbackLevel getFeedbackLevel()
    {
        return m_fbLevel;
    }


    /**
     * Verifies that this task has all the destination informatin
     * it needs. By default checks that the target item's name has
     * been defined.
     * @throws BuildException if missing any required bits.
     **/
    public void verifyIsDefined()
    {
        if (getName()==null) {
            String ermsg = uistrs().get("task.needs.this.attr",
                getTaskName(),"name");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
    }



    /**
     * Verifies this task is completely defined with a target refid
     * and definition sub-element.
     * @throws BuildException if not in project or not defined properly.
     **/
    protected void verifyCanExecute_(String calr)
    {
        verifyInProject_(calr);
        verifyIsDefined();
    }


    private String  m_toRefId;
    private Boolean m_haltIfExists;//NB:false allow overwrites!
    private Boolean m_allowOverwrite;//NB:true allow overwrites!
    private FeedbackLevel m_fbLevel=FeedbackLevel.NORMAL;//NB:=>overwrite noise
}

/* end-of-ItemConstructorTask.java */