/**
 * $Id: EmptyProject.java 951 2010-01-06 02:53:37Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.filesystem;

import  java.io.File;
import  java.io.FileWriter;
import  java.io.IOException;
import  java.util.Map;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.ProjectHelper;
import  org.apache.tools.ant.Target;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.ownhelpers.TaskExaminer;

/**
 * Special project which serves as a dummy parent to components loadeds
 * independent of a parent project file. Gives explicit and unknown 
 * elements a place to call "home".
 *
 * @since     JWare/AntXtras 0.6.0 (from SAMS)
 * @author    ssmc, &copy;2004-2005,2009-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   guarded
 * @.group    impl,helper
 **/

public final class EmptyProject extends Project
{
    public static final String TARGET0 = "---no-op";


    private static final String EMPTY_ANT_FILE= 
        "<?xml version=\"1.0\"?> "+
        " <project name=\"STUB\" basedir=\".\" default=\"---no-op\"> "+
        "   <target name=\"---no-op\"/> "+
        " </project>";



    private File newAntFile(Requester clnt)
    {
        String filepath = "<n/d>";
        try {
            File dir = TempLocator.getSystemTempDir();
            File antfile = AntXFixture.fileUtils().createTempFile("EmptyProject",".xml",dir,true,false);
            filepath = antfile.getPath();
            FileWriter w = new FileWriter(antfile);
            w.write(EMPTY_ANT_FILE);
            w.flush();
            w.close();
            return antfile;
        }
        catch (IOException ioX) {
            String error = AntX.uistrs().get("fixture.emptyproject.cant",
                     filepath, ioX.getMessage());
            throw new BuildException(error,ioX,clnt.getLocation());
        }
    }



    /**
     * Creates a new fully initialized empty project.
     * @param clnt caller (non-null)
     **/
    public EmptyProject(Requester clnt)
    {
        init();
        File myini = newAntFile(clnt);
        setUserProperty("ant.file", myini.getAbsolutePath());
        ProjectHelper ph = ProjectHelper.getProjectHelper();
        ph.parse(this,myini);
    }



    /**
     * Creates a new custom-named, fully initialized empty project.
     * @param name the new project's name (non-null)
     * @param clnt caller (non-null)
     **/
    public EmptyProject(String name, Requester clnt)
    {
        this(clnt);
        setName(name);
    }



    /**
     * Utility method to extract the default (dummy) target of an
     * empty or otherwise private project.
     * @param project the project (non-null)
     * @return the default target or <i>null</i> if cannot determine
     **/
    public static final Target getDefaultTarget(Project project)
    {
        Target t = null;
        Map all = project.getTargets();
        if (project.getDefaultTarget()!=null) {
            t = (Target)all.get(project.getDefaultTarget());
        }
        if (t==null) {
            t = (Target)all.get(TARGET0);
        }
        return t;
    }



    /**
     * Utility method to create or extract a stub empty target
     * in a project. The empty target is created once and returned
     * for every subsequent retrieval. Never returns <i>null</i>.
     * @param project the project (non-null)
     * @return the stub empty target (non-null)
     **/
    public static final Target getEmptyTarget(Project project)
    {
        Map all = project.getTargets();
        Target t = (Target)all.get(TARGET0);
        if (t==null) {
            t = TaskExaminer.newStubTarget(project);
            t.setName(TARGET0);
            project.addOrReplaceTarget(t);
            AntX.verify_(all.containsKey(TARGET0),
                AntX.fixture+"EmptyProject:","newEmptyTarget- installed");
        }
        return t;
    }



    /**
     * Utility method to use a requester's target or if none, create
     * or extract a stub empty target in a project. The empty target is
     * created only if the caller has not provided a source target.
     * Never returns <i>null</i>.
     * @param project the project (non-null)
     * @param clnt call-controls (non-null)
     * @return caller's source target or the stub empty target (non-null)
     **/
    public static final Target getEmptyTarget(Project project, Requester clnt)
    {
        Target t = clnt.getSourceTarget();
        if (t==null) {
            t = getEmptyTarget(project);
        }
        return t;
    }

}

/* end-of-EmptyProject.java */