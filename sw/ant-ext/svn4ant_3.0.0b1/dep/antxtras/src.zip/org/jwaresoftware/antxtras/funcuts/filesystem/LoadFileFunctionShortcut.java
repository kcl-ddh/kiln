/**
 * $Id: LoadFileFunctionShortcut.java 1038 2010-03-20 19:03:33Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.filesystem;

import  java.io.BufferedInputStream;
import  java.io.File;
import  java.io.FileInputStream;
import  java.io.IOException;
import  java.io.InputStreamReader;
import  java.io.Reader;
import  java.util.Vector;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.filters.util.ChainReaderHelper;
import  org.apache.tools.ant.types.FilterChain;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.InputFileLoader;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that loads a file's contents as its value. Shortcut for the
 * standard Ant <span class="src">&lt;loadfile&gt;</span> task. The general format
 * of the URI is:
 * <span class="src">$loadfile:path[?filterchainref]</span>. The path will be resolved
 * relative to the uri's owning project if necessary. The optional filterchainref can
 * refer to an existing Ant <span class="src">&lt;filterchain&gt;</span> data type.
 * <p>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;svn:prop action="revedit" revision="${build.rev}" &#8230;&gt;
 *     &lt;property name="longversion" value="${build.longversion}"/&gt;
 *     &lt;property name="changelog" value="${<b>$loadfile:</b>${changelogs}}"/&gt;
 *
 * <b>2)</b> -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="loadfile"
 *           value="${ojaf}.filesystem.LoadFileFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.6
 * @author   ssmc, &copy;2005-2006,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   api,helper
 **/
public final class LoadFileFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Maximum file size we will load: {@value} bytes.
     */
    public static final int MAXSIZE= 1000*1024/*1MB*/;



    /**
     * Initializes a new loadfile funcut handler.
     **/
    public LoadFileFunctionShortcut()
    {
        super();
    }



    /**
     * Returns the contents of a (filtered) file as the funcut's
     * value. Returns <i>null</i> if named file is missing or is
     * larger than {@linkplain #MAXSIZE} bytes.
     * @param uriFragment the user's uri (non-null)
     * @param fullUri the uri including scheme information (non-null)
     * @param clnt caller information (non-null)
     * @throws BuildException if cannot load file and funcut haltiferror
     *         option is enabled.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        final Project P = clnt.getProject();
        String path = uriFragment;
        FilterChain filterchain = null;

        int nl = Project.MSG_WARN;
        if (isHaltIfError(clnt)) {
            nl = Project.MSG_ERR;
        }

        int i = uriFragment.indexOf(SCHEME_DELIMITER);
        if (i>=0) {
            path = uriFragment.substring(0,i++);
            if (i<uriFragment.length()) {
                String fc = Tk.resolveString(P,uriFragment.substring(i),true);
                filterchain = filterchain(fc,nl,P,clnt);
            }
        }
        path = Tk.resolveString(P,path,true);
        String value=null;
        try {
            value = loadFile(path,filterchain,clnt);
        } catch(RuntimeException anyX) {
            clnt.problem(Tk.messageFrom(anyX),nl);
            if (nl!=Project.MSG_WARN) {
                throw anyX;
            }
        } catch(IOException ioX) {
            clnt.problem(Tk.messageFrom(ioX),nl);
            if (nl!=Project.MSG_WARN) {
                throw new BuildException(ioX,clnt.getLocation());
            }
        }
        return value;
    }




    /**
     * Work to load the file. Modeled after the &lt;loadfile&gt; Ant
     * task to maintain compatibility.
     * @param path path of file to load (non-null)
     * @param filterchain [optional] filters for file as its read
     * @param clnt caller information (non-null)
     * @return file's contents or null if file missing or too big.
     * @throws IOException if unable to load file
     **/
    private String loadFile(String path, FilterChain filterchain, Requester clnt)
        throws IOException
    {
        File f = new File(path);
        if (!f.exists() || !f.isFile()) {
            String w = AntX.uistrs().get(Errs.FNF,path);
            clnt.problem(w,Project.MSG_WARN);
            return null;
        }
        long flength = f.length();
        if (flength==0L) {
            return "";
        }
        long maxsize = maxsize(clnt);
        if (flength>maxsize) {
            String w = AntX.uistrs().get("valueuri.file.toobig",path,""+maxsize+"bytes");
            clnt.problem(w,Project.MSG_WARN);
            return null;
        }
        if (filterchain==null) {
            return InputFileLoader.loadString(f);
        }
        FileInputStream fis= new FileInputStream(f);
        try {
            Reader ir= new InputStreamReader(new BufferedInputStream(fis));
            ChainReaderHelper crh = new ChainReaderHelper();
            crh.setProject(clnt.getProject());
            crh.setBufferSize((int)flength);
            crh.setPrimaryReader(ir);
            Vector v = new Vector();
            v.add(filterchain);
            crh.setFilterChains(v);
            return crh.readFully(crh.getAssembledReader());

        } finally {
            Tk.closeQuietly(fis);
        }
    }



    /**
     * Determine the filterchain to apply to loaded file. If the named reference
     * does not exist or is not a filterchain, the global "haltiferror" setting
     * for valueuri handlers determines if we barf or not.
     * @param fc filterchain refid
     * @param nl noise level (ERR to barf)
     * @param P project we're in (non-null)
     * @param clnt callback info (non-null)
     * @return filterchain or null if none (or couldn't find/get).
     **/
    private FilterChain filterchain(String fc, int nl, final Project P, Requester clnt)
    {
        FilterChain filterchain=null;
        try {
            filterchain = (FilterChain)FixtureExaminer.getReferencedObject(P,clnt,fc,FilterChain.class);
        } catch(BuildException notfoundX) {
            if (nl==Project.MSG_ERR) {
                throw notfoundX;
            }
        }
        if (filterchain!=null) {
            FilterChain ref = new FilterChain();
            ref.setProject(P);
            ref.setRefid(LocalTk.referenceFor(fc,P));
            filterchain = ref;
        }
        return filterchain;
    }



    /**
     * Returns the maximum size of any file to be loaded. Facilitates 
     * testing of limit code where smaller limit can be specified 
     * per project. Controlled by property 
     * "<i>&lt;config&gt;</i>&#46;defaults&#46;loadfile&#46;maxsize".
     * @param clnt caller (non-null)
     * @return maximum size in bytes
     **/
    private long maxsize(Requester clnt)
    {
        String override = clnt.getProject().getProperty
            (Iteration.configId()+".defaults.loadfile.maxsize");
        if (override!=null) {
            return Tk.integerFrom(override,MAXSIZE);
        }
        return MAXSIZE;
    }
}


/* end-of-LoadFileFunctionShortcut.java */
