/**
 * $Id: BuildListenerSkeleton.java 410 2008-04-20 17:33:55Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.starters;

import  org.apache.tools.ant.BuildEvent;
import  org.apache.tools.ant.SubBuildListener;

/**
 * Stub implementation of a Ant build listener.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,helper
 **/

public abstract class BuildListenerSkeleton
    implements SubBuildListener
{
    /**
     * Initializes a new build lister stub.
     **/
    protected BuildListenerSkeleton()
    { }


    /**
     * Called before any targets started; does nothing.
     **/
    public void buildStarted(BuildEvent event)
    { }


    /**
     *  Called after the last target finished; does
     * nothing.
     **/
    public void buildFinished(BuildEvent event)
    { }


    /**
     * Called before any sub-build targets started;
     * does nothing.
     * @since JWare/AntX 0.5
     **/
    public void subBuildStarted(BuildEvent event)
    { }


    /**
     * Called after the last sub-build target finished;
     * does nothing.
     * @since JWare/AntX 0.5
     **/
    public void subBuildFinished(BuildEvent event)
    { }



    /**
     * Called when a target is started; does nothing.
     **/
    public void targetStarted(BuildEvent event)
    { }


    /**
     * Called after a target has finished; does nothing.
     **/
    public void targetFinished(BuildEvent event)
    { }


    /**
     * Called when a task is started; does nothing.
     **/
    public void taskStarted(BuildEvent event)
    { }


    /**
     * Called when a task has finished; does nothing.
     **/
    public void taskFinished(BuildEvent event)
    { }


    /**
     *  Called whenever a message is logged; does nothing.
     **/
    public void messageLogged(BuildEvent event)
    { }
}

/* end-of-BuildListenerSkeleton.java */
