/**
 * $Id: ConditionFunctionShortcuts.java 1037 2010-03-20 18:35:28Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.apache.tools.ant.Task;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.InstanceFactory;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut handler that returns the string "<span class="src">true</span>" 
 * or "<span class="src">false</span>" based on the inlined short hand condition's
 * result. Will return <i>null</i> if the named condition is not recognized. This
 * hander is not installed by default; you must explicitly install
 * it as shown in the examples section (typically done by AntXtras install antlib).
 * <p/>
 * However you install this handler, you can only use the AntXtras-defined URI 
 * scheme (condition) names. See the full declaration file
 * <span class="src">org/jwaresoftware/antxtras/funcuts/antlib.xml</span> for a 
 * listing of all the recognized short hand condition names (of course, you could
 * just read this source file also).
 * <p/>
 * <b>Example Usage:</b><pre>
 *  <b>1)</b>-- Misc Shorthand Conditions --
 *  &lt;do true="${<b>$isantversion:</b>^.*version 1\.6.*"&gt;...
 *  &lt;domatch value="${<b>$allsettrue:</b>metrics.enabled,maven.enabled}"&gt;...
 *  &lt;property name="vars.enabled" value="${<b>$filenotempty:</b>${vars.f}}"/&gt;
 *
 *  <b>2)</b>-- To Install and Enable --
 *  &lt;managefuncuts action="enable"&gt;
 *     &lt;parameter name="isset"
 *           value="${ojac}.ConditionFunctionShortcuts"/&gt;
 *     &lt;parameter name="isnotset"
 *           value="${ojac}.ConditionFunctionShortcuts"/&gt;
 *     ...<i>[All other standard names and your own custom ones if desired]</i>
 *  &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    api,helper
 * @see       URIable
 * @see       org.jwaresoftware.antxtras.rules.RuleFunctionShortcut
 **/

public class ConditionFunctionShortcuts extends FunctionShortcutSkeleton
{
    /**
     * Set up the map of name to condition evaluators. Some of
     * these names are duplicates and remain for backward 
     * compatibility's sake (just a boat-load o' scripts would
     * need updating...bleech). For v3 we need to trim to list
     * to a smaller and consistent set (SSMC)
     */
    private static InstanceFactory m_IF= new InstanceFactory();
    static {
        m_IF.put("$isset:",IsSet.class);
        m_IF.put("$isnotset:",IsNotSet.class);
        m_IF.put("$issettrue:",IsSetTrue.class);
        m_IF.put("$allset:",AllSet.class);
        m_IF.put("$allsettrue:",AllSetTrue.class);
        m_IF.put("$anyset:",AnySet.class);
        m_IF.put("$anysettrue:",AnySetTrue.class);
        m_IF.put("$noneset:",NoneSet.class);
        m_IF.put("$isboolean:",IsBoolean.class);
        m_IF.put("$isnumber:",IsNumber.class);
        m_IF.put("$isnotwhitespace:",IsNotWhitespace.class);
        m_IF.put("$isreference:",IsReference.class);
        m_IF.put("$isantversion:",IsAntVersion.class);
        m_IF.put("$isfile:",IsFile.class);
        m_IF.put("$filenotempty:",FileNotEmpty.class);
        m_IF.put("$isdirectory:",IsDirectory.class);
        m_IF.put("$isresource:",IsResource.class);
        m_IF.put("$isclass:",IsClass.class);

        //B- shorter-shortcuts [KEEP for 3.x]
        m_IF.put("$notset:",IsNotSet.class);
        m_IF.put("$isbool:",IsBoolean.class);
        m_IF.put("$notwhitespace:",IsNotWhitespace.class);
        m_IF.put("$isref:",IsReference.class);
        m_IF.put("$isdir:",IsDirectory.class);
        m_IF.put("$isres:",IsResource.class);
        m_IF.put("$fne:",FileNotEmpty.class);
    }



    /**
     * Initializes a new condition function shortcuts handler.
     * Only the standard condition names are supported by this
     * handler.
     * @see #addMapping addMapping(&#8230;)
     **/
    public ConditionFunctionShortcuts()
    {
    }



    /**
     * Programmatic extension point that allows subclasses to add
     * own condition names and condition classes.
     * @param name protocol marker string (non-null)
     * @param claz URIable class (non-null)
     * @throws ClassCastException if <span class="src">claz</span> is not
     *  assign-compatible with {@linkplain URIable}.
     **/
    public static void addMapping(String name, Class claz)
    {
        AntX.require_(name!=null && claz!=null,
            AntX.conditions+"FunctionShortcuts:", "addMapin- nonzro args");

        if (!URIable.class.isAssignableFrom(claz)) {
            throw new ClassCastException(claz.getName());
        }

        synchronized(m_IF) {
            m_IF.put(name,claz);
        }
    }



    /**
     * Common work that determines and evaluates the condition
     * represented by the function shortcut.
     * @param uriFragment resource information from URI (non-null)
     * @param fullUri the full shortcut URI (non-null)
     * @param clnt caller information (non-null)
     * @return result or <i>null</i> if did not find match.
     **/
    protected Boolean eval(String uriFragment, String fullUri, Requester clnt)
    {
        int i= fullUri.indexOf(':');
        if (i>0) {
            String which= fullUri.substring(0,++i);
            if (i<fullUri.length()) {
                Object c= m_IF.newInstance(which);
                if (c instanceof URIable) {
                    clnt.getProject().setProjectReference(c);
                    if (c instanceof Task) {
                        Task t = (Task)c;
                        t.setLocation(clnt.getLocation());
                        t.init();
                    }
                    String fragment = fullUri.substring(i);
                    fragment = Tk.resolveString(clnt.getProject(),fragment,true);
                    ((URIable)c).xsetFromURI(fragment);
                    return ((URIable)c).eval() ? Boolean.TRUE : Boolean.FALSE;
                }
            }
        }
        return null;
    }



    /**
     * Returns either the string "<span class="src">true</span>" or
     * "<span class="src">false</span>" for a known condition. Otherwise
     * returns whatever the default value for an unrecognized URI would
     * be (usually <i>null</i>).
     * @return "true" or "false" if uri described a known condition,
     *         otherwise <i>null</i>.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        Boolean B = eval(uriFragment, fullUri, clnt);
        if (B!=null) {
            return String.valueOf(B.booleanValue());
        }
        return getDefaultValue(fullUri,clnt);
    }
}


/* end-of-ConditionFunctionShortcuts.java */