/**
 * $Id: EmptyLogs.java 410 2008-04-20 17:33:55Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.capture;

import  org.jwaresoftware.antxtras.core.NoiseLevel;

/**
 * An always-empty placeholder for a LogsRecorder.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2003,2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   impl,helper
 * @.pattern JWare.NullProxy
 **/

public final class EmptyLogs implements LogsRecorder
{
    /**
     * VM/ClassLoader shareable instance of an EmptyLogs object.
     **/
    public static final EmptyLogs INSTANCE= new EmptyLogs();



    /**
     * Initializes new instance of an EmptyLogs object.
     **/
    public EmptyLogs()
    {
    }


    /**
     * Always returns <i>false</i> since this recorder
     * never records any messages.
     * @param nl noise level (non-null)
     **/
    public boolean isImportant(NoiseLevel nl)
    {
        return false;
    }


    /**
     * Always returns an empty string since this recorder
     * records nothing.
     **/
    public String copyOfImportantLogs()
    {
        return "";
    }


    /**
     * Always returns an empty string since this recorder
     * records nothing.
     **/
    public String copyOfAllLogs()
    {
        return "";
    }


    /**
     * Does nothing because nothing's ever recorded.
     **/
    public void clearLogs()
    {
    }
}

/* end-of-LogsRecorder.java */
