/**
 * $Id: ExternalPropertyDef.java 415 2008-04-22 02:08:37Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  java.util.Map;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.FlexString;

/**
 * Special flex value that has a predetermined <em>target</em> value. All of this
 * items modifiers (like trimming) are still applied to target string.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,helper
 **/

public final class ExternalPropertyDef extends FlexString
{
    /**
     * Initializes a new undefined predef value. This item's
     * target string must be specified before it is used.
     **/
    public ExternalPropertyDef()
    {
        super();
        setIsProperty(true);
    }


    /**
     * Initializes a new attached but undefined predef value.
     * This item's target string must be specified before it
     * is used.
     * @param P enclosing project (non-null)
     **/
    public ExternalPropertyDef(Project P)
    {
        this();
        require_(P!=null,"ctor- nonzro proj");
        setProject(P);
    }


    /**
     * Defines both this item's source and target strings.
     * @param definition the source (key) and target (value)
     **/
    public void set(Map.Entry definition)
    {
        require_(definition!=null,"set- nonzro defn");
        set(definition.getKey().toString());
        setTargetString(definition.getValue().toString());
    }


    /**
     * Defines this item's target string.
     * @param value the target value
     **/
    public void setTargetString(String value)
    {
        m_predefValue = value;
    }


    /**
     * Returns the predefined source string. The source is
     * not resolved in anyway.
     **/
    public String sourceString(Project P)
    {
        return get();
    }


    /**
     * Returns the predefined value string. The source is not
     * used to retrieve any information from the fixture.
     **/
    public String targetString(Project P, String source)
    {
        return m_predefValue;
    }


    private String m_predefValue;
}

/* end-of-ExternalPropertyDef.java */
