/**
 * $Id: EqualFields.java 418 2008-04-26 18:25:00Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.ProjectComponent;
import  org.apache.tools.ant.taskdefs.condition.Condition;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableProjectComponent;
import  org.jwaresoftware.antxtras.helpers.Strings;

/**
 * Diagnostics condition that verifies two fields on two different objects
 * are equivalent. Can also be configured to verify that a single object
 * field is <i>null</i>.
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,test,helper
 * @see      AssertTask
 **/

final class EqualFields extends AssertableProjectComponent
    implements Condition
{
    /**
     * Initializes a new EqualFields condition.
     **/
    EqualFields()
    {
        super(AntX.conditions);
        initFields();
    }


    /**
     * Initializes a new CV-labeled EqualFields condition.
     * @param iam CV-label (non-null)
     **/
    EqualFields(String iam)
    {
        super(iam);
        initFields();
    }


    /**
     * Sets the name of the first reference.
     * @param refid reference identifier (non-null)
     **/
    void setItem1(String refid)
    {
        require_(refid!=null,"setItem1- nonzro refid");
        m_item1 = refid;
    }


    /**
     * Returns reference identifier for first item. Returns
     * <i>null</i> if never set.
     **/
    String getItem1()
    {
        return (m_item1==__NULL1) ? null : m_item1;
    }


    /**
     * Sets the name of the second reference. Pass the string
     * "null" for null comparison.
     **/
    void setItem2(String refid)
    {
        if (refid==null || Strings.NULL.equalsIgnoreCase(refid)) {
            m_item2 = null;
        } else {
            m_item2 = refid;
        }
    }


    /**
     * Returns reference identifier for second item. Returns
     * <i>null</i> if never set. Returns the string "null" if
     * will used as <i>null</i>.
     **/
    String getItem2()
    {
        return (m_item2==__NULL2) ? null :
            (m_item2==null) ? Strings.NULL : m_item2;
    }


    /**
     * Returns project field for given reference item. Can be easily
     * genericized to look for any field if this is ever useful.
     * @throws BuildException if field not properly specified
     **/
    private Object getItemField(String refid, boolean refRequired)
    {
        if (refid==null || refid==__NULL1 || refid==__NULL2) {
            if (refRequired) {
                String ermsg = uistrs().get("brul.assert.samefield.need.item");
                log(ermsg,Project.MSG_ERR);
                throw new BuildException(ermsg);
            }
            return refid==null ? null : getProject();
        }
        //NB: Would generalize to use reflection here (ssmc)\\
        Object obj = getProject().getReference(refid);

        if (!(obj instanceof ProjectComponent)) {
            String ermsg = uistrs().get("brul.assert.samefield.missing.field",
                                        refid, "Project");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg);
        }
        return ((ProjectComponent)obj).getProject();
    }


    /**
     * Returns <i>true</i> if the two objects have equivalent projects.
     * @throws BuildException if not properly defined
     **/
    public boolean eval()
    {
        verifyInProject_("eval");
        Object P1 = getItemField(m_item1,true);
        Object P2 = getItemField(m_item2,false);
        return equalObjects(P1,P2,true);
    }


    /**
     * Returns <i>true</i> if a equals b. Handles nulls. Does not handle
     * Java arrays.
     **/
    static boolean equalObjects(Object a, Object b, boolean identical)
    {
        if (a==null) {
            return b==null;
        }
        if (b==null) {
            return false;
        }
        if (a==b) {
            return true;
        }
        return identical ? false : a.equals(b);
    }


    /**
     * Allows us to initializes the two fields to something that isn't
     * <i>null</i> but that won't match anything user likely to specify.
     **/
    private static final String __NULL1, __NULL2; //NB: make different
    static {
        StringBuffer sb = new StringBuffer
            (String.valueOf(System.identityHashCode(EqualFields.class)));
        sb.append("_");
        __NULL1 = sb.substring(0);
        sb.append("_");
        __NULL2 = sb.substring(0);
        sb = null;
    }
    private void initFields()
    {
        m_item1 = __NULL1;
        m_item2 = __NULL2;
    }

    private String m_item1, m_item2;
}

/* end-of-EqualFields.java */
