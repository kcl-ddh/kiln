/**
 * $Id: Empties.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.helpers;

import  java.util.Collections;
import  java.util.List;
import  java.util.Map;
import  java.util.Properties;

/**
 * Unmodifiable proxies for various types of objects that are not <i>null</i>.
 *
 * @since     JWare/internal 2.0
 * @author    ssmc, &copy;2007-2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    impl,helper
 **/

public class Empties
{
    /** Empty string. **/
    public static final String STRING="";

    /** Empty, immutable List. **/
    public static final List LIST= Collections.EMPTY_LIST;

    /** Empty, immutable Map. **/
    public static final Map MAP= Collections.EMPTY_MAP;

    /** Empty, immutable Properties. **/
    public static final Properties PROPERTIES= new UnmodifiableProperties();

    /** Empty array of Objects. **/
    public static final Object[] EMPTY_OBJECT_ARRAY= new Object[0];

    /** Empty array of Class references. **/
    public static final Class[] EMPTY_CLASS_ARRAY= new Class[0];

    /** Empty array of Strings. **/
    public static final String[] EMPTY_STRING_ARRAY= new String[0];


    protected Empties()
    {/*to permit sub-system specific extensions*/}
}


/* end-of-Empties.java */
