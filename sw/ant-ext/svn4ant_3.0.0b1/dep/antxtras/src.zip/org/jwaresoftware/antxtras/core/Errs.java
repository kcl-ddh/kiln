/**
 * $Id: Errs.java 947 2010-01-05 17:14:57Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

/**
 * Collection of <em>very</em> frequently used AntXtras error messages.
 *
 * @since    JWare/AntX 0.6.0
 * @author   ssmc, ssmc, &copy;2007-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,helper
 **/
public class Errs
{
    /** Template for: {@value}. */
    public static final String CLONE_BROKEN_MSGID= "cv.clone.broken";
    public static final String CloneInternalError() {
        return AntX.uistrs().get(CLONE_BROKEN_MSGID);
    }

    /** Tasks of type "&#123;0&#125;" require a "&#123;1&#125;" attribute. */
    public static final String TNTA  = "task.needs.this.attr";
    public static final String NeedsThisAttribute(String type, String name) {
        return AntX.uistrs().get(TNTA,type,name);
    }

    /** Items of type "&#123;0&#125;" do not permit the value "&#123;1&#125;" 
     * for the " &#123;2&#125;" parameter. */
    public static final String TIPV  = "task.illegal.param.value";
    public static final String IllegalParameterValue(String source, String param, String badvalue) {
        return AntX.uistrs().get(TIPV,source,badvalue,param);
    }

    /** Can only specify either a "&#123;0&#125;" or a "&#123;1&#125;" parameter. */
    public static final String TOOOA = "task.one.or.other.attr";
    public static final String OneOrOtherAttribute(String one, String other) {
        return AntX.uistrs().get(TOOOA,one,other);
    }

    /** Template for: {@value}. */
    public static final String TOOSI = "taskset.only.one.specialtask";
    
    /** Can only specify ONE of the attributes "&#123;0&#125;" as a parameter. */
    public static final String TOOA = "task.only.oneof.attr";
    public static final String OnlyOneOfAttributeSet(String set) {
        return AntX.uistrs().get(TOOA,set);
    }

    /** Template for: {@value}. */
    public static final String FNF   = "task.err.filenotfound";
    
    /** The &#123;0&#125; task allows only one "&#123;1&#125;" element. */
    public static final String OST   = "task.one.specialtask";
    public static final String OnlyOneSpecialElement(String source, String element) {
        return AntX.uistrs().get(OST,source,element);
    }

    /** The reference "&#123;0&#125;" is not of a compatible type 
     * (want "&#123;1&#125;", have "&#123;2&#125;")*/
    public static final String TBR = "task.bad.refid";
    public static final String BadReferenceId(String refid, String want, String have) {
        return AntX.uistrs().get(TBR,refid,want,have);
    }

    /** The reference "&#123;0&#125;" does not exist. */
    public static final String TMR = "task.missing.refid";
    public static final String MissingReferenceId(String refid) {
        return AntX.uistrs().get(TMR,refid);
    }

    /** Tasks of type "&#123;0&#125;" do not support the "&#123;1&#125;" attribute(s). */
    public static final String TUA = "task.unsupported.attr";
    public static final String UnsupportedAttribute(String source, String attr) {
        return AntX.uistrs().get(TUA,source,attr);
    }

    /** Tasks of type "{0}" cannot be nested in {1} tasks. */
    public static final String UnsupportedNestedElement(String source, String element) {
        return AntX.uistrs().get("taskset.nested.task.disallowed",element,source);
    }

    /** The update property(&#123;0&#125;) already exists; it cannot be overwritten. */
    public static final String PropertyExists(String property) {
        return AntX.uistrs().get("task.warn.property.exists",property);
    }

    /** The new refid(&#123;0&#125;) belongs to an existing reference. */
    public static final String ReferenceExists(String refid) {
        return AntX.uistrs().get("task.warn.refid.exists",refid);
    }

    /** Can only specify one of the attributes: property, variable, or reference. */
    public static final String TooManyFlexibleAttributes() {
        return AntX.uistrs().get("task.too.many.flex.attrs");
    }

    /** The current thread's &#123;0&#125; stack has been fatally corrupted. */
    public static final String FixtureOverlayContextStackCorrupted(String fxid) {
        return AntX.uistrs().get("context.stack.corrupted",fxid);
    }

    protected Errs()
    {}
}


/* end-of-Errs.java */
