/**
 * $Id: PropertiesPrinter.java 545 2008-12-28 14:24:10Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.print;

import  java.io.PrintStream;
import  java.util.Enumeration;
import  java.util.Properties;

/**
 * Helper to print a properties object without encoding. Useful for a diagnostic
 * view of a properties object (as opposed to a store-it view).
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    impl,helper
 **/

public final class PropertiesPrinter
{
    public final static void print(Properties p, PrintStream out)
    {
        if (p==null) {
            out.println("NULL");
        } else {
            Enumeration names = p.propertyNames();
            while (names.hasMoreElements()) {
                String property = names.nextElement().toString();
                String value = p.getProperty(property);
                out.print(property);
                out.print("=");
                out.println(value);
            }
        }
    }

    public final static void header(String name, Object value, PrintStream out)
    {
        out.print(name);
        out.print(": ");
        out.println(value);
    }

    public final static void line(String name, Object value, PrintStream out)
    {
        out.print(name);
        out.print("=");
        out.println(value);
    }

    private PropertiesPrinter() { }
}

/* end-of-PropertiesPrinter.java */
