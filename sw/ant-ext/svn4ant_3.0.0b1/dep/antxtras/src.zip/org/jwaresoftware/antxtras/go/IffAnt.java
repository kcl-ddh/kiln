/**
 * $Id: IffAnt.java 962 2010-01-10 22:24:01Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.go;

import  org.apache.tools.ant.MagicNames;
import  org.apache.tools.ant.Main;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.util.regexp.RegexpMatcher;
import  org.apache.tools.ant.util.regexp.RegexpMatcherFactory;

import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Implementation of the general <i>if-ant</i> test for all conditional components.
 * The <span class="src">IffAnt</span> criteria passes if the current Ant runtime's
 * version string matches the given regular expression.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004-2005,2007-2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,helper
 * @.pattern GoF.Strategy
 * @see      Go
 * @see      IffOs
 * @see      org.jwaresoftware.antxtras.parameters.PlatformConditional PlatformConditional
 **/

public final class IffAnt
{
    private static final RegexpMatcherFactory REMFactory =
        new RegexpMatcherFactory();

    /**
     * Returns <i>true</i> if the version information stored in
     * the given property matches the version regular expression.
     * @param pattern version pattern (non-null)
     * @param property the name of the property storing version info
     * @param P project from which properties read
     * @param ifNot <i>true</i> if test should be for no-match
     **/
    public static boolean pass(String pattern, String property,
                               Project P, boolean ifNot)
    {
        if (Tk.isWhitespace(pattern) || Tk.isWhitespace(property)) {
            return ifNot ? true : false;
        }
        pattern = Tk.resolveString(P,pattern);

        RegexpMatcher re = REMFactory.newRegexpMatcher(P);
        re.setPattern(pattern);

        String setting = null;
        if (P!=null) {
            setting = P.getProperty(property);
        }
        if (setting==null) {//NB:can happen in test|in-early-load environments!
            setting = Main.getAntVersion();
        }

        boolean is = re.matches(setting);
        re= null;
        return ifNot ? !is : is;
    }


    /**
     * Returns <i>true</i> if the current Ant runtime's version
     * information matches the version regular expression.
     * @param pattern version pattern (non-null)
     * @param P project from which properties read
     * @param ifNot <i>true</i> if test should be for no-match
     **/
    public static boolean pass(String pattern, Project P, boolean ifNot)
    {
        return pass(pattern, MagicNames.ANT_VERSION, P, ifNot);
    }


    /**
     * Execute test for an "if-antLike" conditional parameter.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsLike extends Go.TestSkeleton {
        public IsLike() {
        }
        public IsLike(String pattern) {
            super(pattern);
        }
        public boolean pass(Project P) {
            verifyInited();
            return IffAnt.pass(getParameter(),P,false);
        }
        public String getParameterName() {
            return "ifAntLike";
        }
    }


    /**
     * Execute test for an "unless-antLike" conditional parameter.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsNotLike extends Go.TestSkeleton {
        public IsNotLike() {
        }
        public IsNotLike(String pattern) {
            super(pattern);
        }
        public boolean pass(Project P) {
            verifyInited();
            return IffAnt.pass(getParameter(),P,true);
        }
        public String getParameterName() {
            return "unlessAntLike";
        }
    }


    /**
     * Execute test for an "if-antLike-property" conditional parameter.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsLikeProperty extends Go.TestSkeleton {
        public IsLikeProperty() {
        }
        public IsLikeProperty(String pattern, String property) {
            super(pattern);
            setSourceProperty(property);
        }
        public boolean pass(Project P) {
            verifyInited();
            return IffAnt.pass(getParameter(),m_versionProperty,P,false);
        }
        public String getParameterName() {
            return "ifAntLikeProperty";
        }
        public void setSourceProperty(String property)
        {
            m_versionProperty = property;
        }
        private String m_versionProperty= MagicNames.ANT_VERSION;
    }


    /**
     * Prevent; only helpers public.
     **/
    private IffAnt() {
    }
}

/* end-of-IffAnt.java */
