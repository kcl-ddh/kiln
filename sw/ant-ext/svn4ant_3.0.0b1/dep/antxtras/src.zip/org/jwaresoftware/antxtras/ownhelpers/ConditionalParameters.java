/**
 * $Id: ConditionalParameters.java 410 2008-04-20 17:33:55Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.ownhelpers;

import  java.util.Iterator;
import  java.util.Map;
import  java.util.Properties;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.helpers.GenericParameters;
import  org.jwaresoftware.antxtras.helpers.InnerNameValuePair;
import  org.jwaresoftware.antxtras.parameters.Conditional;

/**
 * Extension of standard {@linkplain GenericParameters GenericParameters}
 * that supports
 * {@linkplain ConditionalInnerNameValuePair conditional parameters}.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    impl,helper
 * @see       ConditionalInnerNameValuePair
 **/

public final class ConditionalParameters extends GenericParameters
{
    /**
     * Initializes a new empty parameters collection bean.
     **/
    public ConditionalParameters()
    {
    }



    /**
     * Initializes a new empty parameters collection bean
     * associated with project.
     * @param project this parameter object's enclosing project
     **/
    public ConditionalParameters(Project project)
    {
        setProject(project);
    }



    /**
     * Returns an independent map of this collection's
     * name-value items. The returned map contains the
     * {@linkplain InnerNameValuePair} items not excluded by their
     * if/unless constraints.
     * @param P [optional] project used to resolve property references.
     **/
    public Map copyOfParameterObjects(Project P)
    {
        if (P==null) {
            P = getProject();
        }
        Map copy = super.copyOfParameterObjects();
        if (!copy.isEmpty()) {
            Iterator itr = copy.values().iterator();
            while (itr.hasNext()) {
                InnerNameValuePair pair = (InnerNameValuePair)itr.next();
                if (pair instanceof Conditional) {
                    if (!OptionalExecuteHelper.include(P,(Conditional)pair)) {
                        itr.remove();
                    }
                }
            }
        }
        return copy;
    }



    /**
     * Shortcut for {@linkplain #copyOfParameterObjects(Project)
     * copyOfParameterObjects(Project)} using this item's own project
     * to resolve references.
     */
    public Map copyOfParameterObjects()
    {
        return copyOfParameterObjects(null);
    }



    /**
     * Returns an independent Properties map of this collection's
     * name-value items as simplified name-stringvalue pairs.
     * The returned map contains the item names and string
     * values of those items not excluded by their if/unless constraints.
     * Handles hetergeneous items fine.
     * @param P [optional] project used to resolve property references.
     * @param altForm alternative form of property references allowed.
     **/
    public Properties copyOfSimpleKeyValues(final Project P, boolean altForm)
    {
        Properties copy = new Properties();
        if (!isEmpty()) {
            Iterator itr= values().iterator();
            while (itr.hasNext()) {
                InnerNameValuePair pair = (InnerNameValuePair)itr.next();
                if (pair instanceof Conditional) {
                    if (OptionalExecuteHelper.include(P,(Conditional)pair)) {
                        copy.put(pair.getName(),pair.getValue(P,altForm));
                    }
                } else {
                    copy.put(pair.getName(),pair.getValue(P,altForm));
                }
            }
        }
        return copy;
    }



    /**
     * Factory method to create a new conditional name-value pair
     * for inclusion in this collection.
     **/
    protected InnerNameValuePair newNVPair()
    {
        return new ConditionalInnerNameValuePair();
    }
}

/* end-of-ConditionalParameters.java */