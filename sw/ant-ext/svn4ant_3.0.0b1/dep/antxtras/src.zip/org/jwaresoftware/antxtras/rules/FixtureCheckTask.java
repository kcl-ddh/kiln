/**
 * $Id: FixtureCheckTask.java 582 2009-02-07 17:27:56Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  java.text.MessageFormat;
import  java.util.Stack;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.condition.Condition;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.behaviors.BuildAssertionException;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.Handling;
import  org.jwaresoftware.antxtras.parameters.IsA;

/**
 * Helper that verifies the expected state of fixture information. Basically
 * a simplified target-independent assertion that verifies the most basic build
 * iteration constraints. Usually defined as &lt;fixturecheck&gt;.
 * This task is important when defining rules that expect certain properties
 * to exist.
 * <p>
 * <b>Example Usage:</b><pre>
 *    &lt;fixturecheck isset="module_version"/&gt;
 *    &lt;fixturecheck isnotwhitespace="o.a.t.a.Pattern"/&gt;
 *    &lt;fixturecheck antIs="1.6+"/&gt;
 *    &lt;fixturecheck nonesetlike="^failure\.svn\..*$"/&gt;
 * -OR-
 *    &lt;rule id="required.subbuild.fixture"&gt;
 *       &lt;fixturecheck isset="o.a.t.a.Pattern"&gt;
 *       &lt;require messageid="err.misin.filters"&gt;
 *         &lt;isreference name="copyfilters.sources" class="${o.a.t.a.Pattern}"/&gt;
 *         &lt;isreference name="copyfilters.manifests" class="${o.a.t.a.Pattern}"/&gt;
 *       &lt;/require&gt;
 *    &lt;/rule&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,helper
 * @see      AssertTask
 **/

public final class FixtureCheckTask extends BooleanRule
{
    /**
     * Initializes a new standalone FixtureCheckTask instance.
     **/
    public FixtureCheckTask()
    {
        super(AntX.rules+"FixtureCheck:",false);
    }


    /**
     * Initializes a new standalone custom-labeled
     * FixtureCheckTask instance.
     * @param iam CV-label (non-null)
     **/
    public FixtureCheckTask(String iam)
    {
        super(iam,false);
    }


    /**
     * Initializes a new embedded custom-labeled
     * FixtureCheckTask instance.
     * @param embed <i>true</i> if this is an embedded task
     * @since JWare/AntX 0.4
     **/
    public FixtureCheckTask(boolean embed)
    {
        super(AntX.rules+"FixtureCheck:",embed);
    }


    /**
     * Initializes the enclosing project for this task. Also
     * updates internal project-component helpers.
     **/
    public void setProject(Project project)
    {
        super.setProject(project);
        m_shh.setProject(project);
    }


    /**
     * Any short-hand condition setup triggers an immediate
     * evaluation.
     **/
    private void evalIfEmbedded()
    {
        if (isEmbedded()) {
            eval();
        }
    }

// ---------------------------------------------------------------------------------------
// Parameters:
// ---------------------------------------------------------------------------------------

    /**
     * Sets an inlined message to be displayed if check fails.
     * Diagnostics aid.
     * @since JWare/AntXtras 2.0.0
     **/
    public final void setMessage(String msg)
    {
        if (!Tk.isWhitespace(msg)) {
            m_defaultMsg = uistrs().get("brul.assert.failed.lead",msg);
        } else {
            m_defaultMsg = msg;
        }
    }


    /** 
     * V1 series version of {@linkplain #setMessage}.
     * @deprecated Use {@linkplain #setMessage} instead.
     */
    public final void setMsg(String msg) {
        setMessage(msg);
    }


    /**
     * Returns this task's inlined default message. Returns
     * <i>null</i> if never set.
     */
    public final String getDefaultMessage()
    {
        return m_defaultMsg;
    }


    /**
     * Will verify the named property is defined in fixture.
     * @param property the property to check (non-null)
     **/
    public void setIsSet(String property)
    {
        m_shh.setIsSet(property);
        m_shh.setMalformed(Handling.REJECT);
        evalIfEmbedded();
    }


    /**
     * Will verify the named property is defined to a positive
     * boolean string in fixture. Synonyms like "on" are allowed.
     * @param property the property to check (non-null)
     **/
    public void setIsSetTrue(String property)
    {
        m_shh.setIsSetTrue(property);
        evalIfEmbedded();
    }


    /**
     * Will verify the named property is not defined in fixture.
     * @param property the property to check (non-null)
     **/
    public void setIsNotSet(String property)
    {
        m_shh.setIsNotSet(property);
        evalIfEmbedded();
    }

    /**
     * Will verify the named variable is defined in fixture.
     * @param variable the variable to check (non-null)
     **/
    public void setVarSet(String variable)
    {
        m_shh.setVarSet(variable);
        evalIfEmbedded();
    }


    /**
     * Will verify the named variable is defined to a positive
     * boolean string in fixture. Synonyms like "yes" are allowed.
     * @param variable the variable to check (non-null)
     **/
    public void setVarSetTrue(String variable)
    {
        m_shh.setVarSetTrue(variable);
        evalIfEmbedded();
    }


    /**
     * Will verify the named variable is not defined in fixture.
     * @param variable the variable to check (non-null)
     **/
    public void setVarNotSet(String variable)
    {
        m_shh.setVarNotSet(variable);
        evalIfEmbedded();
    }


    /**
     * Will verify the named reference is defined in fixture.
     * @param refid the reference to check (non-null)
     **/
    public void setIsRef(String refid)
    {
        m_shh.setIsReference(refid);
        evalIfEmbedded();
    }


    /**
     * Will verify the named reference is not defined in fixture.
     * @param refid the reference to check (non-null)
     * @since JWare/AntX 0.5
     **/
    public void setIsNotRef(String refid)
    {
        m_shh.setIsNotReference(refid);
        evalIfEmbedded();
    }


    /**
     * Will verify that at least one of the named properties
     * exists in the fixture.
     * @param properties the comma-delimited list of property
     *                   names (non-null)
     **/
    public void setAnySet(String properties)
    {
        m_shh.setAnySet(properties);
        m_shh.setMalformed(Handling.REJECT);
        evalIfEmbedded();
    }


    /**
     * Will verify that all of the named properties exist in
     * the fixture.
     * @param properties the comma-delimited list of property
     *                   names (non-null)
     **/
    public void setAllSet(String properties)
    {
        m_shh.setAllSet(properties);
        m_shh.setMalformed(Handling.REJECT);
        evalIfEmbedded();
    }


    /**
     * Will verify that all of the matching properties exist
     * and are resolvable in the fixture.
     * @param pattern the filtering pattern for all script
     *        properties
     * @since JWare/AntX 0.4
     **/
    public void setAllSetLike(String pattern)
    {
        m_shh.setAllSetLike(pattern);
        evalIfEmbedded();
    }


    /**
     * Will verify that none of the named properties exist in
     * the fixture.
     * @param properties the comma-delimited list of property
     *                   names (non-null)
     **/
    public void setNoneSet(String properties)
    {
        m_shh.setNoneSet(properties);
        evalIfEmbedded();
    }


    /**
     * Will verify that there are no properties that match the given
     * pattern. For example:
     * <span class="src">&lt;fixturecheck nonesetlike="^failure\.svn.*$"/&gt;</span>.
     * @param pattern the filtering pattern for all script properties
     * @since JWare/AntX 0.6
     **/
    public void setNoneSetLike(String pattern)
    {
        m_shh.setNoneSetLike(pattern);
        evalIfEmbedded();
    }


    /**
     * Will verify that the named property is defined as a
     * boolean string in fixture. Both positive and negative boolean
     * strings allowed (including synonyms like "on" and "no").
     * @param property the property to check (non-null)
     **/
    public void setIsBoolean(String property)
    {
        m_shh.setIsBoolean(property);
        m_shh.setIsA(IsA.PROPERTY);
        evalIfEmbedded();
    }


    /**
     * Will verify that the named property is defined as a
     * parseable integral value (short, int, long) in fixture. Both
     * positive and negative values allowed.
     * @param property the property to check (non-null)
     * @since JWare/AntXtras 2.0.0
     **/
    public void setIsNumber(String property)
    {
        m_shh.setIsNumber(property);
        m_shh.setIsA(IsA.PROPERTY);
        evalIfEmbedded();
    }

    /** Backward-compatible variant of 'isnumber' shorthand. 
     *  @deprecated Use {@linkplain #setIsNumber} instead.
     **/
    public final void setIsNumeric(String property)
    {
        setIsNumber(property);
    }


    /**
     * Will verify that the named property is defined to non-
     * whitespace characters. Failed property substitution is
     * automatically checked.
     * @param property the property to check (non-null)
     **/
    public void setIsNotWhitespace(String property)
    {
        m_shh.setIsNotWhitespace(property);
        m_shh.setIsA(IsA.PROPERTY);
        m_shh.setMalformed(Handling.REJECT);
        evalIfEmbedded();
    }

// ---------------------------------------------------------------------------------------

    /**
     * Defines short hand &lt;antversion is="&#8230;"/&gt; condition.
     * @since JWare/AntX 0.4
     **/
    public void setAntIs(String version)
    {
        m_shh.setAntIs(version);
        evalIfEmbedded();
    }


    /**
     * Defines short hand &lt;antversion pattern="&#8230;"/&gt;
     * condition.
     * @since JWare/AntX 0.4
     **/
    public void setAntLike(String pattern)
    {
        m_shh.setAntLike(pattern);
        evalIfEmbedded();
    }



    /**
     * Defines short hand check for specific os configuration.
     * @since JWare/AntX 0.4
     **/
    public void setOS(String selector)
    {
        m_shh.setOS(selector);
        evalIfEmbedded();
    }


// ---------------------------------------------------------------------------------------
// Rule Evaluation:
// ---------------------------------------------------------------------------------------

    /**
     * Evaluates this fixture verification. If verification fails,
     * this evaluation throws a build exception immediately so
     * never returns <i>false</i>.
     * @throws BuildAssertionException if assertion <i>false</i>
     **/
    public boolean eval() throws BuildException
    {
        verifyInProject_("eval");

        Condition c = getRootCondition();

        if (c==null) {
            String msgid= isEmpty()
                ? "brul.err.atleast.one.condition"
                : "brul.err.only.one.condition";
            String ermsg = uistrs().get(msgid);
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg, getLocation());
        }

        boolean istrue = c.eval();
        setEvalResult(istrue,getConditionNames(1));
        return istrue;
    }


    /**
     * Called to record this verification's evaluation results. For
     * fixture verifications a <i>false</i> result is very bad.
     *<i>true</i> results are basically ignored.
     **/
    protected void setEvalResult(boolean istrue, final String listing)
        throws BuildException
    {
        if (!istrue) {
            String error;

            if (getMessageId()==null) {
                String inlined = getDefaultMessage();
                if (inlined==null) {
                    error = uistrs().get("brul.assert.failed",listing);
                } else {
                    error = MessageFormat.format(inlined,new Object[]{listing});
                }
            } else {
                error = getMsg(newMsgGetter(listing));
            }

            log(error, Project.MSG_ERR);
            throw new BuildAssertionException(error, getLocation());

        }
    }


    /**
     * No-op.
     **/
    public void verifyNoCircularDependency(Stack stk, Requester clnt)
    {
    }

// ---------------------------------------------------------------------------------------

    private String m_defaultMsg;
    private final ShortHandHelper m_shh = new ShortHandHelper(this);
}

/* end-of-FixtureCheckTask.java */
