/**
 * $Id: RefLoaderEnabled.java 808 2009-08-30 16:47:21Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

import  org.apache.tools.ant.types.Reference;

/**
 * Mixin interface for a component that supports custom class and resource loading
 * options via a predefined class loader reference only. The component will use
 * the custom loader when searching for and/or loading resources. Forces component
 * to support the standard "<span class="src">loaderref=refid</span>" parameter.
 *
 * @since     JWare/AntX 2.0.0
 * @author    ssmc, &copy;2007-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    api,infra
 * @see       org.jwaresoftware.antxtras.construct.ClassLoaderDefTask
 **/

public interface RefLoaderEnabled
{
    /**
     * Tells this component to use an existing classloader to
     * search and/or load resources.
     * @param r reference to an existing ClassLoader (non-null)
     **/
    void setLoaderRef(Reference r);


    /**
     * Returns this component's own loader identifier based on
     * its <em>current</em> configuration; specifically the last
     * assigned loader reference or the last classpath reference
     * assigned.
     **/
    String getLoaderRefId();
}

/* end-of-RefLoaderEnabled.java */
