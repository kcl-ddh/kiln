/**
 * $Id: UnmodifiableListSet.java 936 2010-01-02 14:01:17Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

import  java.util.Collection;
import  java.util.Iterator;
import  java.util.List;
import  java.util.Set;

/**
 * Adapter for a simple List to a simple Set. User must guarantee
 * the underlying list really only has unique elements.
 *
 * @since     JWare/AntXtras 2.1.0
 * @author    ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   special (as guarded as underlying List)
 * @.group    impl,helper
 **/

public class UnmodifiableListSet implements Set
{
    final List list;

    /** 
     * Initializes a new set wrapper for the given list.
     * * @param list the list (non-null)
     **/
    public UnmodifiableListSet(List list) {
        this.list = list;
    }

    public int size() {
        return list.size();
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public Object[] toArray() {
        return list.toArray();
    }

    public Object[] toArray(Object[] a) {
        return list.toArray(a);
    }

    public boolean add(Object o) {
        throw new UnsupportedOperationException();
    }

    public boolean contains(Object o) {
        return list.contains(o);
    }

    public boolean remove(Object o) {
        throw new UnsupportedOperationException();
    }

    public boolean addAll(Collection c) {
        throw new UnsupportedOperationException();
    }

    public boolean containsAll(Collection c) {
        return list.containsAll(c);
    }

    public boolean removeAll(Collection c) {
        throw new UnsupportedOperationException();
    }

    public boolean retainAll(Collection c) {
        throw new UnsupportedOperationException();
    }

    public Iterator iterator() {
        return new ArrayIterator(toArray());
    }
}

/* end-of-UnmodifiableListSet.java */
