/**
 * $Id: IsBoolean.java 415 2008-04-22 02:08:37Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.IgnoreCaseEnabled;
import  org.jwaresoftware.antxtras.parameters.SynonymsEnabled;

/**
 * Simple Is-A-Boolean condition check.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   &lt;isboolean value="${junit.present}"/&gt;
 *   &lt;isboolean property="is.dist.build"/&gt;
 *   &lt;isboolean variable="defaults.disabled" synonyms="off"/&gt;
 *</pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2003-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,infra
 **/

public final class IsBoolean extends SimpleFlexCondition
    implements IgnoreCaseEnabled, SynonymsEnabled
{
    /**
     * Initializes new IsBoolean condition. A value type must be
     * specified before this condition is evaluated.
     **/
    public IsBoolean()
    {
        super();
    }


    /**
     * Initializes a fully-defined IsBoolean condition.
     * @param property the property against which condition checks
     **/
    public IsBoolean(String property)
    {
        setProperty(property);
    }


    /**
     * Initializes an IsBoolean condition to either a property or
     * a variable value check.
     * @param value the property or varaible against which condition checks
     * @param isP <i>true</i> if <code>value</code> is property's name
     **/
    public IsBoolean(String value, boolean isP)
    {
        if (isP) {
            setProperty(value);
        } else {
            setVariable(value);
        }
    }


    /**
     * Sets whether value should be lowercased before checked.
     **/
    public void setIgnoreCase(boolean ignore)
    {
        getValueHelper().setIgnoreCase(ignore);
    }


    /**
     * Returns <i>true</i> if this condition will ignore value's
     * case when it's checked. Defaults <i>false</i>.
     **/
    public final boolean isIgnoreCase()
    {
        return getValueHelper().isIgnoreCase();
    }


    /**
     * Sets whether value will be checked for boolean synonyms
     * like "<i>off</i>" or "<i>yes</i>". Defaults <i>on</i>.
     * @param allowAll <i>true</i> if synonyms are enabled (default)
     **/
    public void setSynonyms(boolean allowAll)
    {
        m_allowAll = allowAll;
    }


    /**
     * Returns <i>true</i> if value allowed to be a boolean synonyms.
     * Defaults <i>true</i>.
     **/
    public final boolean allowSynonyms()
    {
        return m_allowAll;
    }



    /**
     * Sets this condition to evaluate a literal value as-is.
     * @param value the literal value to check
     **/
    public void setValue(String value)
    {
        require_(value!=null,"setValu- nonzro");
        setLiteral(value);
    }



    /**
     * Returns <i>true</i> if this condition's property, reference,
     * or variable value matches a boolean value name (explicitly).
     **/
    public boolean eval()
    {
        verifyCanEvaluate_("eval");

        String value = getValueHelper().getValue();
        if (value==null) {
            return false;
        }

        boolean isbool;
        if (allowSynonyms()) {
            isbool = Tk.string2PosBool(value).booleanValue() ||
                !Tk.string2NegBool(value).booleanValue();
        } else {
            isbool = Strings.TRUE.equals(value) ||
                Strings.FALSE.equals(value);
        }
        return isbool;
    }


    private boolean m_allowAll=true;
}

/* end-of-IsBoolean.java */
