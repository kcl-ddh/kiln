/**
 * $Id: BundleStringManagerNoNulls.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.uism;

import  java.text.MessageFormat;

/**
 * Wrapper for the standard BundleStringManager that returns the incoming message
 * id if no matching template found. Use for <em>fixed, immutable</em> string
 * managers (like shared class instances).
 *
 * @since    JWare/internal 2.0
 * @author   ssmc, &copy;2005-2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  special (as threadsafe as underlying BundleStringManager)
 * @.group   impl,infra
 **/

public final class BundleStringManagerNoNulls extends BundleStringManager
{
    /**
     * Initializes a new no-null bundle string manager.
     **/
    public BundleStringManagerNoNulls(String resourcebundle)
    {
        super(resourcebundle);
    }



    /**
     * Returns the incoming message id if unable to find a match
     * in this bundle.
     * @param id message id (non-null)
     * @param args message template arguments
     * @param defm [optional] default message used if no match found
     * @return message or message id if no match found.
     **/
    public String mget(String id, Object[] args, String defm)
    {
        String result = super.mget(id,args,defm);
        if (result==null || result.length()==0) {
            result = id;
        }
        return result;
    }



    /**
     * Ensures the message id is appended if unable to find a match
     * in this bundle.
     * @param mf message formatter to use (non-null)
     * @param id message id (non-null)
     * @param args message template arguments
     * @param sb [optional] buffer to fill in (if null, new one created)
     * @param defm [optional] default message used if no match found
     * @return filled in string buffer (never <i>null</i>).
     **/
    public StringBuffer fill(MessageFormat mf, String id, Object[] args,
                             StringBuffer sb, String defm)
    {
        if (sb==null) {
            sb = new StringBuffer(150);
        }
        int len0 = sb.length();
        sb = super.fill(mf,id,args,sb,defm);
        if (sb.length()==len0) {
            sb.append(id);
        }
        return sb;
    }
}


/* end-of-BundleStringManagerNoNulls.java */
