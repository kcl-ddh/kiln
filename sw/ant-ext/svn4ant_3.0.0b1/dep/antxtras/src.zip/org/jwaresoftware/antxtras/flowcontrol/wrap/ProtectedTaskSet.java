/**
 * $Id: ProtectedTaskSet.java 430 2008-04-27 15:27:03Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.wrap;

import  org.jwaresoftware.antxtras.core.AntX;

/**
 * Wrapper task that gives its user an opportunity to cleanup after
 * process-aborting build errors. Like Java-style try-catch-finally
 * construct. Usually defined &lt;protect&gt; with optional &lt;iferror&gt;
 * and &lt;always&gt; nested tasksets.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   &lt;capturelogs importantfrom="info"&gt;
 *     &lt;<b>protect</b>&gt;
 *       <i>[...compilation here...]</i>
 *       &lt;<b>always</b>&gt;
 *         &lt;copylogged tofile="${logs.d}/compile.log"/&gt;
 *       &lt;/always&gt;
 *     &lt;/protect&gt;
 *   &lt;/capturelogs&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,infra
 * @see      IfErrorTask
 * @see      AlwaysTask
 **/

public final class ProtectedTaskSet extends TolerantTaskSet
{
    /**
     * Initializes new protected taskset.
     **/
    public ProtectedTaskSet()
    {
        super(AntX.flowcontrol+"ProtectedTaskSet:");
    }
}

/* end-of-ProtectedTaskSet.java */
