/**
 * $Id: Stringifier.java 544 2008-12-27 02:21:13Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  java.io.File;
import  java.net.URL;
import  java.util.Date;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.EnumeratedAttribute;
import  org.apache.tools.ant.types.Environment;
import  org.apache.tools.ant.types.Path;
import  org.apache.tools.ant.types.RegularExpression;
import  org.apache.tools.ant.util.regexp.RegexpMatcher;

import  org.jwaresoftware.antxtras.behaviors.FlexStringFriendly;
import  org.jwaresoftware.antxtras.helpers.DateTimeFormat;
import  org.jwaresoftware.antxtras.helpers.InnerString;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Base utility for converting fixture components to their string form. This default
 * stringifiers understand a subset of standard Ant elements (listed below) and any AntX
 * component that implements the {@linkplain FlexStringFriendly} interface. AntX
 * feedback tasks like &lt;print&gt; can fall back to Stringifiers if needed.
 * <p/>
 * A <i>lenient</i> stringifier is one that tries to make an intelligent decision about
 * how to stringify an object but if all fails will just default to whatever
 * <span class="src">Object.toString</span> returns. A strict stringifier will return
 * <i>null</i> if it does not understand how to convert an object to a
 * {@linkplain FlexString} friendly value.
 * <p>
 * <b>Recognized Types:</b><ul>
 *   <li>{@linkplain FlexStringFriendly}</li>
 *   <li>InnerStrings</li>
 *   <li>String</li>
 *   <li>Boolean (converted to "true" or "false")</li>
 *   <li>Dates (converted to GMT string)</li>
 *   <li>URLs</li>
 *   <li>Files</li>
 *   <li>RegularExpressions (converted to underlying pattern)</li>
 *   <li>Paths</li>
 *   <li>Numbers</li>
 *   <li>Throwable (converted to throwable's message)</li>
 *   <li>Class (converted to class's fully qualified name)</li>
 *   <li>EnumeratedAttribute</li>
 *   <li>Environment.Variable</li>
 * </ul>
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  guarded
 * @.group   api,helper
 * @see      FlexStringFriendly
 **/

public class Stringifier implements FixtureCore
{
    /**
     * Pseudo factory method that returns the one of the current
     * iteration's two class stringifier singletons. Never returns
     * <i>null</i>.
     * @param lenient <i>true</i> to return the lenient stringifier
     * @see Iteration#lenientStringifer
     * @see Iteration#strictStringifier
     **/
    public static final Stringifier get(boolean lenient)
    {
        return lenient ? Iteration.lenientStringifer()
            : Iteration.strictStringifier();
    }


    /**
     * Initializes a new lenient stringifier.
     **/
    public Stringifier()
    {
        m_isLenient = true;
    }


    /**
     * Initializes a new stringifier.
     * @param lenient <i>true</i> if this stringifier should
     *                do lenient stringification(tm)
     **/
    public Stringifier(boolean lenient)
    {
        m_isLenient = lenient;
    }


    /**
     * Returns <i>true</i> if this stringifier will tolerate any
     * type of object, defaulting to the standard 'toString()'
     * method to stringify it. Defined when this stringifier is
     * created.
     **/
    public final boolean isLenient()
    {
        return m_isLenient;
    }


    /**
     * Tries to convert a generic reference object to a flex value
     * friendly string. If the project is unspecified and this stringifier
     * needs a project reference, this method will throw an
     * IllegalArgumentException.
     * @param o the thing to be stringified
     * @param project [optional] project from which information read
     *                if necessary (unused by default)
     * @throws IllegalArgumentException if project <i>null</i> and
     *               is required
     **/
    public String stringFrom(Object o, Project project)
    {
        if (o==null) {
            return null;
        }
        if (o instanceof FlexStringFriendly) {
            return ((FlexStringFriendly)o).stringFrom(project);
        }

        //Implementation Notes:
        //   => ugly (and slow) but works...
        //   => to extend this if ever necessary need to customize
        //      the stringifier used by the Iteration object...
        //
        if (o instanceof String || o instanceof Boolean) {
            return o.toString();
        }
        if (o instanceof InnerString) {
            return ((InnerString)o).toString(project);
        }
        if (o instanceof Throwable) {
            return ((Throwable)o).getMessage();
        }
        if (o instanceof RegularExpression) {
            return ((RegularExpression)o).getPattern(project);
        }
        if (o instanceof RegexpMatcher) {
            return ((RegexpMatcher)o).getPattern();
        }
        if (o instanceof Path) {
            return ((Path)o).toString();
        }
        if (o instanceof File || o instanceof URL || o instanceof Number) {
            return o.toString();
        }
        if (o instanceof Date) {
            return DateTimeFormat.ISOmillistrictformat(((Date)o).getTime());
        }
        if (o instanceof EnumeratedAttribute) {
            return ((EnumeratedAttribute)o).getValue();
        }
        if (o instanceof Environment.Variable) {
            return ((Environment.Variable)o).getValue();
        }
        if (o instanceof Class) {
            return ((Class)o).getName();
        }

        if (!isLenient()) {
            return null;//abandon-ship!
        }

        //NB: Ant's default types aren't very 'toString'-friendly
        //    but let's assume that caller knows what they're doing
        return Tk.stringFrom(o,project);
    }


    private final boolean m_isLenient;
}

/* end-of-Stringifier.java */
