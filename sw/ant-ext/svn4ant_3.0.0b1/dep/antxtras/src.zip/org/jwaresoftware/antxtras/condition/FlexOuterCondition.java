/**
 * $Id: FlexOuterCondition.java 415 2008-04-22 02:08:37Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  java.util.List;

import  org.apache.tools.ant.Project;

/**
 * Any compound condition that can accept nested flex values and
 * property sets.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface FlexOuterCondition
{
    Project getProject();
    List getIncludes();
    boolean willTrim();
    boolean ignoreWhitespace();
}

/* end-of-FlexOuterCondition.java */
