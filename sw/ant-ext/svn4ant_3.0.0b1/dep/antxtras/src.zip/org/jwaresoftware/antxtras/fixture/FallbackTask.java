/**
 * $Id: FallbackTask.java 869 2009-11-22 19:48:45Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.fixture;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.ownhelpers.PropertyExaminer;
import  org.jwaresoftware.antxtras.parameters.Handling;
import  org.jwaresoftware.antxtras.parameters.MalformedCheckEnabled;

/**
 * Task that will setup a default or "fallback" value for a single
 * property or variable. The situation under which you use a fallback
 * instead of a prefer is different. Unlike a prefer (which implies
 * you <em>want</em> the user to define the fixture element), a
 * fallback defines a perfectly valid started value which is often
 * left as-is by the user.
 * <p/>
 * <b>Example Usage:</b><pre>
 * &lt;fallback property="marker.string" value="FIXMEE,TODOO"/&gt;
 * &lt;fallback property="type" value="library" malformed="reject"/&gt;
 * &lt;fallback var="maxloops" value="100"/&gt;
 * </pre>
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    api,infra
 **/

public final class FallbackTask extends AssertableTask
    implements MalformedCheckEnabled
{
    /**
     * Initializes a new fallback task instance.
     **/
    public FallbackTask()
    {
        super(AntX.fixture+"FallbackTask:");
    }



    /**
     * Sets the name of the project property this task
     * should check for existence.
     * @param property the property name (non-null)
     **/
    public void setProperty(String property)
    {
        require_(property!=null,"setProperty- nonzro name");
        m_itemName = property;
        m_isProperty = Boolean.TRUE;
    }



    /**
     * Sets the name of the variable this task should
     * check for existence.
     * @param variable the variable name (non-null).
     **/
    public void setVariable(String variable)
    {
        require_(variable!=null,"setVar- nonzro name");
        m_itemName = variable;
        m_isProperty = Boolean.FALSE;
    }



    /**
     * Synonym for {@linkplain #setVariable(String)}.
     * @param variable the variable name (non-null)
     **/
    public final void setVar(String variable)
    {
        setVariable(variable);
    }



    /**
     * Returns the fallback value fixture item's identifier.
     * Must be defined in order for this task to execute.
     **/
    final String getValueName()
    {
        return m_itemName;
    }



    /**
     * Sets the fallback value to use. The value must be
     * non-null but can be the empty string. For variables,
     * note that the empty string has no effect unless the
     * property AntXtras override property is in effect.
     * @param fallback value to use (non-null)
     **/
    public void setValue(String fallback)
    {
        require_(fallback!=null,"setValue- nonzro valu");
        m_itemValue = fallback;
    }



    /**
     * Returns the fallback value to use. Will be the
     * string "true" if never set explicitly.
     **/
    final String getValue()
    {
        return m_itemValue;
    }



    /**
     * Sets this task's malformed handling option.
     * @param response one of [default,balk,reject,accept,ignore]
     **/
    public void setMalformed(Handling response)
    {
        require_(response!=null,"setMalformed- nonnul flag");
        m_refHandling = response;
    }



    /**
     * Returns this task's malformed handling setting.
     * Returns <i>ACCEPT</i> if never set explicitly.
     **/
    public Handling getMalformedHandling()
    {
        return m_refHandling;
    }



    /**
     * Ensures we have either a target property or
     * variable name.
     * @param calr calling function's identifier (debug)
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);
        if (m_isProperty==null) {
            String e = Errs.NeedsThisAttribute(getTaskName(), "property|var");
            log(e,Project.MSG_ERR);
            throw new BuildException(e,getLocation());
        }
    }



    /**
     * Determines whether or not we should set the target
     * to the new value based on the existing value and our
     * malformed setting.
     * @param valu existing value (can be <i>null</i>)
     * @return true if should set else false
     * @throws BuildException if existing value is malformed
     *   and handling option is set to reject or to balk
     **/
    private boolean set(String type, String curvalue)
    {
        String valuename = getValueName();
        boolean set = (curvalue==null);
        if (!set) {
            PropertyExaminer test = new PropertyExaminer(getProject());
            test.setCheckBrokenSubstitution();
            boolean broken = !test.verifiedLiteral(curvalue);
            if (broken) {
                log("Detected current value is malformed ("+
                    valuename+"="+curvalue+")",
                    Project.MSG_VERBOSE);
            }
            switch(getMalformedHandling().getIndex()) {
                case Handling.ACCEPT_INDEX:
                case Handling.INHERIT_INDEX: {
                    break;
                }
                case Handling.BALK_INDEX: {
                    if (broken) {
                        String err = getMsg();
                        if (err.length()==0) {
                            err = getAntXMsg("fixture.malformed.value.found",
                                             type,valuename,curvalue);
                        }
                        log(err,Project.MSG_ERR);
                        throw new BuildException(err, getLocation());
                    }
                    break;
                }
                default: {//Handling.REJECT_INDEX|Handling.IGNORE_INDEX
                    if (broken) {
                        set = true;
                    }
                }
            }
        }
        return set;
    }



    /**
     * Sets the fixture element (variable or property) if
     * not already set or set to a malformed value and our
     * handling option is set to ignore|reject.
     * @throws BuildException if current value is malformed
     *   and handling option set to balk.
     */
    public void execute()
    {
        verifyCanExecute_("exec");
        final Project P = getProject();
        String it = getValueName();

        if (Boolean.TRUE==m_isProperty) {
            String valu = P.getProperty(it);
            boolean set = set("property",valu);
            if (set) {
                P.setProperty(it, getValue());
            }
        } else {
            String valu = Variables.readstring(it);
            boolean set = set("var",valu);
            if (set) {
                Variables.set(it, getValue(),
                   new Requester.ForComponent(this));
            }
        }
    }


    private String   m_itemName;
    private Boolean  m_isProperty;
    private String   m_itemValue= Strings.TRUE;
    private Handling m_refHandling= Handling.ACCEPT;
}

/* end-of-FallbackTask.java */
