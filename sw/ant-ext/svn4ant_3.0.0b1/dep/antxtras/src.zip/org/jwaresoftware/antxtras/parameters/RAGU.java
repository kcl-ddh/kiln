/**
 * $Id: RAGU.java 551 2009-01-10 23:42:10Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Enumeration that represents the various status ratings. The following list
 * explains what the various values mean:<ul>
 *    <li><span class="src">RED</span>: The receiver is in a bad, or
 *      non-functioning state.</li>
 *    <li><span class="src">AMBER</span>: The receiver is in a functioning
 *        state but there are issues that might need attention.</li>
 *    <li><span class="src">GREEN</span>: The receiver is in a fully
 *        functioning state.</li>
 *    <li><span class="src">UNDEFINED</span>: The receiver is unable to 
 *        determine it state or is deactived or otherwise OFF.</li>
 * </ul>
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class RAGU extends EnumSkeleton
{
    /** Index of {@linkplain #RED RED}. **/
    public static final int RED_INDEX = 0;
    /** Index of {@linkplain #AMBER AMBER}. **/
    public static final int AMBER_INDEX = RED_INDEX+1;
    /** Index of {@linkplain #GREEN GREEN}. **/
    public static final int GREEN_INDEX = AMBER_INDEX+1;
    /** Index of {@linkplain #UNDEFINED UNDEFINED}. **/
    public static final int UNDEFINED_INDEX = GREEN_INDEX+1;


    /** Singleton "<span class="src">RED</span>" choice. **/
    public static final RAGU RED=
        new RAGU("red",RED_INDEX);

    /** Singleton "<span class="src">AMBER</span>" choice. **/
    public static final RAGU AMBER=
        new RAGU("amber",AMBER_INDEX);

    /** Singleton "<span class="src">GREEN</span>" choice. **/
    public static final RAGU GREEN=
        new RAGU("green",GREEN_INDEX);

    /** Singleton "<span class="src">UNDEFINED</span>" choice. **/
    public static final RAGU UNDEFINED=
        new RAGU("undefined",UNDEFINED_INDEX);



    /**
     * Required bean void constructor for Ant's introspector.
     **/
    public RAGU()
    {
        super();
    }


    /**
     * Use to create public singletons. Ensures this enum is
     * initialized as if with the default Ant Introspector
     * helper thingy.
     **/
    private RAGU(String v, int i)
    {
        super(v);
    }


    /**
     * Returns copy of all possible source values as an ordered
     * string array. Note: ordering should be same as our
     * singleton indices.
     **/
    public String[] getValues()
    {
        return new String[] {"red", "amber", "green", "undefined"};
    };



    /**
     * Returns a marker single uppercase character for this 
     * setting. For instance, 'red' will return 'R', 'amber'
     * will return 'A'.
     **/
    public String getMarkerChar() 
    {
        return ""+Character.toUpperCase(getValue().charAt(0));
    }


    /**
     * Helper that converts a scalar to a known RAG.
     * Returns <i>null</i> if value does not match any of expected
     * source.
     * @param i the index to be matched
     **/
    public static RAGU from(int i)
    {
        if (i==GREEN.index)    { return GREEN; }
        if (i==RED.index)      { return RED; }
        if (i==AMBER.index)    { return AMBER; }
        if (i==UNDEFINED.index){ return UNDEFINED; }
        return null;
    }


    /**
     * Same as {@linkplain #from(int) from(int)} but with a
     * default value if value does not match any known
     * RAG index.
     * @param i the index to be matched
     * @param dflt the default RAG if necessary
     **/
    public static RAGU from(int i, RAGU dflt)
    {
        RAGU choice= from(i);
        return (choice==null) ? dflt : choice;
    }


    /**
     * Helper that converts a string to a known RAG
     * singleton. Returns <i>null</i> if string unrecognized. 
     * String can be either RAG's symbolic name, a synonym,
     * or a RAG value's index.
     **/
    public static RAGU from(String s)
    {
        if (s!=null && s.length()>0) {
            s = Tk.lowercaseFrom(s);
            char c0 = s.charAt(0);
            if (Character.isDigit(c0)) {
                try { return from(Integer.parseInt(s)); }
                catch(Exception nfx) {/*burp*/}
            } else if (s.length()==1) {
                if (GREEN.value.charAt(0)==c0)     { return GREEN; }
                if (AMBER.value.charAt(0)==c0)     { return AMBER; }
                if (RED.value.charAt(0)==c0)       { return RED; }
                if (UNDEFINED.value.charAt(0)==c0) { return UNDEFINED; }
                if ('o'==c0 || '?'==c0)            { return UNDEFINED; }
            } else {
                if (GREEN.value.equals(s))     { return GREEN; }
                if (AMBER.value.equals(s))     { return AMBER; }
                if (RED.value.equals(s))       { return RED; }
                if (UNDEFINED.value.equals(s)) { return UNDEFINED; }
                if ("off".equals(s))           { return UNDEFINED; }
            }
        }
        return null;
    }


    /**
     * Same as {@linkplain #from(String) from(String)} but with a
     * default value if supplied value does not match any known
     * RAG's name.
     * @param s the symbolic name to be matched
     * @param dflt the default RAGU if necessary
     **/
    public static RAGU from(String s, RAGU dflt)
    {
        RAGU choice= from(s);
        return (choice==null) ? dflt : choice;
    }
}

/* end-of-RAGU.java */