/**
 * $Id: Variables.java 1034 2010-03-20 15:05:26Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  java.util.ArrayList;
import  java.util.Collection;
import  java.util.HashMap;
import  java.util.Iterator;
import  java.util.Map;
import  java.util.Properties;

import  org.apache.tools.ant.Project;
import  org.jwaresoftware.antxtras.behaviors.ProblemHandler;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Manager of an execution cycle's variables (aka modifiable properties). 
 * This class is used heavily by the standard AntXtra's  
 * {@linkplain org.jwaresoftware.antxtras.variables.AssignTask AssignTask} and
 * related component as well as any other component that reads or writes to variables.
 * This class is almost always used via the various {@linkplain Iteration singleton}
 * static APIs like {@linkplain #readstring readstring}, {@linkplain #set set},
 * and {@linkplain #delete delete}.
 * <p/>
 * This class administers a <em>single</em> thread-independent collection of
 * thread-specific elements. In other words, for each variable there is a single named
 * collection of thread-specific values. This is different from how other thread-based
 * cycle information is stored. See the {@linkplain FixtureOverlays} class for 
 * further details.
 * <p/>
 * This class's effectiveness relies on a single instance being used. Within Ant certain
 * tasks can create multiple class loaders hence muddying the singleton concept because
 * class loaders are a hidden (or forgotten) link in the definition of a unique entity
 * within a VM's object space. Soooo my advice is to use variables with care when 
 * mucking with multiple, user controlled, class loaders within a single thread.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  guarded
 * @.group   impl,helper
 * @see      org.jwaresoftware.antxtras.variables.AssignTask
 * @see      PropertyHandle
 * @see      Iteration#variables
 **/

public final class Variables implements FixtureCore, FixtureAdministrator
{
    private static final String IAM_ = "Variables:";



    /**
     * If you really want your own set of modifiable exportable
     * properties for something.
     * @see Iteration#variables
     **/
    public Variables()
    {
    }



    /**
     * Returns the modifiable property handle for named item.
     * @param name the property's name (non-null)
     **/
    public PropertyHandle getProperty(String name)
    {
        AntX.require_(name!=null,IAM_,"get- nonzro name");

        synchronized(m_handles) {
            PropertyHandle ph = (PropertyHandle)m_handles.get(name);
            if (ph==null) {
                ph = new PropertyHandle();
                m_handles.put(name, ph);
            }
            return ph;
        }
    }



    /**
     * Convenience to get(create) and set a property handle in single
     * operation.
     * @param name the property's name (non-null)
     * @param valu the property's value
     * @param clnt [optional] callback link for diagnostics
     **/
    public void putProperty(String name, Object valu, Requester clnt)
    {
        PropertyHandle ph = getProperty(name);
        if (clnt!=null) {
            record(name,valu,clnt);
        }
        ph.set(valu);
    }



    /**
     * Returns <i>true</i> if a property handle already exists for
     * given name. This method does not check the property handle's
     * contents.
     * @param name the property's name  (non-null)
     **/
    public boolean knowsProperty(String name)
    {
        AntX.require_(name!=null,IAM_,"check- nonzro name");

        synchronized(m_handles) {
            return m_handles.containsKey(name);
        }
    }



    /**
     * Convenience to read a property's value iff it's defined or
     * return some default value. Returns <i>null</i> if the property
     * is defined and it's current value is <i>null</i>-- will not
     * return the default value.
     * @param name the property's name (non-null)
     * @param dflt default value return iff property not defined
     **/
    public Object readProperty(String name, Object dflt)
    {
        AntX.require_(name!=null,IAM_,"read- nonzro name");

        synchronized(m_handles) {
            PropertyHandle ph= (PropertyHandle)m_handles.get(name);
            return (ph!=null) ? ph.get() : dflt;
        }
    }



    /**
     * Convenience to clear the property handle's value in a single
     * operation. Any existing property handle is returned (can be
     * <i>null</i>).
     * @param name the property's name (non-null)
     * @param clnt [optional] callback link for diagnostics
     **/
    public PropertyHandle removeProperty(String name, Requester clnt)
    {
        AntX.require_(name!=null,IAM_,"remove- nonzro name");

        if (clnt!=null) { 
            record(name,clnt);
        }
        synchronized(m_handles) {
            return (PropertyHandle)m_handles.remove(name);
        }
    }



    /**
     * Convenience to clear a collection of properties in a single
     * operation.
     * @param names the collection of properties to delete (non-null)
     * @param clnt [optional] callback link for diagnostics
     * @since JWare/AntX 0.5
     **/
    public void removeProperties(Collection names, Requester clnt)
    {
        AntX.require_(names!=null,IAM_,"remove- nonzro names");

        if (clnt!=null) {
            record(names.toString(),clnt);
        }
        synchronized(m_handles) {
            m_handles.keySet().removeAll(names);
        }
    }



    /**
     * Convenience to clear a collection of properties in a single
     * operation. Only properties with names matching those in the
     * given collection are retained.
     * @param names the collection of properties to retain (non-null)
     * @since JWare/AntX 0.5
     **/
    public void retainProperties(Collection names)
    {
        AntX.require_(names!=null,IAM_,"retain- nonzro names");

        synchronized(m_handles) {
            m_handles.keySet().retainAll(names);
        }
    }



    /**
     * Returns detached copy of all properties in current repository. The
     * returned Properties item is a regular key->value mapping. Useful
     * for capturing environment diagnostics.
     * @param existingP Properties to be updated (pass <i>null</i> for new)
     * @since JWare/AntX 0.2
     **/
    public Properties copyOfProperties(Properties existingP)
    {
        if (existingP==null) {
            existingP= new Properties();
        }
        synchronized(m_handles) {
            Iterator itr = m_handles.entrySet().iterator();
            while (itr.hasNext()) {
                Map.Entry mE= (Map.Entry)itr.next();
                PropertyHandle ph= (PropertyHandle)mE.getValue();
                existingP.put(mE.getKey(),String.valueOf(ph.get()));//cvt null to "null"
            }
        }
        return existingP;
    }



    /**
     * Returns detached copy of names of all properties in current 
     * repository. The returns Collection contains property names.
     * This is used to capture environment diagnostics and support
     * execution bubbles.
     * @since JWare/AntX 0.5
     **/
    public Collection copyOfPropertyNames()
    {
        synchronized(m_handles) {
            return new ArrayList(m_handles.keySet());
        }
    }



    /**
     * Clears all properties for all threads in current repository. Your
     * application should never use this method directly; it is provided for
     * test harness to reset the environment to a known state.
     * @since JWare/AntX 0.4
     **/
    void clearProperties()
    {
        synchronized(m_handles) {
            m_handles.clear();
            m_handles = new HashMap(111,0.8f);
        }
    }


    /** 
     * Write diagnostic of set if needed. Handle case were incoming
     * value barfs on toString (possible with some Ant types).
     */
    static final void record(String name, Object valu, Requester clnt)
    {
        if (clnt!=null) {
            clnt.log("Setting var: '"+name+
                     "' -> "+Tk.stringFrom(valu,null),
                     Project.MSG_DEBUG);
        }
    }


    /** 
     * Write diagnostic of del if needed. 
     */
    static final void record(String name, Requester clnt)
    {
        if (clnt!=null) {
            clnt.log("Removing var: '"+name+
                     "'",Project.MSG_DEBUG);
        }
    }



    /**
     * Instance-level member fields.
     **/
    private HashMap m_handles= new HashMap(111,0.8f);



//---------------------------------------------------------------------------------------------------------|
// Bunch of convenient utility APIs for the Iteration singleton:
//---------------------------------------------------------------------------------------------------------|


    /**
     * Returns a complete independent copy of the current iteration's 
     * {@linkplain Iteration#variables modifiable properties}.
     * @since JWare/AntX 0.5
     **/
    public static final Properties copy(Properties fillin)
    {
        return Iteration.variables().copyOfProperties(fillin);
    }


    /**
     * Returns <i>true</i> if the named property is defined 
     * in the current iteration's 
     * {@linkplain Iteration#variables modifiable properties}.
     * @since JWare/AntX 0.5
     **/
    public static final boolean has(String name)
    {
        return Iteration.variables().knowsProperty(name);
    }


    /**
     * Returns a property from the current iteration's 
     * {@linkplain Iteration#variables modifiable properties}.
     **/
    public static final PropertyHandle get(String name)
    {
        return Iteration.variables().getProperty(name);
    }


    /**
     * Updates a property value in the current iteration's 
     * {@linkplain Iteration#variables modifiable properties}.
     **/
    public static final void set(String name, Object valu)
    {
        Iteration.variables().putProperty(name,valu,null);
    }


    /**
     * Like {@linkplain #set(String, Object) set(name,value)} 
     * but with diagnostic feedback if possible.
     * @param name name of variable (non-null)
     * @param valu value of variable (non-null)
     * @param clnt [optional] callback link for diagnostics
     * @since JWare/AntXtras 2.0.0
     **/
    public static final void set(String name, Object valu, Requester clnt)
    {
        Iteration.variables().putProperty(name,valu,clnt);
    }


    /**
     * Clears a property value in the current iteration's 
     * {@linkplain Iteration#variables modifiable properties}.
     * The property is still known to the iteration. Use 
     * {@linkplain #delete delete(name)} to remove a property 
     * from the iteration.
     * @see #delete
     **/
    public static final void unset(String name)
    {
        Iteration.variables().putProperty(name,null,null);
    }


    /**
     * Like {@linkplain #unset(String) unset(name)} but
     * with diagnostic feedback if possible.
     * @param name name of variable (non-null)
     * @param clnt [optional] callback link for diagnostics
     * @since JWare/AntXtras 2.0.0
     **/
    public static final void unset(String name, Requester clnt)
    {
        Iteration.variables().putProperty(name,null,clnt);
    }


    /**
     * Reads a property value from the current iteration's 
     * {@linkplain Iteration#variables modifiable properties}
     * returning a default value if property not defined.
     **/
    public static final Object read(String name, Object dflt)
    {
        return Iteration.variables().readProperty(name,dflt);
    }


    /**
     * Reads a property value from the current iteration's 
     * {@linkplain Iteration#variables modifiable properties}
     * returning a default string if property not defined.
     **/
    public static final String readstring(String name, String dflt)
    {
        return (String)Iteration.variables().readProperty(name,dflt);
    }


    /**
     * Reads a property value from current iteration's 
     * {@linkplain Iteration#variables modifiable properties}
     * returning <i>null</i> if property not defined.
     **/
    public static final Object read(String name)
    {
        return Iteration.variables().readProperty(name,null);
    }


    /**
     * Reads a property value from current iteration's 
     * {@linkplain Iteration#variables modifiable properties}
     * returning <i>null</i> if property not defined.
     **/
    public static final String readstring(String name)
    {
        return (String)Iteration.variables().readProperty(name,null);
    }


    /**
     * Deletes a property from the current iteration's 
     * {@linkplain Iteration#variables modifiable properties}.
     **/
    public static final void delete(String name)
    {
        Iteration.variables().removeProperty(name,null);
    }


    /**
     * Like {@linkplain #delete(String) delete(name)} but
     * with diagnostic feedback if possible.
     * @param name name of variable (non-null)
     * @param clnt [optional] callback link for diagnostics
     * @since JWare/AntXtras 2.0.0
     **/
    public static final void delete(String name, Requester clnt)
    {
        Iteration.variables().removeProperty(name,clnt);
    }


    /**
     * Deletes a collection of properties from current iteration's 
     * {@linkplain Iteration#variables modifiable properties}.
     * @param clnt [optional] callback link for diagnostics
     * @since JWare/AntX 0.5
     **/
    public static final void delete(Collection names, Requester clnt)
    {
        Iteration.variables().removeProperties(names,clnt);
    }


    /**
     * Deletes a collection of properties from the current iteration's 
     * {@linkplain Iteration#variables modifiable properties}.
     * Only properties with names matching those in the given collection
     * are retained.
     * @since JWare/AntX 0.5
     **/
    public static final void retain(Collection names)
    {
        Iteration.variables().retainProperties(names);
    }


//---------------------------------------------------------------------------------------------------------|
// Iteration reset for execution harnesses;
//---------------------------------------------------------------------------------------------------------|

    /**
     * Installs fixture component cleanup method.
     * @since JWare/AntX 0.4
     **/
    static {
        AntXFixture.setKillMethod
            (FixtureIds.VARIABLES_ADMINISTRATION,
             new KillMethod() {
                     public boolean kill(ProblemHandler from) {
                         /*!*/
                         Iteration.variables().clearProperties();
                         return true;
                     }
                     public boolean kill(String target, ProblemHandler from) {
                         return kill(from);
                     }
                 }
             );
    }
}

/* end-of-Variables.java */
