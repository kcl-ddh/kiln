/**
 * $Id: InstanceFactory.java 390 2008-03-30 17:51:32Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.helpers;

import  java.lang.reflect.Constructor;
import  java.util.Hashtable;
import  java.util.Iterator;
import  java.util.Map;
import  java.util.Properties;

import  org.apache.tools.ant.BuildException;

/**
 * Utility class that acts as a simple name to implementation class mapping and
 * factory all in one. Like a standard <span class="src">Hashtable</span>, instances
 * of this class are protected against concurrent access and/or modification.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   guarded
 * @.group    impl,helper
 * @.pattern  GoF.Factory
 **/

public final class InstanceFactory extends Hashtable
{
    /** Signature of general parameter-based constructor. **/
    public static final Class[] CTOR_SIG0= new Class[] {GenericParameters.class};



    /**
     * Initializea new empty instance factory.
     **/
    public InstanceFactory()
    {
    }



    /**
     * Initializea new empty instance factory that uses a
     * specific default class for unmatched categories.
     * @param defaultClass the default class reference (non-null)
     **/
    public InstanceFactory(Class defaultClass)
    {
       setDefaultInstanceClass(defaultClass);
    }




    /**
     * Initializes the fallback class of unmatched categories.
     * @param c the class reference (non-null)
     * @throws IllegalArgumentException is class is <i>null</i>
     **/
    public synchronized void setDefaultInstanceClass(Class c)
    {
        if (c==null) {
            throw new IllegalArgumentException();
        }
        m_defaultClass = c;
    }



    /**
     * Returns this factory's fallback class for unmatched
     * categories. Will never return <i>null</i>.
     **/
    public synchronized Class getDefaultInstanceClass()
    {
        return m_defaultClass;
    }



    /**
     * Installs a new class mapping under a specific name.
     * @param key the category name (non-null)
     * @param value the <span class="src">Class</span> reference
     * @throws IllegalArgumentException if value is not a valid class reference.
     **/
    public Object put(Object key, Object value)
    {
        if (value==null) {
            return super.remove(key);
        }
        if (!(value instanceof Class)) {
            throw new IllegalArgumentException("Only class references allowed!");
        }
        return super.put(key,value);
    }



    private synchronized Class getc(Object key)
    {
        Object rc = get(key);
        Class c;
        if (rc==null) {
            c = getDefaultInstanceClass();
        } else {
            c = (Class)rc;
        }
        return c;
    }



    /**
     * Creates a new instance of the named category.
     * @param key the category's name (non-null)
     * @return new instance
     * @throws BuildException if unable to create new instance.
     **/
    public Object newInstance(Object key)
    {
        Class c = getc(key);
        try {
            return c.newInstance();
        } catch(Exception anyX) {
            throw new BuildException(anyX);
        }
    }



    /**
     * Creates a new custom instance of the named category.
     * @param key the category's name (non-null)
     * @param args the constructor's single argument (non-null)
     * @return new cstom instance
     * @throws BuildException if unable to create new instance.
     **/
    public Object newInstance(Object key, GenericParameters args)
    {
        Class c = getc(key);
        try {
            Constructor ctor = c.getConstructor(CTOR_SIG0);
            Object[] initargs = new Object[] {args};
            return ctor.newInstance(initargs);
        } catch(Exception anyX) {
            throw new BuildException(anyX);
        }
    }



    /**
     * Returns a properties mapping of this factory's named
     * items to their associated class names. Will never return
     * <i>null</i> but can return an empty properties. Caller
     * assumes ownership of returned map.
     * @since JWare/AntX 0.6
     **/
    public synchronized Properties getInstanceClasses()
    {
        Properties classnames = new Properties();
        Iterator itr = entrySet().iterator();
        while (itr.hasNext()) {
            Map.Entry next = (Map.Entry)itr.next();
            Class c = (Class)next.getValue();
            classnames.put(next.getKey(),c.getName());
        }
        return classnames;
    }


    private Class m_defaultClass = Object.class;
}


/* end-of-InstanceFactory.java */