/**
 * $Id: PropertiesLoaderDef.java 936 2010-01-02 14:01:17Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.construct;

import  java.io.ByteArrayInputStream;
import  java.io.File;
import  java.io.IOException;
import  java.io.InputStream;
import  java.io.InputStreamReader;
import  java.lang.reflect.InvocationTargetException;
import  java.lang.reflect.Method;
import  java.net.MalformedURLException;
import  java.net.URL;
import  java.util.Properties;
import  java.util.PropertyResourceBundle;

import  org.apache.tools.ant.AntClassLoader;
import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.filters.util.ChainReaderHelper;
import  org.apache.tools.ant.types.FilterChain;
import  org.apache.tools.ant.types.Path;
import  org.apache.tools.ant.types.Reference;
import  org.apache.tools.ant.util.ClasspathUtils;

import  org.jwaresoftware.antxtras.behaviors.AntLibFriendly;
import  org.jwaresoftware.antxtras.behaviors.BuildError;
import  org.jwaresoftware.antxtras.behaviors.ProblemHandler;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.AssertableDataType;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.FixtureComponent;
import  org.jwaresoftware.antxtras.helpers.InputFileLoader;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.CloneBrokenError;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;
import  org.jwaresoftware.antxtras.parameters.CustomLoaderEnabled;
import  org.jwaresoftware.antxtras.parameters.FlexExistenceEnabled;
import  org.jwaresoftware.antxtras.parameters.FormatHint;

/**
 * Supporting type that lets you manage the definition of a Properties
 * location. Any component that needs to load a Properties by file,
 * by resource, by URL, etc&#46; can use this type to do the 
 * implementation's heavy lifting. Note that in order to trigger the
 * loader <em>to actually look for and load</em> the source you need
 * to call one of the factory methods: newBundleWrap or newProperties.
 * <p/>
 * <b>Warning:</b> for XML formatted properties ONLY THE PATH-BASED
 * sources are supported. AND you cannot create a bundle from such a
 * source (as PropertyResourceBundle does not understand).
 * <p/>
 * <b>Example Usage:</b><pre>
 *  &lt;<b>propertiesdef</b> id="shared-conf.def"
 *         resource="staging/META-INF/shared-conf.properties"/&gt;
 *
 *  &lt;<b>propertiesdef</b> id="build-messages"
 *         mustexist="yes" format="xml"
 *         file="${build.d}/${module}/feedback-messages.xml"/&gt;
 *
 *  &lt;<b>propertiesdef</b> id="modules" mustexist="yes"
 *         url="${buildserver.url}/${project}/modules"/&gt;
 *
 *  &lt;<b>propertiesdef</b> id="shared-conf.def"
 *         resource="shared-conf.properties"&gt;
 *      &lt;filterchain&gt;
 *          &lt;expandproperties/&gt;
 *      &lt;filterchain&gt;
 *  &lt;/propertiesdef&gt;
 * </pre>
 *
 * @since    JWare/AntXtras 2.0.0 (extracted from MessagesBundle)
 * @author   ssmc, &copy;2009-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,infra
 * @.caveat  For URL-based data files, assumes the Ant runtime is
 *           authorized on the targeted server(s).
 * @see      org.jwaresoftware.antxtras.messages.MessagesBundle
 **/

public class PropertiesLoaderDef extends AssertableDataType
    implements FixtureComponent, CustomLoaderEnabled, FlexExistenceEnabled,
               Cloneable, AntLibFriendly
{
    /**
     * Initializes a new PropertiesLoaderDef instance. The new
     * instance is equivalent to an empty Properties file.
     **/
    public PropertiesLoaderDef()
    {
        super(AntX.construct+"PropertiesLoaderDef:");
    }



    /**
     * Initializes a new PropertiesLoaderDef instance with a
     * custom diagnostics label.
     * @param iam cv-label (non-null)
     **/
    public PropertiesLoaderDef(String iam)
    {
        super((iam==null) ? (AntX.construct+"PropertiesLoaderDef:") : iam);
    }



    /**
     * Initializes a new PropertiesLoaderDef instance with its
     * 'mustExist' option predefined. Useful constructor when
     * this item is embedded in another object.
     * @param iam [optional] cv-label
     * @param mustExist <i>true</i> if named source must exist
     * @see #setMustExist setMustExist(&#8230;)
     **/
    public PropertiesLoaderDef(String iam, boolean mustExist)
    {
        this(iam);
        m_failIfMissing = mustExist;
    }



    /**
     * Capture our identifier for feedback since types don't
     * always get correct location information.
     **/
    public void setId(String id)
    {
        m_Id= id;
    }



    /**
     * Tries to return an unique identifier for this bundle. Looks
     * for a build-script identifier({@linkplain #setId setId});
     * if none found, creates a unique string based on type's
     * class name and instance reference.
     **/
    public final String getId()
    {
        if (m_Id!=null) {
            return m_Id;
        }
        if (isReference()) {
            return getSourceRef().getId();
        }
        return super.getId();
    }



    /**
     * Returns a human-readable description of the source of this
     * loader's properties information. Never returns <i>null</i>
     * but can return empty string if no source ever set.
     * @since JWare/AntXtras 2.0.0
     **/
    public final String getFromLabel()
    {
        return m_fromLabel;
    }



    /**
     * Returns when this loader actually read in its bytes (if a
     * remote source), or the last-modified timestamp for source
     * (if filesystem source).
     * @since JWare/AntXtras 2.1.0
     **/
    public final long getLoadTimestamp()
    {
        return m_loadTimestamp;
    }



    /**
     * Tells this loader it is part of another object's
     * implementation. This loader will defer resource loading
     * to the controlling object's class loader if it exists.
     * @param cLFactory bundle controller (non-null)
     * @since JWare/AntX 0.4
     **/
    public void setController(CustomLoaderFactoryMethod cLFactory)
    {
        m_cLFactory = cLFactory;
    }



    /**
     * Returns this loader's controller's class loader factory
     * or <i>null</i> if no such object.
     * @since JWare/AntXtras 2.0.0
     **/
    public final CustomLoaderFactoryMethod getController()
    {
        return m_cLFactory;
    }



    /**
     * Sets whether this loader will fail if it cannot locate
     * and load its properties from the specified location.
     * @param mustExist <i>true</i> if source must be loaded
     **/
    public void setMustExist(boolean mustExist)
    {
        if (isReference()) {
            throw tooManyAttributes();
        }
        m_failIfMissing = mustExist;
        edited();
    }



    /**
     * Returns <i>true</i> if the source specified for this
     * item must exist (or a default must be specified in
     * system properties). Defaults to <i>false</i>.
     **/
    public boolean getMustExist()
    {
        if (isReference()) {
            return getSourceRef().getMustExist();
        }
        return m_failIfMissing;
    }


// ---------------------------------------------------------------------------------------
// Factory methods for Properties
// ---------------------------------------------------------------------------------------

    /**
     * Builder method that returns a Properties object based on this loader's 
     * source contents and the optional filter chain. Never returns <i>null</i>.
     * If incoming Properties reference is <i>null</i> a new Properties object
     * is created; otherwise, the new data is loaded into the existing Properties
     * (with unconditional overwrite of pre-existing properties with same keys).
     * @param p [optional] custom Properties object to fill in.
     * @param fc [optional] custom preprocessor of filters (applied before properties read)
     * @param errH [optional] callback if load problem occurs
     * @throws BuildException if unable to load properties content.
     * @since JWare/AntXtras 2.1.0
     **/
    public synchronized Properties newProperties(Properties p, FilterChain fc, ProblemHandler errH)
    {
        if (isReference()) {
            p = getSourceRef().newProperties(p,fc,errH);
            if (!triedLoadOnce()) {
                setTriedLoadOnce(getSourceRef().isWellFormed());
            }
            return p;
        }
        if (!triedLoadOnce()) {
            tryLoadSource(errH);
        }
        try {
            if (p==null) {
                p = new Properties();
            }
            if (isWellFormed()==Boolean.TRUE && getBytes().length>0) {
                if (isXMLTrue()) {
                    loadXMLFormatIfJRE5(p,fc,false);
                } else {
                    p.load(getInputStream(getBytes(),fc));
                }
            }
            return p;
        } catch(IOException iox) {
            String error = IllegalFormat(Tk.messageFrom(iox),false);
            throw new BuildError(error,getLocation(),iox);
        }
    }



    /**
     * Builder method that returns a Properties object based on this loader's
     * source contents only. Never returns <i>null</i>. If incoming 
     * Properties reference is <i>null</i> a new Properties object is created;
     * otherwise, the new data is loaded into the existing Properties (with
     * unconditional overwrite of pre-existing properties with same keys).
     * @param p [optional] custom Properties object to fill in.
     * @param errH [optional] callback if load problem occurs
     * @throws BuildException if unable to load properties content.
     * @since JWare/AntXtras 2.0.0
     **/
    public synchronized Properties newProperties(Properties p, ProblemHandler errH)
    {
        return newProperties(p,null,errH);
    }


    /**
     * Variant of {@linkplain #newProperties(Properties, ProblemHandler)}
     * that uses a newly created standard Properties object.
     * @param errH [optional] callback if load problem occurs
     */
    public synchronized Properties newProperties(ProblemHandler errH)
    {
        return newProperties(null,errH);
    }



    /**
     * Returns a new PropertyResourceBundle backed by this loader's 
     * properties contents and optional filter chain. Adapter factory 
     * method that never returns <i>null</i>. Only works for standard 
     * Property formatted sources (XML format is not supported by the 
     * Java PropertyResourceBundle class).
     * @param fc [optional] custom preprocessor of filters (applied before properties read)
     * @param errH [optional] callback if load problem occurs
     * @throws BuildException if unable to load properties content.
     * @since JWare/AntXtras 2.1.0
     **/
    public synchronized final PropertyResourceBundle newBundleWrap(FilterChain fc, ProblemHandler errH)
    {
        PropertyResourceBundle prb;
        if (isReference()) {
            prb=getSourceRef().newBundleWrap(fc,errH);
            if (!triedLoadOnce()) {
                setTriedLoadOnce(getSourceRef().isWellFormed());
            }
            return prb;
        }

        if (!triedLoadOnce()) {
            tryLoadSource(errH);
        }
        try {
            byte[] data = getBytes();
            boolean xml = isXMLTrue();
            if (isWellFormed()!=Boolean.TRUE || xml) {
                data = NO_BYTES;
                fc = null;//SKIPPED!
                String why = xml ? "(XML)" : "";
                String error = uistrs().get("task.uism.err.invalid.format",why);
                log(error,Project.MSG_WARN);
            }
            prb = new PropertyResourceBundle(getInputStream(data,fc));
        } catch(IOException iox) {
            throw new BuildError(iox.getMessage());//NB:never...
        }
        return prb;
    }


    
    /**
     * Returns a created PropertyResourceBundle backed by this
     * loader's properties contents. Adapter factory method that
     * never returns <i>null</i>. Only works for standard Property
     * formatted sources (XML format is not supported by the Java
     * PropertyResourceBundle class).
     * @param errH [optional] callback if load problem occurs
     * @throws BuildException if unable to load properties content.
     **/
    public final PropertyResourceBundle newBundleWrap(ProblemHandler errH)
    {
        return newBundleWrap(null,errH);
    }



    /**
     * Returns a clone of this loader definition. Supports passing of
     * PropertiesLoaderDef between project and sub-projects. If this
     * loader is a reference to another, that loader's clone
     * method is invoked.
     * @since JWare/AntX 0.3
     **/
    public Object clone()
    {
        if (isReference()) {
            return getSourceRef().clone();
        }
        try {
            PropertiesLoaderDef copy = (PropertiesLoaderDef)super.clone();
            if (m_file!=null) {
                copy.m_file = new File(m_file.getPath());
            }
            if (m_URL!=null) {
                copy.m_URL = new URL(m_URL.toString());
            }
            if (m_bytes.length>0) {
                byte[] newbytes = new byte[m_bytes.length];
                System.arraycopy(m_bytes,0,newbytes,0,m_bytes.length);
                copy.setBytes(newbytes);
            }
            return copy;
        } catch (MalformedURLException mfx) {
            throw new BuildException(mfx);
        } catch(CloneNotSupportedException clnx) {
            throw new CloneBrokenError();
        }
    }


    /**
     * Factory method for the input data reader that will account for
     * custom client-supplied filter chains. If a filter chain is
     * setup, this method might effectively (re)read the data multiple
     * times depending on the type of filters used. However, the original
     * properties def source is still read ONCE (it is the input).
     * @param data the original data as read from this definition's source (non-null)
     * @param fc [optional] filter chain to be applied to data <em>before</em> returned.
     * @return the data to be read as the properties (post-filtering)
     * @throws IOException if read or filtering processors do.
     **/
    private InputStream getInputStream(byte[] data, FilterChain fc) throws IOException
    {
        //If no filters, do nothing. Note that an empty input stream is
        //NOT short-circuited because a filter might change that state!
        if (fc==null || fc.getFilterReaders().isEmpty()) {
            return new ByteArrayInputStream(data);
        }
        log("About to filter loaded properties stream",Project.MSG_DEBUG);
        ChainReaderHelper crh = new ChainReaderHelper();
        crh.setProject(getProject());
        crh.setBufferSize(InputFileLoader.BUFSIZ);
        crh.setPrimaryReader(new InputStreamReader(new ByteArrayInputStream(data),"8859_1"));
        crh.filterChains.add(fc);
        String filtered = crh.readFully(crh.getAssembledReader());
        return new ByteArrayInputStream(filtered.getBytes("8859_1"));
    }

// ---------------------------------------------------------------------------------------
// Datasources as URLs
// ---------------------------------------------------------------------------------------

    /**
     * Sets this loader's source properties as a URL.
     * @param urlstr URL string representation (non-null)
     * @throws BuildException if this loader is reference to another
     *         or if another source has already been specified.
     **/
    public void setURL(String urlstr)
    {
        require_(urlstr!=null,"setURL- nonzro url");
        if (isReference()) {
            throw tooManyAttributes();
        }
        checkNewDatasource();
        m_URLstr = urlstr;
        m_URL = null;
        m_fromLabel = "url:"+urlstr;
        edited("url");
    }



    /**
     * Returns this loader's resource's URL location. Returns
     * <i>null</i> if never set or was set to an invalid
     * URL string.
     **/
    public final URL getURL()
    {
        if  (isReference()) {
            return getSourceRef().getURL();
        }
        if (m_URL!=null) {
            return m_URL;
        }
        if (m_URLstr!=null) {
            try {
                m_URL = new URL(m_URLstr);
            } catch(MalformedURLException mfx) {
                log(uistrs().get("task.uism.err.bad.url",m_URLstr), Project.MSG_ERR);
            }
        }
        return m_URL;
    }


    /**
     * Opens URL connection, copies returned output to this loader as raw
     * Properties information. This method assumes URL's contents are in
     * the standard Properties format including character encoding.
     * @param url the url to be read (non-null)
     * @return <i>true</i> if read and stored successfully
     * @see InputFileLoader
     **/
    protected final boolean copyURLStreamToSelf(URL url)
    {
        boolean copied=false;
        try {
            setBytes(new InputFileLoader().loadURL(url));//NB:assumin iso8851-1
            m_loadTimestamp = System.currentTimeMillis();
            log("Copied properties contents URL("+url+") to buffer",Project.MSG_DEBUG);
            copied=true;
        } catch(IOException iox) {
            log(uistrs().get("task.uism.err.loading.url",
                             url.toString(),Tk.messageFrom(iox)), 
                Project.MSG_ERR);
        }
        return copied;
    }



    /**
     * Shared grunt work for specify-by-url or specifiy-by-resource.
     * @param url the url to be checked and/or loaded (non-null)
     **/
    protected final boolean handleThisURL(URL url)
    {
        File f = Tk.toFile(url);
        if (f==null) {
            return copyURLStreamToSelf(url);
        }
        if (f.canRead()) {
            boolean OK = copyURLStreamToSelf(url);
            if (OK) {
                m_file = f;
                m_loadTimestamp = f.lastModified();
            }
            return OK;
        } 
        log(uistrs().get("task.uism.err.bad.file",f.getPath(),"unreadable or not file"),
            Project.MSG_ERR);
        return false;
    }



    /**
     * Checks if this loader has been specified as a URL. If it
     * has this method  tries to load the URL's raw contents
     * immediately to this loader's byte buffer for holding.
     * @return <i>true</i> if url was defined and was loaded.
     **/
    protected final boolean handleURL()
    {
        URL url = getURL();

        return (url!=null) ? handleThisURL(url) : false;
    }

// ---------------------------------------------------------------------------------------
// Datasources as Files
// ---------------------------------------------------------------------------------------

    /**
     * Sets this loader's source Properties's location as a file.
     * @param filepath the readable file path (non-null)
     * @throws BuildException if this loader is reference to another
     *         or if another source has already been specified.
     **/
    public void setFile(String filepath)
    {
        require_(filepath!=null,"setFile- nonzro filepath");
        if (isReference()) {
            throw tooManyAttributes();
        }
        checkNewDatasource();
        m_file = getProject().resolveFile(filepath);
        m_fromLabel = "file:"+filepath;
        edited("file");
    }



    /**
     * Returns this loader's Properties's file location. Returns
     * <i>null</i> if never set (or determined from other
     * datasource type).
     **/
    public final File getFile()
    {
        if  (isReference()) {
            return getSourceRef().getFile();
        }
        return m_file;
    }



    /**
     * Tells this loader the format of the named source explicitly.
     * One of [xml|properties].
     * @since JWare/AntXtras 2.0.0
     **/
    public void setFormat(String value)
    {
        require_(value!=null,"setFormat- nonzro format");
        if (isReference()) {
            throw tooManyAttributes();
        }
        FormatHint hint = FormatHint.from(value);
        if (hint!=FormatHint.PROPERTIES && hint!=FormatHint.XML) {
            String error = Errs.IllegalParameterValue(getTypeName(),"format",value);
            throw new BuildException(error,getLocation());
        }
        this.m_formatHint = hint;
    }



    /**
     * Returns this loader's source's format indicator. Will
     * return <i>null</i> if never set (in which case assumes
     * 'properties' format).
     * @since JWare/AntXtras 2.0.0
     **/
    public final FormatHint getFormat()
    {
        if  (isReference()) {
            return getSourceRef().getFormat();
        }
        return m_formatHint;
    }



    /**
     * Checks if this loader has been specified as a File. If it
     * has, this method tries to load the file's raw contents
     * immediately to this loader's byte buffer for holding.
     * @return <i>true</i> if file was defined and was loaded.
     **/
    protected final boolean handleFile()
    {
        File f = getFile();
        if (f!=null) {
            if (f.canRead()) {
                try {
                    URL furl = AntXFixture.fileUtils().getFileURL(f);
                    boolean OK = copyURLStreamToSelf(furl);
                    if (OK) {
                        m_URL = furl;
                        m_loadTimestamp = f.lastModified();
                    }
                    return OK;
                } catch(MalformedURLException mfx) {
                    log(uistrs().get("task.uism.err.bad.file",f.getPath(),Tk.messageFrom(mfx)),
                        Project.MSG_ERR);
                }
            } else {
                log(uistrs().get("task.uism.err.bad.file",f.getPath(),"unreadable or not file"),
                    Project.MSG_ERR);
            }
        }
        return false;
    }

// ---------------------------------------------------------------------------------------
// Datasources as Resources
// ---------------------------------------------------------------------------------------

    /**
     * Creates and returns a new classpath element from this
     * loader's custom resource search path. Returned path
     * must be configured by caller.
     **/
    public Path createClassPath()
    {
        return getCLSpi(true).createClasspath();
    }



    /**
     * Returns this loader's custom classpath. Returns
     * <i>null</i> if never created.
     **/
    public final Path getClassPath()
    {
        if  (isReference()) {
            return getSourceRef().getClassPath();
        }
        if (getOwnCLSpi()!=null) {
            return getOwnCLSpi().getClasspath();
        }
        return null;
    }



    /**
     * Adds a new classpath element to this loader's
     * custom classpath.
     * @param classpath additional classpath element (non-null)
     */
    public void setClassPath(Path classpath)
    {
        require_(classpath!=null,"setClasPath- nonzro path");
        getCLSpi(false).setClasspath(classpath);
    }



    /**
     * Adds a new classpath by-reference to this loader's
     * custom classpath.
     * @param r reference to existing classpath item (non-null)
     */
    public void setClassPathRef(Reference r)
    {
        require_(r!=null,"setClasPathRef- nonzro ref");
        getCLSpi(false).setClasspathref(r);
    }



    /**
     * Tells this loader to use an existing classloader to
     * search for and load resources. If loader does not
     * exist, and this loader has a custom class path, a
     * new class loader will be stored under this reference's id.
     * @param r reference to an existing ClassLoader (non-null)
     * @since JWare/AntX 0.4
     **/
    public void setLoaderRef(Reference r)
    {
        require_(r!=null,"setLoaderRef- nonzro ref");
        getCLSpi(false).setLoaderRef(r);
    }



    /**
     * Returns this loader's class loader's identifier based 
     * on its <em>current</em> configuration. Returns <i>null</i>
     * if never defined (directly or indirectly through a
     * classpath reference).
     * @since JWare/AntX 0.4
     **/
    public String getLoaderRefId()
    {
        if  (isReference()) {
            return getSourceRef().getLoaderRefId();
        }
        if (getOwnCLSpi()!=null) {
            return getOwnCLSpi().getClassLoadId();
        }
        return null;
    }



    /**
     * Sets this loader's resource bundle's as a
     * classpath-based resource base name.
     * @throws BuildException if this loader is reference
     *         to another or if another source has already
     *         been specified.
     **/
    public void setResource(String resource)
    {
        require_(resource!=null,"setResource- nonzro resource");
        if (isReference()) {
            throw tooManyAttributes();
        }
        checkNewDatasource();
        m_resource = resource;
        m_fromLabel = "resource:"+resource;
        edited("resource");
    }



    /**
     * Returns this loader's resource location as a classpath-
     * based resource base name (slash-delimited). Returns
     * <i>null</i> if never set.
     **/
    public final String getResource()
    {
        if  (isReference()) {
            return getSourceRef().getResource();
        }
        return m_resource;
    }



    /**
     * Shared grunt work for specify-by-resource-path and a 
     * determined class loader (or not). Fallback implementation
     * that assumes resource is a path NOT a bundle base name.
     * @param resource the resource to be loaded (non-null)
     * @param cL [optional] the controlling class loader
     * @return <i>true</i> if loaded
     **/
    protected final boolean handleThisResource(String resource, ClassLoader cL)
    {
        boolean OK=false;
        URL url;

        if (cL==null) { //possible re: Class.getClassLoader() javadocs
            url = LocalTk.getSystemResource(resource,getProject());
        } else {
            url = cL.getResource(resource);
        }

        if (url!=null) {
            log("Found resource ("+resource+"); trying load",Project.MSG_DEBUG);
            OK = handleThisURL(url);
            if (OK) {
                m_URL = url;
            }
        } else {
            log(uistrs().get("task.uism.err.bad.resource",resource),
                Project.MSG_ERR);
        }
        return OK;
    }



    /**
     * Shared grunt work for specify-by-resource.
     * @param resource the resource to be loaded (non-null)
     **/
    protected boolean handleThisResource(String resource)
    {
        boolean OK=false;

        AntClassLoader AcL=null;
        ClassLoader cL=null;
        final Project P= getProject();

        if (P!=null && getOwnCLSpi()!=null) {
            AcL = (AntClassLoader)getOwnCLSpi().getClassLoader();
            cL = AcL;
        } else if (getController()!=null) {
            cL = getController().getClassLoader();
        }
        if (cL==null) {
            cL = this.getClass().getClassLoader();//NB: can be null
        }

        OK = handleThisResource(resource, cL);

        if (AcL!=null) {
            if (getOwnCLSpi().getClassLoadId()==null) {
                AcL.cleanup();
            }
            AcL=null;
        }
        return OK;
    }



    /**
     * Checks if this loader's source has been specified as a class
     * or system resource. If it has, this method tries to immediately
     * load the resource's raw contents to this loader's byte buffer.
     * @return <i>true</i> if resource defined, read, and
     *         loaded successfully.
     **/
    protected final boolean handleResource()
    {
        boolean OK = false;
        String resource = getResource();

        if (resource!=null) {
            OK = handleThisResource(resource);
        }

        return OK;
    }

// ---------------------------------------------------------------------------------------
// Loading Properties to in-memory buffer:
// ---------------------------------------------------------------------------------------

    /**
     * Common implemenation datetype name for this loader 
     * def (or subclass). Not necessarily same as public type
     * declared name.
     **/
    protected String getCN()
    {
        return "propertiesdef";
    }



    /**
     * Returns the PropertiesLoaderDef referenced by this instance.
     * @throws BuildException if reference is not valid.
     **/
    protected PropertiesLoaderDef getSourceRef()
    {
        return (PropertiesLoaderDef)getCheckedRef
                    (PropertiesLoaderDef.class,getCN());
    }



    /**
     * Returns <i>true</i> if we've tried to load this loader's
     * raw Properties information at least once. Public to allow
     * testing of this class and subclasses.
     **/
    public final boolean triedLoadOnce()
    {
        return m_isInited;
    }



    /**
     * Toggles this loader's "tried to load" flag to ON. Latch;
     * once toggled can't flip back.
     * @since JWare/AntXtras 2.0.0 
     **/
    protected final void setTriedLoadOnce(Boolean wellformed)
    {
        m_isInited = true;
        m_isWellformed = wellformed;
    }



    /**
     * Returns <i>true</i> if we've loaded the source's contents
     * and verified whether a Properties object is readable from
     * it. Will return <i>null</i> if haven't read source yet.
     **/
    protected final Boolean isWellFormed()
    {
        return m_isWellformed;
    }



    /**
     * Returns this loader's custom class path helper. Never
     * returns <i>null</i>.
     * @.safety single
     * @since JWare/AntX 0.4
     **/
    private final ClasspathUtils.Delegate getCLSpi(boolean subel)
    {
        if (isReference()) {
            if (subel) {
                throw noChildrenAllowed();
            }
            throw tooManyAttributes();
        }
        if (m_CLspi==null) {
            m_CLspi= ClasspathUtils.getDelegate(this);
            edited("classloader");
        }
        return m_CLspi;
    }



    /**
     * Returns this loader's custom class path helpers reference
     * as-is. Will return <i>null</i> if helper not initialized.
     **/
    protected final ClasspathUtils.Delegate getOwnCLSpi()
    {
        return m_CLspi;
    }



    /**
     * Something about source has been determined to be invalid
     * (either can't read, can't load, invalid properties format,
     * or something).
     * @param errH [optional] problem handler from caller
     **/
    private void invalidSource(ProblemHandler errH, Throwable cause) 
    {
        boolean optional = !getMustExist();
        String error = uistrs().get("task.uism.err.invalid.setup");
        int noiselevel = optional ? Project.MSG_WARN : Project.MSG_ERR;
        if (errH!=null) {
            errH.problem(error, noiselevel);
        } else {
            log(error, noiselevel);
        }
        if (!optional) {
            throw new BuildException(error,cause,getLocation());
        }
    }



    /**
     * Tries to load the raw properties contents into our in
     * memory byte buffer. Loading order has following precedence:<ol>
     *  <li>File attribute</li>
     *  <li>Resource attribute</li>
     *  <li>URL attribute</li>
     * </ol>
     **/
    protected final void tryLoadSource(ProblemHandler errH) throws BuildException
    {
        if (!triedLoadOnce()) {
            if (!handleFile() &&
                !handleResource() &&
                !handleURL()) {
                invalidSource(errH,null);
            }
            setTriedLoadOnce(null);
            checkMalformedContents(errH);
        }
    }


    /**
     * Sets flag that indicates whether a properties object
     * can be read from the bytes we've ingested.
     **/
    private void checkMalformedContents(ProblemHandler errH)
    {
        this.m_isWellformed = Boolean.TRUE;
        if (getBytes().length>0) {
            Properties test = new Properties();
            try {
                if (isXMLTrue()) {
                    loadXMLFormatIfJRE5(test,null,true);
                } else {
                    test.load(getInputStream(getBytes(),null));
                }
            } catch(Exception loadX) {
                this.m_isWellformed = Boolean.FALSE;
                invalidSource(errH,loadX);
            }
            test = null;
        }
    }


    /**
     * Called whenever a source-attribute is defined; ensure at most
     * one source is defined.
     **/
    private void checkNewDatasource()
    {
        if (m_Nsources>0) {
            throw new BuildException(AntX.uistrs().get
                    ("task.uism.err.too.many.sources"));
        }
        m_Nsources++;
    }



    /**
     * Returns this loader's raw Properties definition information.
     * Never returns <i>null</i> but can be empty byte array if
     * never loaded or was unable to load.
     **/
    private byte[] getBytes()
    {
        return m_bytes;
    }



    /**
     * Changes this loader's raw Properties definition information.
     * @.safety single
     **/
    protected final void setBytes(byte[] bytes)
    {
        require_(bytes!=null,"setBytes- nonzro byts");
        m_bytes = bytes;
    }


    
    /**
     * Returns indicator of whether or not source is in the XML
     * format. Can only determine (for sure) if an explicit source
     * name (like file) was given. Returns <i>null</i> if this
     * loader doesn't know.
     **/
    public final Boolean getXMLFlag()
    {
        Boolean flag = null;//Don't know...
        FormatHint hint = getFormat();
        if (hint!=null) {
            flag = Boolean.valueOf(FormatHint.XML==hint);
        } else {
            URL url = getURL();//NB:we try to map this when we can!
            if (url!=null) {
                String path = url.getPath();
                if (path!=null && path.length()>0) {
                    flag = Boolean.valueOf(path.toLowerCase().endsWith(".xml"));
                }
            }
            if (flag==null && getFile()!=null) {
                String path = getFile().getName();
                flag = Boolean.valueOf(path.toLowerCase().endsWith(".xml"));
            }
        }
        return flag;
    }


    /**
     * Convenient test against {@linkplain #getXMLFlag()} to see
     * if returned value is explicitly set "true".
     **/
    public final boolean isXMLTrue()
    {
        return Boolean.TRUE.equals(getXMLFlag());
    }


    private final String IllegalFormat(String why, boolean quiet)
    {
        String error = uistrs().get("task.uism.err.invalid.format",why);
        if (!quiet) {
            log(error,Project.MSG_ERR);
        }
        return error;
    }


    /**
     * Allow us to work with both JDK 1.4.x and JDK 1.5.x until
     * AntXtras v3 series. Properties.loadFromXML belongs to 
     * JRE 1.5.x only.
     * @since JWare/AntXtras 2.0.0
     */
    private static Class[] BYXML_SIG = new Class[]{java.io.InputStream.class};
    private void loadXMLFormatIfJRE5(Properties p, FilterChain fc, boolean preflight)
    {
        try {
            Method m = Properties.class.getDeclaredMethod("loadFromXML", BYXML_SIG);
            Object[] args = new Object[] {getInputStream(getBytes(),fc)};
            m.invoke(p, args);
        } catch(InvocationTargetException xwrap) {
            Throwable underneath = xwrap.getCause();
            String error = IllegalFormat("("+Tk.messageFrom(underneath)+")",preflight);
            RuntimeException rtx;
            if (underneath instanceof RuntimeException) {
                rtx = (RuntimeException)underneath; 
            } else {
                rtx = new BuildException(error,underneath,getLocation());
            }
            throw rtx;
        } catch(Exception otherx) {
            String error = IllegalFormat("("+Tk.messageFrom(otherx)+")",preflight);
            RuntimeException rtx;
            if (otherx instanceof RuntimeException) {
                rtx = (RuntimeException)otherx; 
            } else {
                rtx = new BuildException(error,otherx,getLocation());
            }
            throw rtx;
        }
    }


    private File m_file;
    private String m_URLstr;
    private URL m_URL;
    private String m_resource;
    private String m_fromLabel="";
    private long m_loadTimestamp;
    private ClasspathUtils.Delegate m_CLspi;//NB:lazy-inited
    private boolean m_failIfMissing;//NB:=> empty bundle
    private CustomLoaderFactoryMethod m_cLFactory;//NB:=>standalone-type

    private static byte[] NO_BYTES = new byte[0];
    private boolean m_isInited;
    private Boolean m_isWellformed;
    private byte[] m_bytes= NO_BYTES;//NB:=> like empty bundle!
    private int m_Nsources=0;//NB:number of sources defined (0..1)
    private String m_Id;
    private FormatHint m_formatHint;//NB:=> standard properties
}

/* end-of-PropertiesLoaderDef.java */
