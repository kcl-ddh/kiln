/**
 * $Id: IsXDefFunctionShortcut.java 766 2009-04-11 13:08:49Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.condition;

import  org.apache.tools.ant.ComponentHelper;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that returns "true" or "false" depending on 
 * whether the named Ant component is already defined. This handler 
 * works for any Ant type (taskdef or typedef). The general form of 
 * the URI: <span class="src">$istype:<nobr>typename</nobr></span>.
 * <p/>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;do if="emma.present" false="${$istask:emma}"&gt;
 *     <i>[&#8230;Install emma task here]</i>
 *    &lt;/do&gt;
 *
 * <b>2)</b> -- To Install and Enable --
 *  &lt;managefuncuts action="enable"&gt;
 *     &lt;parameter name="istask"
 *          value="${ojaf}.condition.IsXDefFunctionShortcut"/&gt;
 *     &lt;parameter name="istype"
 *          value="${ojaf}.condition.IsXDefFunctionShortcut"/&gt;
 *  &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class IsXDefFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initalizes a new type check function shortcut.
     **/
    public IsXDefFunctionShortcut()
    {
        super();
    }


    /**
     * Returns "true" if the named item is already defined 
     * in the current Ant type system.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        String typename = uriFragment;
        int i = uriFragment.indexOf("?");
        if (i>=0) {
            typename = uriFragment.substring(0,i);
        }
        ComponentHelper ch = ComponentHelper.getComponentHelper(clnt.getProject());
        return String.valueOf(ch.getDefinition(typename)!=null);
    }
}

/* end-of-IsXDefFunctionShortcut.java */