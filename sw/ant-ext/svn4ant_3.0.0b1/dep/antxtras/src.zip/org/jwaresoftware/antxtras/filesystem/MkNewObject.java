/**
 * $Id: MkNewObject.java 425 2008-04-27 02:31:31Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.filesystem;

import  java.lang.reflect.Constructor;
import  java.io.File;
import  java.io.FileOutputStream;
import  java.io.IOException;
import  java.io.PrintWriter;
import  java.net.URL;
import  java.util.Iterator;
import  java.util.List;
import  java.util.Properties;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.FilterSet;
import  org.apache.tools.ant.types.FilterSetCollection;
import  org.apache.tools.ant.types.Path;
import  org.apache.tools.ant.types.PropertySet;
import  org.apache.tools.ant.types.Reference;
import  org.apache.tools.ant.util.ClasspathUtils;
import  org.apache.tools.ant.util.FileUtils;

import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.ownhelpers.LocalTk;
import  org.jwaresoftware.antxtras.parameters.CustomLoaderEnabled;
import  org.jwaresoftware.antxtras.starters.StringItemListHandle;

/**
 * Skeleton starter for tasks that create or copy file system objects. Implements
 * the common "copy prototype" functionality.
 *
 * @since    JWare/AntX 0.3 (Extracted from MkTempObject)
 * @author   ssmc, &copy;2003-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,helper
 **/

public abstract class MkNewObject extends AssertableTask implements CustomLoaderEnabled
{
    /**
     * Initializes a new MkNewObject instance.
     **/
    protected MkNewObject(String iam)
    {
        super(iam);
    }


    /**
     * Sets the property into which a URL representation of the
     * temp directory's path is copied.
     * @param urlproperty the property's name (non-null)
     * @since JWare/AntX 0.5
     **/
    public void setUrlProperty(String urlproperty)
    {
        require_(urlproperty!=null,"setUrlProp- nonzro name");
        m_updateUrlProperty = urlproperty;
    }



    /**
     * Returns the name of the property into which a URL representation
     * of the temp directory's path will be stored. Returns <i>null</i>
     * if never set explicitly.
     * @since JWare/AntX 0.5
     **/
    public final String getUrlPathProperty()
    {
        return m_updateUrlProperty;
    }


    /**
     * Returns <i>true</i> if this task will try to mark all created
     * prototype copies as delete-on-exit. Returns <i>false</i> by
     * default.
     **/
    public boolean isAutoDelete()
    {
        return false;
    }


    /**
     * Sets this task's prototype source file.
     * @param copyFrom prototype file's path (non-null)
     * @see #getPrototypePlainFile
     **/
    public void setCopyFile(File copyFrom)
    {
        require_(copyFrom!=null,"setCopy- nonzro src file");
        require_(copyFrom.canRead(), "setCopy- existing readable file/dir");
        m_copyFromFile= copyFrom;
    }


    /**
     * Returns this task's prototype source file. Returns
     * <i>null</i> if never specified.
     **/
    public File getPrototypePlainFile()
    {
        return m_copyFromFile;
    }


    /**
     * Sets this task's prototype class-based resource.
     * @param copyFrom resource's name (non-null)
     * @see #getPrototypeResourceFile
     **/
    public void setCopyResource(String copyFrom)
    {
        require_(!Tk.isWhitespace(copyFrom),"setCopyRez- nonzro rez name");
        m_copyFromResource = copyFrom;
    }


    /**
     * Returns this task's prototype class-based resource. Returns
     * <i>null</i> if never specified.
     **/
    public String getPrototypeResource()
    {
        return m_copyFromResource;
    }



    /**
     * Adds a new classpath by-reference to this task's custom
     * classpath for loading resources.
     * @param r reference to existing classpath item (non-null)
     * @since JWare/AntX 0.6
     **/
    public void setClassPathRef(Reference r)
    {
        require_(r!=null,"setClzpathRef- nonzro ref");
        getCLSpi().setClasspathref(r);
    }



    /**
     * Returns this task's custom classpath for loading resources.
     * Returns <i>null</i> if ever created.
     * @since JWare/AntX 0.6
     **/
    public final Path getClassPath()
    {
        if (m_CLspi!=null) {
            return m_CLspi.getClasspath();
        }
        return null;
    }


    /**
     * Tells this task to use an existing classloader to
     * search for and load provider class. If loader does not exist,
     * and this task has a custom class path, a new class loader
     * will be stored under this reference's id.
     * @param r reference to an existing ClassLoader (non-null)
     * @since JWare/AntX 0.6
     **/
    public void setLoaderRef(Reference r)
    {
        require_(r!=null,"setLodrRef- nonzro ref");
        getCLSpi().setLoaderRef(r);
    }



    /**
     * Returns this task's own loader identifier based on
     * its <em>current</em> configuration. Returns <i>null</i>
     * if never defined (directly or indirectly through a classpath
     * reference).
     * @since JWare/AntX 0.6
     **/
    public String getLoaderRefId()
    {
        if (m_CLspi!=null) {
            return m_CLspi.getClassLoadId();
        }
        return null;
    }



    /**
     * Returns this task's custom class path helper. Never returns <i>null</i>.
     * @.safety single
     * @since JWare/AntX 0.6
     **/
    private final ClasspathUtils.Delegate getCLSpi()
    {
        if (m_CLspi==null) {
            m_CLspi= ClasspathUtils.getDelegate(this);
        }
        return m_CLspi;
    }



    /**
     * Returns this task's prototype resource's actual file.
     * Returns <i>null</i> if never defined. All prototype resources
     * must resolve to physical files.
     * @throws BuildException if cannot do conversion (or resource is
     *         not a file)
     **/
    public File getPrototypeResourceFile()
    {
        if (m_copyFromRezFile==null && getPrototypeResource()!=null) {
            File rezfile = getFileFromResource(getPrototypeResource());
            m_copyFromRezFile = rezfile;
        }
        return m_copyFromRezFile;
    }


    /**
     * Adds a new filterset to use when copying prototype files.
     * @since JWare/AntX 0.2
     **/
    public void addFilterSet(FilterSet filters)
    {
        require_(filters!=null,"addFiltrs- nonzro filtrs");
        getCopyFiltersNoNull().addFilterSet(filters);
    }


    /**
     * Returns <i>true</i> if either a prototype file or prototype
     * resource has been defined.
     * @.sideeffect Will convert prototype resource name into actual file
     **/
    protected final boolean needToCopyFile()
    {
        return (getPrototypePlainFile()!=null ||
                getPrototypeResourceFile()!=null);
    }


    /**
     * Converts a named class resource to a filesystem entity.
     * @throws BuildException if cannot do conversion (or resource is
     *         not a file)
     **/
    protected final File getFileFromResource(String resource)
        throws BuildException
    {
        require_(resource!=null,"rezToFile- nonzro rez");
        URL url = null;

        ClassLoader cl = getClass().getClassLoader();
        if (m_CLspi!=null) {
            cl = m_CLspi.getClassLoader();
        }
        if (cl!=null) {
            url = cl.getResource(resource);
        }
        if (url==null) {
            url = LocalTk.getSystemResource(resource,getProject());
        }
        File rezfile = null;
        if (url!=null) {
            rezfile = Tk.toFile(url);
            if (rezfile!=null && !rezfile.canRead()) {
                rezfile=null;
            }
        }
        if (rezfile==null) {
            String ermsg = uistrs().get("mktemp.cant.read.resource",resource);
            log(ermsg, Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
        return rezfile;
    }


    /**
     * Copies the prototype file to a target directory. Any defined
     * filters are automatically applied to the new destination file. Will
     * mark new file for deletion-on-exit if {@linkplain #isAutoDelete
     * isAutoDelete} returns <i>true</i>.
     * @param fromFile source prototype file (non-null)
     * @param inDir target directory (non-null, must exist)
     * @throws IOException if unable to copy file
     **/
    protected File copyPrototypeFile(File fromFile, File inDir)
        throws IOException
    {
        File toFile = new File(inDir, fromFile.getName());

        getFileUtils().copyFile(fromFile,toFile,getCopyFilters(),false);

        if (isAutoDelete()) {
            toFile.deleteOnExit();
        }
        return toFile;
    }



    /**
     * Returns this task's pre-allocated Ant file utilities helper.
     **/
    protected final FileUtils getFileUtils()
    {
        return AntXFixture.fileUtils();
    }


    /**
     * Returns this task's underlying filterset collection. Will
     * return <i>null</i> if no filters ever added.
     * @.safety single
     **/
    protected final FilterSetCollection getCopyFilters()
    {
        return m_copyFilters;
    }


    /**
     * Returns this task's underlying filterset collection
     * creating a new empty collection if necessary.
     * @.safety single
     **/
    protected final FilterSetCollection getCopyFiltersNoNull()
    {
        if (m_copyFilters==null) {
            m_copyFilters = new FilterSetCollection();
        }
        return m_copyFilters;
    }


    /**
     * Returns this task's list of prototype file lines creating
     * a new empty list if necessary. Contents of this list must
     * be either InnerStrings, Strings, or some other stringifiable
     * object.
     * @since JWare/AntX 0.3
     **/
    protected List getPrototypeLinesNoNull()
    {
        if (m_prototypeLines==null) {
            m_prototypeLines = AntXFixture.newList();
        }
        return m_prototypeLines;
    }


    /**
     * Returns this task's list of prototype file line contents.
     * Will return <i>null</i> if not lines added to this task.
     * @since JWare/AntX 0.3
     **/
    protected List getPrototypeLines()
    {
        return m_prototypeLines;
    }


    /**
     * Copies this task's list of prototype file line contents
     * to existing file. Does nothing if no prototype lines defined.
     * @param newFile the target file (non-null)
     * @param append <i>true</i> if lines should be appended
     * @since JWare/AntX 0.3
     * @throws BuildException if any I/O error occurs or lines improperly
     *         defined.
     **/
    protected void copyPrototypeLines(File newFile, boolean append)
    {
        List l = getPrototypeLines();
        if (l!=null && !l.isEmpty()) {
            try {
                final Project P = getProject();
                FileOutputStream fos = newFOS(newFile,append);
                PrintWriter w = new PrintWriter(fos);
                for (int i=0,N=l.size();i<N;i++) {
                    Object o = l.get(i);
                    if (o instanceof StringItemListHandle) {
                        Iterator itr= ((StringItemListHandle)o).readonlyStringIterator(P);
                        while (itr.hasNext()) {
                            w.println(itr.next().toString());
                        }
                    } else if (o instanceof PropertySet) {
                        Properties ps = ((PropertySet)o).getProperties();
                        if (!ps.isEmpty()) {
                            w.flush();
                            ps.store(fos,null);
                        }
                        ps.clear();
                        ps=null;//gc
                    } else {
                        w.println(Iteration.lenientStringifer().stringFrom(o,P));
                    }
                }
                w.flush();
                w.close();
            } catch(IOException iox) {
                throw new BuildException(iox,getLocation());
            }
        }
    }



    /**
     * Apply any common update properties to final file system object.
     * @param finalObject file system object (non-null)
     * @param strict <i>true</i> if should fail if unable to set update properties
     * @since JWare/AntX 0.5
     **/
    protected void saveFinalPath(File finalObject, boolean strict)
    {
        if (getUrlPathProperty()!=null) {
            checkIfProperty_(getUrlPathProperty(),!strict);
            String urlPath = AntXFixture.fileUtils().toURI(finalObject.getPath());
            getProject().setNewProperty(getUrlPathProperty(),urlPath);
        }
    }



    /**
     * Create a FileOutputStream with custom append option if active
     * JVM supports it.
     **/
    private FileOutputStream newFOS(File newFile, boolean append)
        throws IOException
    {
        if (append) {
            try {
                Class[] sig = new Class[]{File.class,boolean.class};
                Constructor ctor = FileOutputStream.class.getConstructor(sig);
                Object[] args = new Object[]{newFile, (append ? Boolean.TRUE : Boolean.FALSE)};
                return (FileOutputStream)ctor.newInstance(args);
            } catch(Exception anyX) {/*burp*/}
        }
        return new FileOutputStream(newFile);
    }


    private File m_copyFromFile, m_copyFromRezFile;
    private String m_copyFromResource;
    private FilterSetCollection m_copyFilters;
    private List m_prototypeLines;
    private String m_updateUrlProperty;
    private ClasspathUtils.Delegate m_CLspi;//NB:lazy-inited
}

/* end-of-MkNewObject.java */
