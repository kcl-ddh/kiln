/**
 * $Id:$
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Enumeration that represents the various content types your application
 * can use with. Lists the basics, various components will expand this
 * list as needed. The various file types are:<ul>
 *    <li><span class="src">text</span>: The file is a plain text file.
 *        Exactly what format (if any) the text encodes is component-defined.</li>
 *    <li><span class="src">properties</span>: The file is standard Java
 *        properties file.</li>
 *    <li><span class="src">xml</span>: The file is an XML formatted file.
 *        Exactly what schema the XML reflects is component-defined.</li>
 * </ul>
 *
 * @since    JWare/AntXtras 2.0.0
 * @author   ssmc, &copy;2005,2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   api,helper
 **/

public class FormatHint extends EnumSkeleton
{
    /** Index of {@linkplain #TEXT TEXT}. **/
    public static final int TEXT_INDEX = 0;
    /** Index of {@linkplain #PROPERTIES PROPERTIES}. **/
    public static final int PROPERTIES_INDEX = TEXT_INDEX+1;
    /** Index of {@linkplain #XML XML}. **/
    public static final int XML_INDEX = PROPERTIES_INDEX+1;



    /** Singleton "<span class="src">text</span>" choice. **/
    public static final FormatHint TEXT=
        new FormatHint("text",TEXT_INDEX);

    /** Singleton "<span class="src">properties</span>" choice. **/
    public static final FormatHint PROPERTIES=
        new FormatHint("properties",PROPERTIES_INDEX);

    /** Singleton "<span class="src">xml</span>" choice. **/
    public static final FormatHint XML=
        new FormatHint("xml",XML_INDEX);



    /**
     * Required bean void constructor for Ant's introspector.
     **/
    public FormatHint()
    {
        super();
    }


    /**
     * Use to create public singletons. Ensures this enum is
     * initialized as if with the default Ant Introspector
     * helper thingy.
     **/
    public FormatHint(String v, int i)
    {
        super(v);
    }


    /**
     * Returns copy of all possible source values as an ordered
     * string array. Note: ordering should be same as our
     * singleton indices.
     **/
    public String[] getValues()
    {
        return new String[] {"text", "properties", "xml"};
    };



    /**
     * Helper that converts a scalar to a known FormatHint.
     * Returns <i>null</i> if value does not match any of
     * expected source.
     * @param i the index to be matched
     **/
    public static FormatHint from(int i)
    {
        if (i==PROPERTIES.index)  { return PROPERTIES; }
        if (i==TEXT.index)        { return TEXT; }
        if (i==XML.index)         { return XML; }
        return null;
    }


    /**
     * Same as {@linkplain #from(int) from(int)} but with a
     * default value if value does not match any known
     * FormatHint's index.
     * @param i the index to be matched
     * @param dflt the default FormatHint if necessary
     **/
    public static FormatHint from(int i, FormatHint dflt)
    {
        FormatHint choice= from(i);
        return (choice==null) ? dflt : choice;
    }


    /**
     * Helper that converts a string to a known FormatHint
     * singleton. Returns <i>null</i> if string unrecognized.
     * String can be either FormatHint's symbolic name or its index.
     **/
    public static FormatHint from(String s)
    {
        if (s!=null && s.length()>0) {
            s = Tk.lowercaseFrom(s);
            if (Character.isDigit(s.charAt(0))) {
                try { return from(Integer.parseInt(s)); }
                catch(Exception nfx) {/*burp*/}
            } else {
                if (PROPERTIES.value.equals(s)) { return PROPERTIES; }
                if (TEXT.value.equals(s))       { return TEXT; }
                if (XML.value.equals(s))        { return XML; }
                if (Strings.DEFAULT.equals(s))  { return TEXT; }/*safest*/
            }
        }
        return null;
    }


    /**
     * Same as {@linkplain #from(String) from(String)} but with a
     * default value if supplied value does not match any known
     * FormatHint's name.
     * @param s the symbolic name to be matched
     * @param dflt the default FormatHint if necessary
     **/
    public static FormatHint from(String s, FormatHint dflt)
    {
        FormatHint choice= from(s);
        return (choice==null) ? dflt : choice;
    }
}

/* end-of-FormatHint.java */
