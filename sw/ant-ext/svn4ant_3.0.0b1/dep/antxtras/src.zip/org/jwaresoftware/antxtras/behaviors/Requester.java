/**
 * $Id: Requester.java 779 2009-05-25 00:32:30Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  org.apache.tools.ant.Location;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.ProjectComponent;
import  org.apache.tools.ant.Target;
import  org.apache.tools.ant.Task;

/**
 * Minimal interaction interface between a generic service and a user of that service.
 * In this context a "service" is any object that can handle requests from objects
 * other than itself. This interface allows generic utilities to easily link feedback
 * and diagnostics trails back to specific user components.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    impl,helper
 **/

public interface Requester extends ProblemHandler, LogEnabled
{
    /**
     * Returns a publishable name for the caller. Often used in
     * feedback and/or error messages.
     * @return name (non-null)
     */
    String getName();



    /**
     * Returns a usable location for the caller. Used solely in
     * signal generation to link the service caller to problems.
     * @return location or UNKNOWN_LOCATION
     **/
    Location getLocation();



    /**
     * Returns the project associated with the caller. Can return
     * <i>null</i> if caller is independent of any particular
     * project (like with utilities).
     * @return associated project or <i>null</i>
     **/
    Project getProject();



    /**
     * Returns the (original) script target of the caller. Can
     * return <i>null</i> if this information unknown.
     * @return original target or <i>null</i>
     **/
    Target getSourceTarget();



    /**
     * An anonymous <em>totally silent</em> service requester proxy.
     * Unlike an {@linkplain Anonymous} adapter, this requester will
     * <em>not</em> send messages or indicate problems to the system
     * consoles.
     **/
    public static final Requester DEVNULL= new Requester()
    {
        /**
         * Always returns <span class="src">undefined</span>.
         **/
        public String getName() {
            return "undefined";
        }
        /**
         * Always returns <span class="src">UNKNOWN_LOCATION</span>.
         **/
        public Location getLocation() {
            return Location.UNKNOWN_LOCATION;
        }
        /**
         * Always returns <i>null</i>.
         **/
        public Project getProject() {
            return null;
        }
        /**
         * Always returns <i>null</i> for no source target.
         **/
        public Target getSourceTarget() {
            return null;
        }
        /**
         * Does nothing.
         **/
        public void log(String message) {
        }
        /**
         * Does nothing.
         **/
        public void log(String message, int msgLevel) {
        }
        /**
         * Does nothing.
         **/
        public void problem(Object nugget, int nl) {
        }
    };




    /**
     * An anonymous service requester proxy. Unlike the standard
     * {@linkplain #DEVNULL null proxy} adapter, anonymous requesters
     * can specify both a location and an associated project. This is
     * often the available state from standalone utility methods.
     * @since    JWare/AntX 0.5
     * @author   ssmc, &copy;2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.group   impl,helper
     **/
    public static class Anonymous extends LogEnabled.ForProject
        implements Requester
    {
        private final Location m_loc;

        /**
         * Initializes a new anonymous requester.
         **/
        public Anonymous() {
            super(null);
            m_loc = Location.UNKNOWN_LOCATION;
        }
        /**
         * Initializes a new location-bound anonymous requester.
         * @param loc caller's location (non-null)
         **/
        public Anonymous(Location loc) {
            super(null);
            m_loc = loc==null ? Location.UNKNOWN_LOCATION : loc;
        }
        /**
         * Initializes a new location-bound anonymous requester.
         * @param project caller's associated project (non-null)
         * @param loc caller's location (non-null)
         **/
        public Anonymous(Project project, Location loc) {
            super(project);
            m_loc = loc==null ? Location.UNKNOWN_LOCATION : loc;
        }
        /**
         * Always returns <span class="src">undefined</span>.
         **/
        public String getName() {
            return "undefined";
        }
        /**
         * Always returns either <span class="src">UNKNOWN_LOCATION</span>
         * or a proxy location bound at creation time.
         **/
        public Location getLocation() {
            return m_loc;
        }
        /**
         * Always returns <i>null</i> for no owning target.
         **/
        public Target getSourceTarget() {
            return null;
        }
        /**
         * Records problem using our own log API.
         **/
        public void problem(Object nugget, int nl) {
            log(Tk.stringFrom(nugget,null),nl);
        }
    }



    /**
     * An anonymous service requester that logs to system consoles.
     * @see Anonymous
     **/
    public static final Requester ANONYMOUS= new Anonymous();



    /**
     * Default {@linkplain Requester} adapter for a standard Ant component.
     * @since    JWare/AntX 0.5
     * @author   ssmc, &copy;2004-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.group   impl,helper
     **/
    public static class ForComponent extends LogEnabled.ForComponent
        implements Requester
    {
        /**
         * Initializes a new requester adapter for given component.
         * @param pc the component being wrapped (non-null)
         **/
        public ForComponent(ProjectComponent pc) {
            super(pc);
        }
        /**
         * Returns component's script-supplied name or if this is not
         * defined the component's class leaf name.
         **/
        public String getName() {
            if (m_PC instanceof Task) {
                return ((Task)m_PC).getTaskName();
            }
            String n;
            if (m_PC instanceof Named) {
                n = ((Named)m_PC).getName();
                if (n!=null) {
                    return n;
                }
            }
            if (m_PC instanceof Identified) {
                n = ((Identified)m_PC).getId();
                if (n!=null) {
                    return n;
                }
            }
            return Tk.leafNameFrom(m_PC.getClass());

        }
        /**
         * Returns component's assigned parse location or the
         * <span class="src">UNKNOWN_LOCATION</span> marker if no location
         * known.
         * @see ScriptLocatable
         **/
        public Location getLocation() {
            if (m_PC instanceof Task) {
                return ((Task)m_PC).getLocation();
            }
            if (m_PC instanceof ScriptLocatable) {
                return ((ScriptLocatable)m_PC).getLocation();
            }
            return Location.UNKNOWN_LOCATION;
        }
        /**
         * Returns compoent's owning target or <i>null</i> if
         * no such target.
         **/
        public Target getSourceTarget() {
            if (m_PC instanceof Task) {
                return ((Task)m_PC).getOwningTarget();
            }
            return null;
        }
        /**
         * Always returns task's associated project.
         **/
        public Project getProject() {
            return m_PC.getProject();
        }
        /**
         * Records problem using our own log API.
         **/
        public void problem(Object nugget, int nl) {
            log(Tk.stringFrom(nugget,null),nl);
        }
    }




    /**
     * Default {@linkplain Requester} adapter for a utility object.
     * @since    JWare/AntX 0.5
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.group   impl,helper
     **/
    public static final class ForUtility extends LogEnabled.ForUtility
        implements Requester
    {
        /**
         * Initializes a new adapter for given utility.
         * @param utility the utility being wrapped (non-null)
         */
        public ForUtility(ProjectDependent utility) {
            super(utility);
        }
        /**
         * Always returns leafname of utility's class unless
         * it's an {@linkplain Identified} item.
         **/
        public String getName() {
            if (getImpl() instanceof Identified) {
                String id = ((Identified)getImpl()).getId();
                if (id!=null) {
                    return id;
                }
            }
            return Tk.leafNameFrom(getImpl().getClass());
        }
        /**
         * Always returns <span class="src">UNKNOWN_LOCATION</span>
         * unless the utility implements {@linkplain ScriptLocatable}.
         **/
        public Location getLocation() {
            if (getImpl() instanceof ScriptLocatable) {
                return ((ScriptLocatable)getImpl()).getLocation();
            }
            return Location.UNKNOWN_LOCATION;
        }
        /**
         * Always returns utility's associated project.
         **/
        public Project getProject() {
            return getImpl().getProject();
        }
        /**
         * Always returns <i>null</i> for no owning target.
         **/
        public Target getSourceTarget() {
            return null;
        }
        /**
         * Records problem using our own log API.
         **/
        public void problem(Object nugget, int nl) {
            log(Tk.stringFrom(nugget,null),nl);
        }
    }



    /**
     * Default {@linkplain Requester} adapter for a generic Ant project.
     * @since    JWare/AntX 0.5
     * @author   ssmc, &copy;2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.group   impl,helper
     **/
    public static class ForProject extends LogEnabled.ForProject
        implements Requester
    {
        /**
         * Initializes a new adapter for an Ant project.
         * @param project the project being wrapped (non-null)
         */
        public ForProject(Project project) {
            super(project);
        }
        /**
         * Always returns the project's name or the marker
         * string "project".
         **/
        public String getName() {
            Project P = getProject();
            if (P!=null) {
                return P.getName();
            }
            return "project";
        }
        /**
         * Always returns <span class="src">UNKNOWN_LOCATION</span>.
         **/
        public Location getLocation() {
            Project P = getProject();
            if (P!=null) {
                Task t = P.getThreadTask(Thread.currentThread());
                if (t!=null) {
                    return t.getLocation();
                }
            }
            return Location.UNKNOWN_LOCATION;
        }
        /**
         * Always returns <i>null</i> for no owning target.
         **/
        public Target getSourceTarget() {
            return null;
        }
        /**
         * Records problem using our own log API.
         **/
        public void problem(Object nugget, int nl) {
            log(Tk.stringFrom(nugget,null),nl);
        }
    }



    /**
     * Default {@linkplain Requester} adapter for a generic Ant target.
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.group   impl,helper
     **/
    public static final class ForTarget extends LogEnabled.ForProject
        implements Requester
    {
        final Target m_target;

        /**
         * Initializes a new adapter for an Ant target.
         * @param target the target being wrapped (non-null)
         */
        public ForTarget(Target target) {
            super(target.getProject());
            m_target = target;
        }
        /**
         * Always returns the target's name or the marker
         * string "target" if that is <i>null</i>.
         **/
        public String getName() {
            String s = m_target.getName();
            return s==null ? "target" : s;
        }
        /**
         * Returns the target's location or if that is null
         * <span class="src">UNKNOWN_LOCATION</span>.
         **/
        public Location getLocation() {
            Location l = m_target.getLocation();
            return (l!=null) ? l : Location.UNKNOWN_LOCATION;
        }
        /**
         * Always returns associated target.
         **/
        public final Target getSourceTarget() {
            return m_target;
        }
        /**  
         * Returns the source target. Never <i>null</i>.
         **/
        public Object getImpl() {
            return getSourceTarget();
        }
        /**
         * Records problem using our own log API.
         **/
        public void problem(Object nugget, int nl) {
            log(Tk.stringFrom(nugget,null),nl);
        }
    }
}

/* end-of-Requester.java */