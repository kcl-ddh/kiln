/**
 * $Id: FlexValueSupport.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for a component that supports setter/getters for the
 * four kinds of values: properties, variables, literals, and references.
 * The getters are not explicitly defined by this interface to support
 * implementations that wish to provide better named getters. This
 * interface is the build-script facing setter interface.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface FlexValueSupport
{
    /**
     * Read from or write to named property.
     * @param property property's name (non-null)
     **/
    void setProperty(String property);


    /**
     * Read from or write to named variable property.
     * @param variable property's name (non-null)
     **/
    void setVariable(String variable);


    /**
     * Read from or write to named reference. Typically the
     * source expects or stores a "stringified" form of whatever
     * content is being manipulated.
     * @param reference reference's name (non-null)
     **/
    void setReference(String reference);
}

/* end-of-FlexValueSupport.java */
