/**
 * $Id: BuildInfo.java,in 959 2010-01-09 12:49:09Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras;

import  java.io.Serializable;

import  org.jwaresoftware.internal.apis.Buildstrs;

/**
 * Build information that describes this release of the JWare/AntXtras product.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2003,2007-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,infra
 **/

public final class BuildInfo implements Buildstrs, Serializable, Cloneable
{
    /**
     * Initializes a new BuildInfo instance based on build-time values.
     **/
    public BuildInfo()
    {
    }


    /**
     * Returns diagnostics id for build; always "<code>AntXtras</code>".
     **/
    public final String getID()
    {
        return "AntXtras";
    }


    /**
     * Returns displayable label for build, for example
     * "<code>JWare/AntXtras 2.0.0b2, Feb-27-2009</code>".
     **/
    public final String getDisplayName()
    {
        return "JWare AntXtras/Foundation 3.0.0b1, Apr-18-2010";
    }


    /**
     * Returns product version for this build, for example
     * "<code>2&#46;0&#46;0b3</code>."
     **/
    public final String getVersion()
    {
        return "3.0.0b1";
    }


    /**
     * Returns this build's (unique) identifer, for example
     * "<code>2&#46;0&#46;0b3-build567.23</code>."
     **/
    public final String getBuildVersion()
    {
        return "3.0.0b1-build1083.45";
    }


    /**
     * Returns the product shorthand namespace prefix, for example
     * "<code>oja</code>".
     **/
    public final String getNSPrefix()
    {
        return "oja";
    }


    /**
     * Returns the product namespace URI, for example
     * "<code>jware&#46;antxtras</code>".
     **/
    public final String getNSURI()
    {
        return "jwaresoftware.antxtras";
    }


    /**
     * Returns the product properties namespace prefix, for example
     * "<code>jware</code>" as used in
     * "<code>jware&#46;antxtras&#46;defaults&#46;noiselevel</code>."
     **/
    public final String getPropertiesPrefix()
    {
        return "jware.antxtras.";
    }


    /**
     * Returns date of build in an abbreviated format, for example
     * "<code>Jan012001,12:34GMT</code>".
     **/
    public final String getAbbrDate()
    {
        return "Apr-18-2010";
    }


    /**
     * Returns date of build in a verbose format, for example
     * "<code>Monday 1 January 2001, 12:34:34 GMT</code>".
     **/
    public final String getLongDate()
    {
        return "Apr182010_163836GMT";
    }


    /**
     * Returns OS on which build generated, for example
     * "<code>CentOS Linux 5&#46;1 (patch03)</code>".
     **/
    public final String getOS()
    {
        return "Windows XP 5.1";
    }


    /**
     * Returns build builder's (system) identifier, for example
     * "<code>donutman</code>".
     **/
    public final String getBuilderID()
    {
        return "ssmc";
    }


    /**
     * Returns build builder's common name, for example
     * "<code>Robert Jenson</code>".
     **/
    public final String getBuilderCN()
    {
        return "ssmc";
    }


    /**
     * Returns host information for machine used for build, for example
     * "<code>buildbox1</code>".
     **/
    public final String getHostID()
    {
        return "milo.madhouse.pa";
    }


    /**
     * Returns various paths used to generate build (class,libs,etc.);
     * optional.
     **/
    public final String getUsedPaths()
    {
        return "Undeclared";
    }


    /**
     * Returns {@linkplain #getDisplayName()}.
     */
    public String toString()
    {
        return this.getDisplayName();
    }


    /**
     * Determines if this buildstrs is equal to given object&#150; which has
     * to be another BuildInfo instance.
     **/
    public boolean equals(Object o)
    {
        if (o==null) {
            return false;
        }
        if (o==this || o.getClass()==org.jwaresoftware.antxtras.BuildInfo.class) {
            return true;
        }
        return false;
    }


    /**
     * Returns a hash value for this object. Since all instances of this
     * class are considered equal, the hash value depends on the class's id.
     **/
    public int hashCode()
    {
        return HASH_;
    }


    /**
     * Returns clone of this object.
     **/
    public Object clone()
    {
        try {
            return super.clone();
        } catch(CloneNotSupportedException clnx) {
            throw new InternalError("Clone broken");
        }
    }


    /**
     * Returns a VM-shareable singleton reference.
     * @.safety guarded
     **/
    public static synchronized Buildstrs getInstance()
    {
        if (sm_Instance==null) {
            sm_Instance= new BuildInfo();
        }
        return sm_Instance;
    }


    private static final int HASH_= BuildInfo.class.getName().hashCode();
    private static Buildstrs sm_Instance=null;
}

/* end-of-BuildInfo.java */
