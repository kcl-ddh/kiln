/**
 * $Id: LevelToLabel.java 775 2009-05-03 18:14:13Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  org.apache.tools.ant.Project;

/**
 * Helper to convert an standard Ant noise level to a label
 * suitable for both Ant console and other internal diagnostic
 * output streams.
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    impl,helper
 **/

public final class LevelToLabel
{
    /**
     * Convert the incoming Project.MSG_* level into a usable
     * label string for diagnostics streams.
     * @param msgLevel project noise level
     * @return label (non-null)
     **/
    public static final String get(int msgLevel) {
        switch(msgLevel) {
            case Project.MSG_INFO: { return "[ INFO] "; }
            case Project.MSG_ERR:  { return "[ERROR] "; }
            case Project.MSG_WARN: { return "[ WARN] "; }
            default: { return "[DEBUG] "; }
        }
    }


    private LevelToLabel() {
        super();
    }
}

/* end-of-LevelToLabel.java */
