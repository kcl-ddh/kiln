/**
 * $Id: CallTask.java 1007 2010-03-11 13:23:42Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.call;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.types.PropertySet;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.fixture.CopyPropertyTask;
import  org.jwaresoftware.antxtras.fixture.CopyReferenceTask;
import  org.jwaresoftware.antxtras.helpers.InnerNameValuePair;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.ExecutionMode;
import  org.jwaresoftware.antxtras.parameters.FixturePassthru;

/**
 * Task that calls one or more targets or macrodefs in a new independent
 * project clone of the current project. The CallTask allows only
 * &lt;propertyset&gt;, &lt;[copy]property&gt;, and &lt;[copy]reference&gt;
 * declarations to be nested within it as fixture instructions for the cloned
 * project. Note that unlike &lt;callinline&gt;, this task can also call
 * macrodefs.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;<b>call</b> targets="clobber,checkout,merge" failproperty="prepare.failed"&gt;
 *     &lt;property name="scrub.disable" value="false"/&gt;
 *     &lt;property name="start.time" variable="local.start.time"/&gt;
 *   &lt/call&gt;
 *
 *   &lt;<b>call</b> macros="scrub,checkout,merge"&gt;
 *      &lt;attribute name="project" value="${subproject}"/&gt;
 *      &lt;property name="scrub.disable" value="false"/&gt;
 *   &lt;/call&gt;
 *
 *   &lt;<b>call</b> targets="config,application,scripts" mode="local"&gt;
 *     &lt;property name="outputs.d" value="${main.d}/cli"/&gt;
 *   &lt;/call&gt;
 *
 *    &lt;<b>call</b> targets="ping-machine1,ping-machine2"
 *           haltiferror="no" tryeach="yes" failproperty="ping.incomplete"/&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.4
 * @author    ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    api,infra
 * @see       CallInlineTask
 * @see       CallForEachTask
 **/

public final class CallTask extends OnceTaskSkeleton
{
    /**
     * Initializes a new CallTask instance.
     **/
    public CallTask()
    {
        super(AntX.flowcontrol+"CallTask:");
    }



    /**
     * Initializes a new helper CallTask instance.
     * @param iam CV-label (non-null)
     **/
    public CallTask(String iam)
    {
        super(iam);
    }


//  ---------------------------------------------------------------------------------------
//  Unique Script-facing Parameters:
//  ---------------------------------------------------------------------------------------

    /**
     * Adds a new fixture overlay property to this task.
     * This property is automatically passed to each target's
     * environment as it is executed.
     * @param param initialized property (non-null)
     * @since JWare/AntX 0.4
     **/
    public void addProperty(CopyPropertyTask param)
    {
        require_(param!=null,"addProperty- nonzro item");
        getParametersKeeper().addParameter(param);
    }



    /**
     * Adds a new fixture overlay property set to this task. The
     * properties named by the property set are automatically
     * copied to  each target's environment before it is executed.
     * @param param property set information (non-null)
     * @since JWare/AntX 0.4
     **/
    public void addPropertySet(PropertySet param)
    {
        require_(param!=null,"addPropertySet- nonzro item");
        getParametersKeeper().addParameter(param);
    }


    /**
     * Adds a new configuration reference to this task. This
     * reference is automatically copied to each target's
     * environment as each is executed.
     * @param param reference information (non-null)
     * @since JWare/AntX 0.4
     **/
    public void addReference(CopyReferenceTask param)
    {
        require_(param!=null,"addReference- nonzro item");
        getParametersKeeper().addParameter(param);
    }



    /**
     * Adds a new macro attribute default value to this task.
     * This attribute is automatically passed to <em>each</em>
     * macro when it is executed.
     * @param attr initialized macro attribute (non-null)
     * @since JWare/AntX 0.5
     * @throws BuildException if this caller is not setup for macros.
     **/
    public void addConfiguredAttribute(InnerNameValuePair attr)
    {
        require_(attr!=null,"addAttribute- nonzro item");
        if (getMacroNamesList()==null) {
            String err = getAntXMsg("flow.attritem.formacros");
            log(err,Project.MSG_ERR);
            throw new BuildException(err,getLocation());
        }
        getParametersKeeper().addParameter(attr);
    }



    /**
     * Instructs this task what kinds of fixture informaton
     * should be passed to the child project. By default only
     * properties are passed on.
     * @since JWare/AntX 0.4
     **/
    public void setPassthru(FixturePassthru passthru)
    {
        require_(passthru!=null,"setPassthru- nonzro option");
        m_passthru = FixturePassthru.from(passthru.getIndex());//NB:normalize
    }



    /**
     * Returns the fixture passthru setting to be used when this
     * caller runs its targets. Never returns <i>null</i>;
     * will return <span class="src">PROPERTIES</span> if
     * not set explicitly.
     * @since JWare/AntX 0.4
     **/
    public final FixturePassthru getPassthruOption()
    {
        return m_passthru;
    }



    /**
     * Sets this task's list of targets. These targets will
     * be called in order from a partitioned child project
     * when this task is executed.
     * @param setOfTargetNames the comma-delimited list of names
     * @since JWare/AntX 0.4
     **/
    public void setTargets(String setOfTargetNames)
    {
        require_(!Tk.isWhitespace(setOfTargetNames),
                 "setTargets- nonwhitespace list");
        m_targetNames = setOfTargetNames;
    }


    /**
     * Clearer synonymn for {@linkplain #setTargets(String) setTargets}
     * when only a single target is specified.
     * @param targetName the target name (non-blank)
     * @since JWare/AntXtras 2.0.0
     **/
    public final void setTarget(String targetName)
    {
        setTargets(targetName);
    }


    /**
     * Returns this task's comma-delimited list of target names.
     * Will return <i>null</i> if never set.
     * @since JWare/AntX 0.4
     **/
    public String getTargetNamesList()
    {
        return m_targetNames;
    }



    /**
     * Sets this task's list of macros. These macros will be
     * called in order from the current project's partition when
     * this task is executed.
     * @param setOfMacroNames the comma-delimited list of macros
     * @since JWare/AntX 0.5
     * @.sideeffect Will default mode to "local" if not set.
     **/
    public void setMacros(String setOfMacroNames)
    {
        require_(!Tk.isWhitespace(setOfMacroNames),
                 "setMacros- nonwhitespace list");
        m_macroNames = setOfMacroNames;
        if (!m_modeInited) {
            setMode(ExecutionMode.LOCAL.getValue());
        }
    }


    /**
     * Clearer synonymn for {@linkplain #setMacros(String) setMacros}
     * when only a single macrodef is specified.
     * @param macroName the macrodef name (non-blank)
     * @since JWare/AntXtras 2.0.0
     **/
    public final void setMacro(String macroName)
    {
        setMacros(macroName);
    }


    /**
     * Returns this task's comma-delimited list of macro names.
     * Will return <i>null</i> if never set. By default, all
     * macros must exist within the same project as this task.
     * @since JWare/AntX 0.5
     **/
    public String getMacroNamesList()
    {
        return m_macroNames;
    }



    /**
     * Tells this tasks to execute items locally (within current
     * project) or isolated (within independent clone project).
     * @param Xmodestring either "local" or "isolated"
     * @since JWare/AntX 0.4
     **/
    public void setMode(String Xmodestring)
    {
        require_(Xmodestring!=null,"setMode- nonzro string");
        m_Xmode = ExecutionMode.from(Xmodestring,m_Xmode);
        m_modeInited = true;//latch
    }



    /**
     * Returns this task's execution mode. Never returns <i>null</i>;
     * will return <span class="src">ISOLATED</span> if never set.
     * @since JWare/AntX 0.4
     **/
    public ExecutionMode getMode()
    {
        return m_Xmode;
    }



    //Required sequence of steps (can be specified by subclass "later")
    //Default way of specifying a set of steps is using a comma-delimited list
    //in "macros" or "targets" attribute.
    private String m_targetNames;
    private String m_macroNames;
    private FixturePassthru m_passthru = FixturePassthru.PROPERTIES;/* NB: Ant dflt */
    private ExecutionMode m_Xmode= ExecutionMode.ISOLATED;
    private boolean m_modeInited;
}

/* end-of-CallTask.java */
