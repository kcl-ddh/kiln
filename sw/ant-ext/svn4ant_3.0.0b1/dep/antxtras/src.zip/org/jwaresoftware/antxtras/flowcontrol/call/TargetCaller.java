/**
 * $Id: TargetCaller.java 431 2008-05-03 18:20:14Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.call;

import  java.util.Map;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.taskdefs.Ant;
import  org.apache.tools.ant.taskdefs.Property;
import  org.apache.tools.ant.types.PropertySet;

/**
 * Helper that calls a another target whether that target is inlined
 * or top-level.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   impl,infra
 * @see      OverlayParametersHelper
 **/

public interface TargetCaller
{
    /**
     * Returns this caller's target's name.
     **/
    String getTargetName();


    /**
     * Create a new property to passthru to called target.
     **/
    Property createProperty();


    /**
     * Create a new propertyset to passthru to called target.
     * @since JWare/AntX 0.4
     **/
    PropertySet createPropertySet();


    /**
     * Create a new reference to passthru to called target.
     * @since JWare/AntX 0.3
     **/
    Ant.Reference createReference();


    /**
     * Executes the target this caller references.
     * @throws BuildException if target does.
     **/
    void run() throws BuildException;


    /**
     * Convenient {@linkplain #run() run} alternative that auto-installs
     * a required property into the to-be-called target's runtime
     * environment before it's executed. Useful for looping constructs
     * that call targets as part of their execution w/ a changing
     * cursor property.
     * @param property property name (non-null)
     * @param value property value-- used as-is no additional
     *              replacements are done (non-null)
     * @throws BuildException if target does.
     **/
    void run(String property, String value)
        throws BuildException;


    /**
     * Convenient {@linkplain #run() run} alternative that auto-installs
     * contents of properties map into the to-be-called target's runtime
     * environment before it's executed.
     * @param properties properties to be installed (non-null)
     * @throws BuildException if target does.
     * @since JWare/AntX 0.4
     **/
    void run(Map properties)
        throws BuildException;


    /**
     * Convenient {@linkplain #run() run} alternative that auto-installs
     * arbitrary numbers of fixture data into the to-be-called target's
     * runtime environment before it's executed.
     * @param prep client preparation snippet (non-null)
     * @throws BuildException if target does.
     **/
    void run(TargetCaller.Prep prep)
        throws BuildException;



    /**
     * Helper that lets caller task select which TargetCaller run method to use.
     * @since    JWare/AntX 0.1
     * @author   ssmc, &copy;2002-2003 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.pattern GoF.Strategy
     **/
    interface RunSelector {
        /**
         * Run the caller using the appropriate run-method variant.
         * @param caller the caller to be run (non-null)
         * @throws BuildException if target does.
         **/
        void run(TargetCaller caller) throws BuildException;
    }



    /**
     * Helper that lets caller task prepare a custom runtime environment for
     * a to-be-called target.
     * @since    JWare/AntX 0.1
     * @author   ssmc, &copy;2002-2003 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.pattern GoF.Strategy
     **/
    interface Prep {
        /**
         * Called to prepare the passthru environment appropriately before
         * the to-be-executed target.
         * @param caller the caller that will run the target (non-null)
         * @throws BuildException if unable to prepare target.
         **/
        void prepare(TargetCaller caller) throws BuildException;
    }
}

/* end-of-TargetCaller.java */

