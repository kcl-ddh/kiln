/**
 * $Id: InterpretParameters.java 1007 2010-03-11 13:23:42Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.interpret;

import  java.util.Properties;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.parameters.IsA;

/**
 * Standard script-supplied instructions for a log interpretation request. An interpreter
 * does not have to use all the options.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    impl,helper
 * @see       InterpretLoggedTask
 **/

public interface InterpretParameters extends Requester
{
    /**
     * Returns <i>true</i> if the interpreter should update this
     * requester's project directly. Usually returns <i>true</i>.
     **/
    boolean updateProperties();


    /**
     * Returns the maximum number of errors this interpreter will
     * tolerate before recording a failure. This value is zero (0)
     * unless defined otherwise.
     **/
    int getMaxErrors();


    /**
     * Returns the maximum number of warnings this interpreter will
     * tolerate before recording a failure. This value is ten (10)
     * unless defined otherwise.
     **/
    int getMaxWarnings();


    /**
     * Returns the name of the property this interpreter will update
     * with its conclusion. Never returns <i>null</i> or the empty
     * string.
     **/
    String getUpdateProperty();


    /**
     * Returns the name of the property this interpreter will update
     * with the number of errors. Never returns <i>null</i> or the
     * empty string.
     **/
    String getErrorCountProperty();


    /**
     * Returns the name of the property this interpreter will update
     * with the number of warnings. Never returns <i>null</i> or the
     * empty string.
     **/
    String getWarningCountProperty();



    /**
     * Returns the preferred type of the result set data objects.
     * Defaults to standard properties unless caller sets explicitly.
     * Never returns <i>null</i>.
     **/
    IsA getResultType();



    /**
     * Returns the readonly set of custom properties supplied by
     * client script. Never returns <i>null</i> but can return an
     * empty map.
     **/
    Properties getInstructions();
}

/* end-of-InterpretParameters.java */