/**
 * $Id: CreateTaskTask.java 428 2008-04-27 13:12:32Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.construct;

import  java.util.Map;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.Task;
import  org.apache.tools.ant.TaskContainer;
import  org.apache.tools.ant.UnknownElement;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.ownhelpers.UEContainerProxy;
import  org.jwaresoftware.antxtras.parameters.FeedbackLevel;

/**
 * Creates and caches a new partially defined task instance. The instance can be
 * further customized using {@linkplain AlterTaskTask} inside the various flow
 * control AntX tasks. Use the {@linkplain PerformTaskTask} to execute the
 * final task.
 * <p/>
 * <b>Example Usage:</b><pre>
 *    &lt;assign var="_junitinstance" value="${$random:string}"/&gt;
 *    &lt;<b>createtask</b> name="${$var:_junitinstance}"&gt;
 *       &lt;junit printsummary="yes" haltonfailure="yes"&gt;
 *          &#8230;
 *       &lt;/junit&gt;
 *    &lt;/createtask&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    api,helper
 * @see       AlterTaskTask
 **/

public final class CreateTaskTask extends ItemConstructorTask
    implements TaskContainer
{
    /**
     * Initializes a new createtask task instance.
     **/
    public CreateTaskTask()
    {
        super(AntX.construct+"CreateTaskTask:");
    }


//  ---------------------------------------------------------------------------------------
//  Script-facing Nested Elements:
//  ---------------------------------------------------------------------------------------


    /**
     * Stashes the named UE proxy for subsequent installation.
     * @param task the unknown element task proxy (non-null)
     **/
    public void addTask(Task task)
    {
        require_(task instanceof UnknownElement, "addTask- is UE proxy");
        UnknownElement ue = (UnknownElement)task;
        if (m_itemUE!=null) {
            String ermsg = uistrs().get("taskset.only.one.specialtask",
                                        ue.getQName(), m_itemQName);
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
        m_itemQName = ue.getQName();
        m_itemUE = new UEContainerProxy(ue);
    }


//  ---------------------------------------------------------------------------------------
//  Execution:
//  ---------------------------------------------------------------------------------------


    /**
     * Installs the nested item declaration as a top-level reference
     * in this task's parent project.
     * @throws BuildException if verification fails.
     */
    public void execute()
    {
        verifyCanExecute_("exec");

        String refid = getName();
        final Project P = getProject();
        boolean quiet = FeedbackLevel.isQuietish(getFeedbackLevel(),true,true);

        Object there = FixtureExaminer.trueReference(P,refid);
        if (there==FixtureExaminer.PENDING_REFERENCE) {
            quiet = true;
            there = null;
        }

        Map refs = P.getReferences();
        if (there!=null) {
            String msg = uistrs().get("task.warn.refid.exists",refid);
            if (isHaltIfExists()) {
                log(msg,Project.MSG_ERR);
                throw new BuildException(msg,getLocation());
            }
            if (!willAllowOverwrite()) {
                if (!quiet) {
                    log(msg,Project.MSG_VERBOSE);
                }
                m_itemUE = null;
                return;
            }
            if (!quiet) {
                log(msg,Project.MSG_WARN);
            }
        }

        Object actual = beforeInstall(m_itemUE);
        verify_(actual!=null,"exec- nonzro item");

        if (quiet) {
            refs.put(refid,actual);
        } else {
            P.addReference(refid,actual);
        }

        m_itemUE = null;
    }



    /**
     * Verifies that this task has at least its source reference
     * identifier set.
     * @throws BuildException if missing any required bits.
     **/
    public void verifyIsDefined()
    {
        super.verifyIsDefined();
        if (m_itemUE==null) {
            String ermsg = uistrs().get("task.needs.oneof.these.nested",
                getTaskName(),"<any ant component>");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
    }



    /**
     * Called just before the new item's proxy is inserted into the
     * project's reference table. Subclasses can perform the item (if
     * it is a task) or do further adjustments. The returned object
     * can be proxy or the underlying real object; it cannot be <i>null</i>.
     * @param ue wrapper for the item to be installed (non-null)
     * @return the object to be installed (cannot be <i>null</i>)
     **/
    protected Object beforeInstall(UEContainerProxy ue)
    {
        return ue;
    }


    private UEContainerProxy m_itemUE;
    private String m_itemQName;
}

/* end-of-CreateTaskTask.java */