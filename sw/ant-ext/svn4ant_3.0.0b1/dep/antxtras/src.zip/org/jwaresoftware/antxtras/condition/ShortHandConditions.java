/**
 * $Id: ShortHandConditions.java 1019 2010-03-13 16:13:19Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  java.io.File;

import  org.apache.tools.ant.types.Reference;
import  org.apache.tools.ant.types.Path;

import  org.jwaresoftware.antxtras.parameters.IgnoreCaseEnabled;
import  org.jwaresoftware.antxtras.parameters.IgnoreWhitespaceEnabled;
import  org.jwaresoftware.antxtras.parameters.MalformedCheckEnabled;
import  org.jwaresoftware.antxtras.parameters.TrimEnabled;
import  org.jwaresoftware.antxtras.parameters.FlexValueSupport;
import  org.jwaresoftware.antxtras.parameters.IsA;

/**
 * Collection of most common shorthand condition parameters supported by
 * AntXtras rule tasks. The various "*Enabled" and the FlexValue support
 * modify the primary shorthand condition.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2003-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface ShortHandConditions
    extends FlexValueSupport, IgnoreCaseEnabled, TrimEnabled,
            IgnoreWhitespaceEnabled, MalformedCheckEnabled
{
    /**
     * Parameter shorthand for a single &lt;istrue&gt; condition.
     **/
    void setIsTrue(String name);

    /**
     * Parameter shorthand for a single &lt;isfalse&gt; condition.
     **/
    void setIsFalse(String name);



    /**
     * Parameter shorthand for a single &lt;isnotwhitespace&gt;
     * condition.
     **/
    void setIsNotWhitespace(String name);

    /**
     * Parameter shorthand for a single &lt;isnumber&gt; condition.
     **/
    void setIsNumber(String name);

    /**
     * Parameter shorthand for a single &lt;isboolean&gt; condition.
     **/
    void setIsBoolean(String name);



    /**
     * Parameter shorthand for a single &lt;isset&gt; condition.
     **/
    void setIsSet(String name);

    /**
     * Parameter shorthand for a single &lt;issettrue&gt; condition.
     **/
    void setIsSetTrue(String name);

    /**
     * Modifier for a shorthand &lt;isboolean&gt; or &lt;issettrue&gt;
     * condition.
     **/
    void setSynonyms(boolean allowAll);

    /**
     * Parameter shorthand for a single &lt;isnotset&gt; condition.
     **/
    void setIsNotSet(String name);

    /**
     * Source modifier for various shorthand &lt;isXXX&gt; conditions.
     **/
    void setIsA(IsA isa);



    /**
     * Parameter shorthand for a single &lt;isset isa="variable"&gt;
     * condition.
     **/
    void setVarSet(String name);

    /**
     * Parameter shorthand for a single &lt;issettrue isa="variable"&gt;
     * condition.
     **/
    void setVarSetTrue(String name);

    /**
     * Parameter shorthand for a single &lt;isnotset isa="variable"&gt;
     * condition.
     **/
    void setVarNotSet(String name);



    /**
     * Parameter shorthand for a single &lt;allset&gt; condition.
     **/
    void setAllSet(String properties);

    /**
     * Parameter shorthand for a single &lt;anyset&gt; condition.
     **/
    void setAnySet(String properties);

    /**
     * Parameter shorthand for a single &lt;noneset&gt; condition.
     **/
    void setNoneSet(String properties);



    /**
     * Parameter shorthand for a single &lt;ismatch&gt; condition.
     **/
    void setIsMatch(String pattern);

    /**
     * Defines literal value used in an ismatch condition.
     **/
    void setValue(String literal);



    /**
     * Parameter shorthand for a single &lt;available file="&#46;&#46;&#46;"&gt;
     * condition.
     **/
    void setIsFile(File file);

    /**
     * Parameter shorthand for a single &lt;available file="&#46;&#46;&#46;" type="dir"&gt;
     * condition.
     **/
    void setIsDirectory(File file);

    /**
     * Defines the path used to search for file or directory in an
     * &lt;available&gt; shorthand condition.
     **/
    void setFilepath(Path filp);

    /**
     * Parameter shorthand for a single &lt;available classname="&#46;&#46;&#46;"&gt;
     * condition.
     **/
    void setIsClass(String classname);

    /**
     * Parameter shorthand for a single &lt;available resource="&#46;&#46;&#46;"&gt;
     * condition.
     **/
    void setIsResource(String name);

    /**
     * Defines the classpath used to search for a class or resource in
     * an &lt;available&gt; shorthand condition.
     **/
    void setClasspath(Path clsp);

    /**
     * Defines the classpath reference used to search for a class or
     * resource in an &lt;available&gt; shorthand condition.
     **/
    void setClasspathRef(Reference cpr);

    /**
     * Defines whether system classes included in classpath used to
     * search for classes or resources in an &lt;available&gt; shorthand
     * condition.
     **/
    void setSystemClasses(boolean included);



    /**
     * Parameter shorthand for a single &lt;os family="&#46;&#46;&#46;"&gt; condition.
     **/
    void setOSFamily(String family);

    /**
     * Parameter shorthand for a single AntX
     * <span class="src">ifOS="&#46;&#46;&#46;"</span> condition.
     * @since JWare/AntX 0.4
     **/
    void setOS(String selector);



    /**
     * Parameter shorthand for a single &lt;httpalive url="&#46;&#46;&#46;"&gt;
     * condition.
     * @since JWare/AntX 0.3
     **/
    void setHttpAlive(String url);
}

/* end-of-ShortHandConditions.java */
