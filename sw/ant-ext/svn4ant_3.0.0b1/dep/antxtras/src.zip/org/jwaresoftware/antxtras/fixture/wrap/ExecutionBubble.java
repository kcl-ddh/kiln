/**
 * $Id: ExecutionBubble.java 435 2008-05-03 21:30:38Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.fixture.wrap;

import  org.jwaresoftware.antxtras.behaviors.ProjectDependent;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.FixtureOverlay;

/**
 * Task execution helper that tries to restore a task's surrounding Ant
 * <span class="src">Project</span> build-iteration context to the state it reflected
 * just before task executed.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   impl,infra
 **/

public interface ExecutionBubble extends ProjectDependent, FixtureOverlay
{
    /**
     * Captures project state for later restoration. Must be
     * matched with a call to {@linkplain #leave leave}.
     * @param block the client to be executed (non-null)
     **/
    boolean enter(Requester block);



    /**
     * Restores project state as best can to state before task
     * executed. Will affect project properties and references mostly.
     * Should be done <em>once</em> for each call to
     * {@linkplain #enter enter}.
     * @param block the client that was executed (non-null)
     **/
    boolean leave(Requester block);
}

/* end-of-ExecutionBubble.java */
