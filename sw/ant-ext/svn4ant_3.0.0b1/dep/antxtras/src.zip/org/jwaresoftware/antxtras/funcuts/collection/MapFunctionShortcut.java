/**
 * $Id: MapFunctionShortcut.java 944 2010-01-05 01:11:59Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.collection;

import  java.util.Properties;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.helpers.GenericParameters;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Function shortcut that stringifies various aspects of a map data object. Is
 * the map equivalent of the <span class="src">$list:</span> function shortcut.
 * When generating a listing (keyset,values) you can specify a custom delimiter by
 * setting a second fragment argument after a "<span class="src">,,</span>" like:
 * <span class="src">$map:labels?keys,,||"</span>. The general form of the URI:
 * <span class="src"><nobr>$map:maprefid[?[keys|values|size|dump|<i>key</i>][,,delim]]</nobr></span>.
 * The delim option is only relevant to the set operations.
 * <p/>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;doforeach i="key" list="${<b>$map:</b>@{sysenv}?keys}"&gt;
 *      &lt;altertask name="junitrunner" resolveproperties="yes"&gt;
 *         &lt;sysproperty key="${key}" value="${<b>$map:</b>@{sysenv}?${key}}"/&gt;
 *      &lt;/altertask&gt;
 *    &lt;/doforeach&gt;
 *
 * <b>2)</b> &lt;doforeach i="tool" list="${<b>$map:</b>tools?values}"&gt;
 *      &lt;mkdir dir="${reports.d}/${tool}/${DSTAMP}"/&gt;
 *    &lt;/doforeach&gt;
 *
 * <b>3)</b> &lt;debugg message="Javadoc Configuration: ${<b>$map:</b>javadoc.args}"/&gt;
 *    &lt;inform message="Metrics Tool Count: ${<b>$map:</b>tools?size}"/&gt;
 *
 * <b>4)</b> -- To Install --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="map"
 *           value="${ojaf}.collection.MapFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class MapFunctionShortcut extends CollectionFunctionShortcutSkeleton
{
    /**
     * Initializes a new map function shortcut.
     **/
    public MapFunctionShortcut()
    {
        super();
    }


    /**
     * Extracts the bit of map information requested. Currently supports
     * four special operations: dump (also default if no fragment), keyset,
     * values, and size.
     */
    String valueFromTyped(String refid, int op, String arg2, String key,
        Requester clnt)
    {
        final Project P = clnt.getProject();

        boolean isInlined=false;
        if (Tk.isWhitespace(refid)) {
            isInlined=true;
            refid="";
        }
        else if (refid.startsWith("(") && refid.endsWith(")")) {
            refid = refid.substring(1,refid.length()-1);
            isInlined=true;
        }
        else if (FixtureExaminer.usableReference(P,refid)) {
            Properties all = FixtureExaminer.getReferencedProperties(P,refid,null);
            if (all!=null) {
                return handleOp(all,op,arg2,key);
            }
        } 

        //NB: Look for inlined iff not a refid and most-likely inlined
        if (isInlined || (P.getReference(refid)==null && refid.indexOf("=")>0)) {
            GenericParameters impl = new GenericParameters(P);
            impl.setList(refid);
            return handleOp(impl.toProperties(P),op,arg2,key);
        }
        return null;
    }


    private String handleOp(Properties all, int op, String arg2, String key)
    {
        switch(op) {
            case SIZE: {
                return String.valueOf(all.size());
            }
            case ISEMPTY: {
                return String.valueOf(all.isEmpty());
            }
            case KEYSET: {
                return listFrom(all.keySet().iterator(),delimFrom(arg2));
            }
            case VALUES: {
                return listFrom(all.values().iterator(),delimFrom(arg2));
            }
            case LOOKUP: {
                //NB: For missing properties we interpret the 2nd
                //    arg slot as a default value when defined!
                //    Example: $map:mymap?nosuchkey,,MISSING
                String value = all.getProperty(key);
                if (value==null && arg2!=null) {
                    value = arg2;
                }
                return value;
            }
            case DUMP: {
                return String.valueOf(all);
            }
        }
        return null;
    }
}

/* end-of-MapFunctionShortcut.java */