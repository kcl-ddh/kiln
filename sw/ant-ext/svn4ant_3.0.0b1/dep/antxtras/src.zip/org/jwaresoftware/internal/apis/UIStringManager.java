/**
 * $Id: UIStringManager.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.apis;

import  java.text.MessageFormat;

/**
 * Helper that manages the locating and retrieval of user-readable
 * strings from a generic (and usually localizable) data source. Adds the following
 * abilities to the the generic Java
 * {@linkplain java.util.ResourceBundle ResourceBundles}:<ul>
 *   <li>Is an interface not a class (allows easier integration in distributed runtime).
 *   <li>Intended for strings <em>only</em>; use ResourceBundles (or Configuration)
 *       for generic object retrieval.
 *   <li>Can be used for string collections differentiated by some criterion other
 *       than locale (for example application version).
 *   <li>Can be used as an interface to ResourceBundles, Configurations, and other
 *       memory-based data stores.
 *   <li>Generates runtime exceptions instead of checked exceptions. The idea is that
 *       the underlying strings <em>should</em> be available. Their absence indicates
 *       a serious (though not necessarily catastrophic) problem in a running system. So&#133;
 *   <li>Each retrieval entry-point allows the caller to define a runtime fallback
 *       value (which is used instead of throwing checked exceptions).
 *   <li>Integral support for runtime variable replacement in interface.
 * </ul>
 *
 * @since    JWare/internal 1.0
 * @author   ssmc, &copy;1997-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 * @see      org.jwaresoftware.internal.uism.StringTemplatesManager
 **/

public interface UIStringManager
{
    /**
     * Retrieves a message with given arguments substituted for placeholders.
     **/
    String mget(String key, Object[] args);


    /**
     * Retrieves a message with given arguments substituted for appropriate
     * placeholders. Uses 'defm' as a default response if cannot locate the
     * message template.
     **/
    String mget(String key, Object[] args, String defm);


    /**
     * Retrieves a customized message with given arguments substituted for
     * appropriate placeholders. Uses defm as a default response if cannot
     * locate the message template.
     **/
    String mget(MessageFormat mf, String key, Object[] args, String defm);




    /**
     * Retrieves a named message; assumes no placeholder substitution.
     **/
    String get(String key);


    /**
     * Retrieves a message with default if message not found.
     **/
    String dget(String key, String defm);




    /**
     * Retrieves a message with given argument substituted for placeholders.
     **/
    String get(String key, Object arg1);


    /**
     * Retrieves a message with given argument substituted for placeholders.
     **/
    String dget(String key, Object arg1, String defm);




    /**
     * Retrieves a message with given 2 arguments substituted for placeholders.
     **/
    String get(String key, Object arg1, Object arg2);


    /**
     * Retrieves a message with given 2 arguments substituted for placeholders.
     **/
    String dget(String key, Object arg1, Object arg2, String defm);




    /**
     * Retrieves a message with given 3 arguments substituted for placeholders.
     **/
    String get(String key, Object arg1, Object arg2, Object arg3);


    /**
     * Retrieves a message with given 3 arguments substituted for placeholders.
     **/
    String dget(String key, Object arg1, Object arg2, Object arg3, String defm);




    /**
     * Returns the default string for this UIStringManager. Should never
     * return <i>null</i>.
     **/
    String getDefaultString();
}

/* end-of-UIStringManager.java */
