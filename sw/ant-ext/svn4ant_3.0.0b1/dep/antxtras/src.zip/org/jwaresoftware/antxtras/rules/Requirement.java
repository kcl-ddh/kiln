/**
 * $Id: Requirement.java 1010 2010-03-12 02:13:15Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.starters.Quiet;
import  org.jwaresoftware.antxtras.starters.StrictInnerTask;
import  org.jwaresoftware.antxtras.starters.StrictOuterTask;

/**
 * A {@linkplain BuildRule} item that must evaluate <i>true</i>. If a requirement
 * evaluates <i>false</i> it will update the project property defined in the current
 * threads update-information packet before throwing an assertion build exception.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  guarded
 * @.group   api,infra
 * @see      BuildRule
 * @see      Preference
 **/

final class Requirement extends AssertTask implements StrictInnerTask,Quiet
{
    /**
     * Initializes a new requirement.
     **/
    Requirement()
    {
        super(AntX.rules+"Assert",true,true);
    }


    /**
     * Associates this preference with its enclosing build rule.
     * @param enclosingTask enclosing {@linkplain BuildRule build rule} (non-null)
     **/
    public void setEnclosingTask(StrictOuterTask enclosingTask)
    {
        require_((enclosingTask instanceof RuleSet), "setEnclTsk- only buildrule");
        m_owningRule = enclosingTask;
    }


    /**
     * Returns the {@linkplain BuildRule build rule} in which this
     * preference is nested. Returns <i>null</i> if never set.
     **/
    public StrictOuterTask getEnclosingTask()
    {
        return m_owningRule;
    }


    /**
     * Verifies in a valid project and nested within a build rule.
     * @throws BuildException if not in project and/or build rule
     **/
    protected void verifyCanExecute_(String calr)
    {
        verifyInProject_(calr);
        if (getEnclosingTask()==null) {
            String ermsg = uistrs().get("task.only.in.outer",getTaskName(),"rule");
            log(ermsg,Project.MSG_ERR);
            throw new BuildException(ermsg);
        }
    }


    private StrictOuterTask m_owningRule;
}

/* end-of-Requirement.java */
