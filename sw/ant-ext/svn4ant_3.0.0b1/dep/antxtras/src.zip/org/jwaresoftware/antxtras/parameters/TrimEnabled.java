/**
 * $Id: TrimEnabled.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for any item that supports the standard
 * '<span class="src">trim=[yes|no]</span>' short-hand condition modifier.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2003-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   impl,helper
 **/

public interface TrimEnabled
{
    /**
     * Tells this item to trim strings when used.
     * @param trim <i>true</i> to trim strings
     **/
    void setTrim(boolean trim);


    /**
     * Returns <i>true</i> if this item will trim strings
     * when used.
     **/
    boolean willTrim();
}

/* end-of-TrimEnabled.java */
