/**
 * $Id: ConditionalLocal.java 1036 2010-03-20 18:00:15Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.fixture.wrap;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.go.Iff;
import  org.jwaresoftware.antxtras.go.Unless;
import  org.jwaresoftware.antxtras.helpers.InnerNameValuePair;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * A local parameter that can be conditionally applied.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    api,helper
 * @see       Locals
 **/

public final class ConditionalLocal extends InnerNameValuePair
{
    private final static String IAM_= AntX.fixture+"ConditionLocal:";


    /**
     * Initializes a new conditional parameter.
     **/
    public ConditionalLocal(Project myproject)
    {
        AntX.require_(myproject!=null,IAM_,"Non-null project required");
        m_project = myproject;
        setNull();
    }


    /**
     * Sets ths local's true condition evaluation <em>result</em>.
     * If the incoming string is a positive boolean string then
     * the "true condition" will pass.
     * @param boolstr the evaluation's result (non-null)
     * @since JWare/AntXtras 3.0.0 (pre v3's 'if')
     **/
    public void setTrue(String boolstr)
    {
        m_enabled = m_enabled &&
            Boolean.TRUE.equals(Tk.string2PosBool(boolstr));
    }



    /**
     * Sets ths local's false condition evaluation <em>result</em>.
     * If the incoming string is a positive boolean string then
     * the "false condition" will fail.
     * @param boolstr the evaluation's result (non-null)
     * @since JWare/AntXtras 3.0.0 (pre v3's 'unless')
     **/
    public void setFalse(String boolstr)
    {
        m_enabled = m_enabled &&
            !Boolean.TRUE.equals(Tk.string2PosBool(boolstr));
    }



    /**
     * Sets ths local's true condition evaluation <em>result</em>.
     * If the incoming property's name matches an existing property
     * in this local's project then the "if condition" will pass.
     * @param property the property name (non-null)
     **/
    public void setIf(String property)
    {
        m_enabled = m_enabled &&
            Iff.allowed(property,getProject());
    }



    /**
     * Sets ths local's true condition evaluation <em>result</em>.
     * If the incoming property's name does not match any existing 
     * property in this local's project then the "unless" will pass.
     * @param property the property name (non-null)
     **/
    public void setUnless(String property)
    {
        m_enabled = m_enabled &&
            Unless.allowed(property,getProject());
    }



    /**
     * Returns <i>true</i> if this local's apply test(s) allow
     * installation.
     **/
    public final boolean isEnabled()
    {
        return m_enabled;
    }



    /**
     * Indicates whether this item should inherit its initial
     * value from the surrounding context. The default setting
     * of this property depends on the target fixture element.
     * @param inherit <i>true</i> to always inherit
     **/
    public void setInherit(boolean inherit)
    {
        m_inherit = inherit ? Boolean.TRUE : Boolean.FALSE;
    }



    /**
     * Returns this item's inherit flag setting. Will return
     * <i>null</i> if never set explicitly.
     **/
    public final Boolean getInheritFlag()
    {
        return m_inherit;
    }


    private Project getProject()
    {
        return m_project;
    }


    private boolean m_enabled = true;
    private Boolean m_inherit;
    private Project m_project;
}

/* end-of-ConditionalLocal.java */