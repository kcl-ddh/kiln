/**
 * $Id: EmptyBuildstrs.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.internal.helpers;

import  java.io.Serializable;

import  org.jwaresoftware.internal.apis.Buildstrs;

/**
 * An well-defined collection of placeholder release information.
 * Use in place of <i>null</i>.
 *
 * @since     JWare/internal 1.2
 * @author    ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    impl,helper
 * @.pattern  JWare.NullProxy
 **/

public class EmptyBuildstrs implements Buildstrs, Serializable, Cloneable
{
    private static final String UNDEFINED= "undefined";


    /**
     * VM-shareable singleton; never <i>null</i>.
     **/
    public static final EmptyBuildstrs INSTANCE= new EmptyBuildstrs();


    /**
     * Creates a new buildstrs instance.
     **/
    public EmptyBuildstrs()
    {
    }


    /**
     * Returns "<i>NOID</i>" (note is all uppercased).
     **/
    public String getID()
    {
        return "NOID";
    }


    /**
     * Returns "<i>undefined</i>".
     **/
    public String getDisplayName()
    {
        return UNDEFINED;
    }


    /**
     * Returns "<i>0&#46;0</i>".
     **/
    public String getVersion()
    {
        return "0.0";
    }


    /**
     * Returns "<i>0&#46;0_build00&#46;00</i>".
     **/
    public String getBuildVersion()
    {
        return "0.0_build00.00";
    }


    /**
     * Returns "<i>oo</i>".
     **/
    public String getNSPrefix()
    {
        return "oo";
    }


    /**
     * Returns "<i>http://purl&#46;net/jware/xmlns/</i>".
     **/
    public String getNSURI()
    {
        return "http://purl.net/jware/xmlns/";
    }


    /**
     * Returns "<i>oo&#46;</i>".
     **/
    public String getPropertiesPrefix()
    {
        return "oo.";
    }


    /**
     * Returns "<i>Jan-01-2001</i>".
     **/
    public String getAbbrDate()
    {
        return "Jan-01-2001";
    }


    /**
     * Returns "<i>Jan012001_1010101GMT</i>".
     **/
    public String getLongDate()
    {
        return "Jan012001_1010101GMT";
    }


    /**
     * Returns "<i>undefined</i>".
     **/
    public String getOS()
    {
        return UNDEFINED;
    }


    /**
     * Returns "<i>undefined</i>".
     **/
    public String getBuilderID()
    {
        return UNDEFINED;
    }


    /**
     * Returns "<i>undefined</i>".
     **/
    public String getBuilderCN()
    {
        return UNDEFINED;
    }


    /**
     * Returns "<i>undefined</i>".
     **/
    public String getHostID()
    {
        return UNDEFINED;
    }


    /**
     * Returns "<i>undefined</i>".
     **/
    public String getUsedPaths()
    {
        return UNDEFINED;
    }


    /** Determines if this buildstrs is equal to given object&#150; which has
     * to be another EmptyBuildstrs.
     **/
    public boolean equals(Object o)
    {
        if (o==null) {
            return false;
        }
        if (o==this || o.getClass()==EmptyBuildstrs.class) {
            return true;
        }
        return false;
    }


    /** Returns a hash value for this object. Since all instances of this class
     * are considered equal, the hash value depends on the class's id. **/
    public int hashCode()
    {
        return HASH_;
    }


    /** Returns clone of this object. **/
    public Object clone()
    {
        try {
            return super.clone();
        } catch(CloneNotSupportedException clnx) {
            throw new InternalError();
        }
    }


    /** Returns {@linkplain #getDisplayName display name} of this buildstrs instance. **/
    public String toString()
    {
        return getDisplayName();
    }


    /** Alternative way to get to {@linkplain #INSTANCE}. **/
    public static final Buildstrs getInstance()
    {
        return INSTANCE;
    }


    /* -- seekrit, hashid same for all instances. -- */
    private static final int HASH_= EmptyBuildstrs.class.getName().hashCode();
}

/* end-of-EmptyBuildstrs.java */
