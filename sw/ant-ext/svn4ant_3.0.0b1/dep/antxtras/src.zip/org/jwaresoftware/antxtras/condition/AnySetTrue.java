/**
 * $Id: AnySetTrue.java 415 2008-04-22 02:08:37Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

/**
 * Slight variant of {@linkplain AnySet} that requires at least one named item to contain
 * (or refer to) a positive boolean string. Exists to help inlined value URIs be more
 * selective.
 * <p>
 * <b>Example Usage:</b><pre>
 *    &lt;property name="debug.enabled" value="no"/&gt;
 *    &lt;property name="metrics.enabled" value="false"/&gt;
 *    ...
 *    &lt;tallyset id="testfor.diagnostics" trueproperty="diagnostics.enabled"&gt;
 *       &lt;anysettrue&gt;
 *          &lt;property name="debug.enabled"/&gt;
 *          &lt;property name="metrics.enabled"/&gt;
 *       &lt;/anysettrue&gt;
 *    &lt;/tallyset&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    api,helper
 **/

public final class AnySetTrue extends AnySet
{
    /**
     * Initializea a new any set true condition.
     **/
    public AnySetTrue()
    {
        setTruesOnly();
    }
}

/* end-of-AnySetTrue.java */