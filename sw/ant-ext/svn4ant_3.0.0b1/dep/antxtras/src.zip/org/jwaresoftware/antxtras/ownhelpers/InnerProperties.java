/**
 * $Id: InnerProperties.java 410 2008-04-20 17:33:55Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.ownhelpers;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableProjectComponent;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.IgnoreCaseEnabled;
import  org.jwaresoftware.antxtras.parameters.PropertySource;

/**
 * Custom &lt;propertyset&gt; that simplifies syntax for succinct inclusion in
 * assertions and other AntX rules. Also supports the AntXtra nomenclature for
 * a property's {@linkplain PropertySource source domain}.
 * <p>
 * Note that an <span class="src">InnerProperties</span>'s default domain is
 * "<span class="src">script--</span>" <em>not</em> "<span class="src">all</span>".
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;allset malformed="reject"&gt;
 *      &lt;properties prefix="jware.antx." domain="all--"/&gt;
 *      &lt;properties like="^build\..*$"/&gt;
 *      &lt;properties prefix="build." ignorecase="yes"/&gt;
 *   &lt;/allset&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,helper
 * @see      PropertiesIterator
 **/

public class InnerProperties extends AssertableProjectComponent
    implements IgnoreCaseEnabled, Cloneable
{
    private static final String PATTERN="like";
    private static final String PREFIX="prefix";
    private static final String NOTLIKE="notlike";


    /**
     * Initializes a new properties declaration.
     **/
    public InnerProperties()
    {
        super(AntX.utilities+"InnerProperties:");
    }


    /**
     * Initializes a new utility properties
     * declaration.
     **/
    public InnerProperties(String iam)
    {
        super(iam);
    }



    /**
     * Returns a clone of this properties declaration.
     * @since JWare/AntX 0.5
     */
    public Object clone()
    {
        try {
            return super.clone();
        } catch(CloneNotSupportedException clnX) {
            throw new CloneBrokenError();
        }
    }



    /**
     * Defines a regular expression filter for properties.
     **/
    public void setLike(String pattern)
    {
        require_(!Tk.isWhitespace(pattern),"setLik- nonzro pattern");
        setNewFilter(PATTERN,pattern);
    }


    /**
     * Returns this declaration's regular expression filter.
     * Returns <i>null</i> if never set.
     **/
    public String getLikeFilterPattern()
    {
        return getFilterParameter(PATTERN);
    }


    /**
     * Defines a prefix filter for properties.
     **/
    public void setPrefix(String prefix)
    {
        require_(prefix!=null,"setPrefx- nonzro prefix");
        setNewFilter(PREFIX,prefix);
    }


    /**
     * Returns this declaration's prefix filter.
     * Returns <i>null</i> if never set.
     **/
    public String getPrefixFilterPattern()
    {
        return getFilterParameter(PREFIX);
    }


    /**
     * Defines a regular expression filter for excluded properties.
     **/
    public void setNotLike(String pattern)
    {
        require_(!Tk.isWhitespace(pattern),"setNotLik- nonzro pattern");
        setNewFilter(NOTLIKE,pattern);
    }


    /**
     * Returns this declaration's exclusion regular expression filter.
     * Returns <i>null</i> if never set.
     **/
    public String getNotLikeFilterPattern()
    {
        return getFilterParameter(NOTLIKE);
    }


    /**
     * Sets the source of this declaration's properties. This setter
     * allows all the synonyms for the AntXtra property sources that
     * are compatible with Ant's own &lt;propertyset&gt;'s
     * <span class="src">builtin</span> parameter.
     * @param domainname symbolic name of domain (synonyms allowed)
     **/
    public void setDomain(String domainname)
    {
        PropertySource domain = PropertySource.from(domainname);
        require_(domain!=null,"setDomain- recognized domain");
        m_domain = domain;
    }


    /**
     * Returns the source of this declaration's properties.
     * Returns {@linkplain PropertySource#SCRIPTlite} if
     * never set explicitly.
     **/
    public PropertySource getDomain()
    {
        return m_domain;
    }


    /**
     * Tells this declaration to ignore case (or not)
     * in filters.
     * @param ignore <i>true</i> to ignore
     **/
    public void setIgnoreCase(boolean ignore)
    {
        m_ignoreCase = ignore;
    }


    /**
     * Returns <i>true</i> if this declaration wants
     * case-insensitive filtering. Is <i>false</i> by default.
     **/
    public boolean isIgnoreCase()
    {
        return m_ignoreCase;
    }


    /**
     * Called whenever a filter is defined; ensures at most one
     * filter is defined.
     **/
    private void setNewFilter(String choice, String param)
    {
        if (m_filterType!=null) {
            String error = uistrs().get
                (Errs.TOOOA,"like","prefix");
            log(error, Project.MSG_ERR);
            throw new BuildException(error);
        }
        m_filterType = choice;
        m_filterParameter = param;
    }


    /**
     * Returns the filter parameter string if if the caller's
     * type matches what was set. Otherwise, returns <i>null</i>.
     **/
    private String getFilterParameter(String choice)
    {
        return (m_filterType==choice) ? m_filterParameter : null;
    }


    private String m_filterType;
    private String m_filterParameter;
    private PropertySource m_domain = PropertySource.SCRIPTlite;
    private boolean m_ignoreCase;
}

/* end-of-InnerProperties.java */
