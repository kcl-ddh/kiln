/**
 * $Id: ManageFuncutsTask.java 1042 2010-03-27 16:52:23Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts;

import  java.util.Collection;
import  java.util.Collections;
import  java.util.Iterator;
import  java.util.Map;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.PropertyHelper;

import  org.jwaresoftware.antxtras.behaviors.BuildError;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.FixtureExaminer;
import  org.jwaresoftware.antxtras.core.FixtureIds;
import  org.jwaresoftware.antxtras.core.FixtureInitializer;
import  org.jwaresoftware.antxtras.core.FunctionShortcut;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.core.NoiseLevel;
import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.helpers.Empties;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.FeedbackLevel;
import  org.jwaresoftware.antxtras.starters.SimpleManagerTask;

/**
 * A manager task that (un)installs a function shortcut aware property 
 * helper hook. Once installed this hook lets you use the 
 * "<span class="src">${$scheme:[fragment]}</span>" shorthand string
 * to retrieve arbitrary types of data. This task is a valid
 * antlib definition task, so you can include it in your antlib scriptlets.
 * Usually defined as <span class="src">&lt;managefuncuts&gt;</span>.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   <b>-- To Enable --</b>
 *    &lt;managefuncuts action="enable"/&gt; -or-
 *    &lt;managefuncuts/&gt;
 *
 *   <b>-- To Install A Set Of Handlers --</b>
 *    &lt;managefuncuts action="install"&gt;
 *       &lt;parameter name="foo" value="com.mysoft.FooUriReader"/&gt;
 *       &lt;parameter name="bar" value="com.mysoft.BarUriReader"/&gt;
 *    &lt;/managefuncuts&gt;
 *
 *   <b>-- To Disable --</b>
 *    &lt;managefuncuts action="disable"/&gt;
 *
 *   <b>-- To Uninstall A Set Of Handlers --</b>
 *    &lt;managefuncuts action="uninstall"&gt;
 *       &lt;parameter name="foo"/&gt;
 *    &lt;/managefuncuts&gt; -or-
 *
 *    &lt;managefuncuts action="uninstall-all"/&gt; -or-
 *    &lt;managefuncuts action="uninstall-all"&gt;
 *       &lt;parameter name="disable" value="yes"/&gt;
 *    &lt;/managefuncuts&gt;
 *
 *   <b>-- To Check Whether Funcut Interpretation Is Enabled --</b>
 *    &lt;managefuncuts action="check"/&gt; -or-
 *
 *    &lt;managefuncuts action="check"&gt;
 *       &lt;parameter name="updateproperty" name="funcuts.enabled"/&gt;
 *    &lt;/managefuncuts&gt;  -or-
 *
 *    &lt;managefuncuts action="check"&gt;
 *       &lt;parameter name="handler.0" value="ospathurl"/&gt;
 *       &lt;parameter name="handler.1" value="istype"/&gt;
 *    &lt;/managefuncuts&gt;
 *
 *   <b>-- To Dump all Installed Funcut handler classnames --</b>
 *    &lt;managefuncuts action="dumphandlers"/&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   single
 * @.group    api,helper
 * @.impl     Direct access to project references map is intentional to avoid
 *            the spurious warnings about replaced references.
 * @see       org.jwaresoftware.antxtras.core.FunctionShortcut
 **/

public class ManageFuncutsTask extends SimpleManagerTask
    implements FixtureInitializer
{
    private static final String REFID = FixtureIds.FUNCUTS_INTERPRETER;
    private static final String LABEL = "FuntionShortcutInterpreter";


    /**
     * Initializes a new "enabling" manager task. You must set
     * the action option of this task to change its default
     * enable behavior.
     **/
    public ManageFuncutsTask()
    {
        super(AntX.fixture+"ManageFuncutsTask:","enable");
    }



    /**
     * Verifies that there are no function shortcut interpreters 
     * in the current property helper evaluator chain w/o a matching 
     * reference marker.
     * @param ph the currently installed property helper (non-null)
     **/
    private void verifyNotInstalled(PropertyHelper ph)
    {
        Collection alle = FixtureExaminer.getEvaluators(ph);
        for (Iterator itr=alle.iterator();itr.hasNext();) {
            Object next = itr.next();
            if (next instanceof Interpreter) {
                String error = Iteration.uistrs().get
                    ("fixture.supPh.stack.corrupted",LABEL);
                log(error, Project.MSG_ERR);
                throw new BuildError(error);
            }
        }
    }



    /**
     * Converts a fully qualified class name to a FunctionShortcut
     * class instance.
     * @param e the slot o' information
     * @param cl custom classloader (can be <i>null</i>)
     * @return the class reference
     * @throws BuildException if unable to load class or class
     *      is incompatible.
     **/
    private Class loadHandlerClass(Map.Entry e, ClassLoader cl)
    {
        String classname = (String)e.getValue();
        try {
            Class c;
            if (cl!=null) {
                c = Class.forName(classname,true,cl);
            } else {
                c = Class.forName(classname);
            }
            if (!FunctionShortcut.class.isAssignableFrom(c)) {
                throw new ClassCastException();
            }
            return c;
        } catch (Exception anyX) {
            String error = Iteration.uistrs().get("task.bad.custimpl.class1",
                classname, FunctionShortcut.class.getName());
            log(error, Project.MSG_ERR);
            throw new BuildException(error, anyX, getLocation());
        }
    }



    /**
     * Will install a set of shortcut handlers. Each handler is
     * defined by a generic parameter; the parameter's name is the
     * value uri prefix, and the value is the fully qualified class
     * name of the handler.
     * @param args list of funcut handlers to enable explicitly
     **/
    public void doInstall(Map args)
    {
        if (!args.isEmpty()) {
            Iterator itr= args.entrySet().iterator();
            Class oldc, newc;
            boolean warnreplace = isVerbose();
            ClassLoader cl = getAntlibClassLoader();

            while (itr.hasNext()) {
                Map.Entry e = (Map.Entry)itr.next();
                String prefix = (String)e.getKey();

                if (!FixtureExaminer.isBuiltinFunctionShortcutScheme(prefix)) {
                    newc = loadHandlerClass(e,cl);
                    oldc = Iteration.replaceFuncutHandler(prefix,newc);
                    if (warnreplace && oldc!=null && oldc!=newc) {
                        String warning = Iteration.uistrs().get("valueuri.repl.handlr",
                            prefix, oldc.getName(), newc.getName());
                        log(warning, Project.MSG_WARN);
                    } else {
                        log("For ("+prefix+") installed funcut handler "+newc.getName(),
                            Project.MSG_VERBOSE);
                    }
                } else {
                    String warning = Iteration.uistrs().get("valueuri.resrved.handlr",prefix);
                    log(warning, Project.MSG_WARN);
                }
            }
        }
    }



    /**
     * Will install a property evaluator to interpret AntXtras funcut
     * URIs. Does nothing if an evaluator is already installed for
     * the enclosing project (issues warning). If funcut handlers
     * are declared (as parameters), those handlers are added automatically.
     * @param args list of funcut handlers to also install
     **/
    public void doEnable(Map args)
    {
        Project p = getProject();
        Map ht = p.getReferences();
        boolean warn = false;

        synchronized(ht) {//NB:forces FxExaminer queries to wait too...
            Object o = ht.get(REFID);
            if (o==null) {
                PropertyHelper ph0 = PropertyHelper.getPropertyHelper(p);//Ant
                verifyNotInstalled(ph0);
                Interpreter interpreter = new Interpreter(p,m_rqlink);
                PropertyHelper npa = PropertyHelper.getPropertyHelper(p);//Us
                npa.add(interpreter);
                ht.put(REFID,interpreter);
                log("Enabled RPI and Funcuts successfully; project="+Tk.identityStringFrom(p),
                        Project.MSG_VERBOSE);
            } else {
                warn = true;
            }
        }
        if (!args.isEmpty()) {
            this.doInstall(args);
            warn = false;
        }
        if (warn && isVerbose()) {
            String warning = Iteration.uistrs().get("fixture.supPh.install.once",LABEL);
            log(warning, Project.MSG_WARN);
        }
    }



    /**
     * Shortcut to disable and immediate reenable funcuts.
     * Useful after local adjustment to some setting that
     * affects functioning of the function shortcuts environment.
     * @param args list of funcut handlers to also install on reenable
     * @since JWare/AntXtras 3.0.0
     **/
    public final void doReenable(Map args)
    {
        doDisable(Empties.MAP);
        doEnable(args);
    }



    /**
     * Will uninstall a set of named funcut handlers from the
     * current iteration. Does nothing if the args list is empty.
     * @param args list of funcut handlers to install
     **/
    public void doUninstall(Map args)
    {
        if (!args.isEmpty()) {
            Iterator itr= args.keySet().iterator();
            while (itr.hasNext()) {
                String prefix = (String)itr.next();
                if (!FixtureExaminer.isBuiltinFunctionShortcutScheme(prefix)) {
                    Iteration.removeFuncutHandler(prefix);
                    log("For ("+prefix+") UNinstalled funcut handler",
                            Project.MSG_VERBOSE);
                } else {
                    String warning = Iteration.uistrs().get("valueuri.resrved.handlr",prefix);
                    log(warning, Project.MSG_WARN);
                }
            }
        }
    }



    /**
     * Will uninstall <em>all</em> application funcut handlers from
     * the current iteration. Can optionally disable handling also.
     * @param args list of addition control options
     * @since JWare/AntX 0.6
     **/
    public void doUninstallAll(Map args)
    {
        Iteration.removeAllFuncutHandlers();
        if (!args.isEmpty()) {
            Object option = args.get("disable");
            if (option!=null && Tk.string2PosBool((String)option)==Boolean.TRUE) {
                this.doDisable(Collections.EMPTY_MAP);
            }
        }
    }



    /**
     * Will uninstall a property helper hook that interprets AntXtras
     * funcut URIs. Does nothing if no such interpreter exists in
     * the current project (issues a warning).
     * @param ignoredArgs [ignored]
     **/
    public void doDisable(Map ignoredArgs)
    {
        Project p = getProject();
        Map ht = p.getReferences();
        boolean warn=false;

        synchronized(ht) {//NB:forces FxExaminer queries to wait too...
            Object o = ht.get(REFID);
            if (o instanceof Interpreter) {
                Interpreter interpreter = (Interpreter)o;
                interpreter.uninstall(m_rqlink,System.currentTimeMillis());

                ht.remove(REFID);
                warn = true;

                PropertyHelper ph = PropertyHelper.getPropertyHelper(p);
                if (FixtureExaminer.unsetDelegate(ph,interpreter,m_rqlink)>0) {
                    warn = false;
                    log("Disabled funcut interpreter",Project.MSG_VERBOSE);
                }
                interpreter = null;
            }
            o = null;
        }

        if (warn && isVerbose()) {
            String warning= Iteration.uistrs().get("fixture.supPh.not.instald",LABEL);
            log(warning,Project.MSG_WARN);
        }
    }



    /**
     * Tests for the existence of a funcut interpreter in the
     * enclosing project. The check generates one of three possible
     * answers: <span class="src">yes</span>, <span class="src">no</span>,
     * and <span class="src">unknown</span>. An unknown is flagged if
     * <em>something</em> is declared as an interpreter but is not
     * known to this manager task.
     * <p/>
     * This action can be configured to save its answer string to a
     * project property or variable; set either the
     * "<span class="src">updateproperty</span>" or
     * "<span class="src">updatevariable</span>"
     * parameters to the name of the fixture elements to be set.
     * <p/>
     * You can also query the handler installed for a particular
     * funcut URI by setting a parameter "handler[.N]" to the funcut's
     * scheme name like: &lt;parameter name="handler.0" value="truefalse"/&gt;.
     * You can include as many handler query parameter as you like.
     * @param args custom update property instructions (non-null)
     **/
    public void doCheck(Map args)
    {
        Project p = getProject();
        Map ht = p.getReferences();
        String result = "no";
        boolean installed = false;

        synchronized(ht) {//NB:forces FxExaminer queries to wait too...
            Object o = ht.get(REFID);
            if (o instanceof Interpreter) {
                result = "yes";
                installed = true;
            }
            else if (o!=null) {
                result = "unknown";
            }
        }

        boolean saved=false;
        int Nargs = args.size();

        Object o = args.get("updateproperty");
        if (o!=null) {
            String property = o.toString();
            FixtureExaminer.checkIfProperty(p,m_rqlink,property,true);
            p.setNewProperty(property,result);
            saved = true;
            Nargs--;
        }
        o = args.get("updatevariable");
        if (o!=null) {
            Variables.set(o.toString(),result,m_rqlink);
            saved = true;
            Nargs--;
        }
        if (!saved) {
            int level = NoiseLevel.getDefault(p).getNativeIndex();
            String msg = Iteration.uistrs().get("valueuri.instaled",result);
            log(msg, level);
        }

        //@since JWare/AntX 0.6
        if (installed && Nargs>0) {
            Iterator itr = args.entrySet().iterator();
            Iteration I = Iteration.get();
            int level = getNoiseLevel();
            while (itr.hasNext()) {
                Map.Entry next = (Map.Entry)itr.next();
                if (((String)next.getKey()).startsWith("handler")) {
                    String scheme = (String)next.getValue();
                    String msg = "For("+scheme+") have funcut handler "+I.toString("funcut?"+scheme);
                    log(msg,level);
                }
            }
        }
    }



    /**
     * Dumps the set of scheme names to class name mappings that represents
     * the installed valueuris for the current Iteration.
     * @param args [ignored] arguments for action
     * @since JWare/AntX 0.6
     **/
    public void doDumpHandlers(Map args)
    {
        Map mappings = Iteration.getFuncutHandlerClassNames();
        Iterator itr = mappings.entrySet().iterator();
        int level = getNoiseLevel();

        while (itr.hasNext()) {
            Map.Entry next = (Map.Entry)itr.next();
            String scheme = (String)next.getKey();
            String msg = "For("+scheme+") have funcut handler "+next.getValue();
            log(msg,level);
        }
    }



    /**
     * Determine the best noise level for dumping diagnostics about
     * installed handlers.
     * @since JWare/AntX 0.6
     **/
    private int getNoiseLevel()
    {
        int level = NoiseLevel.getDefault(getProject()).getNativeIndex();
        FeedbackLevel fbl = getFeedbackLevel();
        if (fbl!=FeedbackLevel.NORMAL) {
            if (FeedbackLevel.isQuietish(fbl,false)) {
                level = NoiseLevel.VERBOSE.getIndex();
            } else {
                level = NoiseLevel.INFO.getIndex();
            }
        }
        return level;
    }



    /**
     * Our hook into the standard Ant project property framework.
     * This class must play nice with other installed hooks. Redone
     * as of AntXtras 3.0.0 to implement Ant 1.8 PropertyEvaluator 
     * instead of pre-Ant1.8's propertyHooks.
     *
     * @since     JWare/AntX 0.5
     * @author    ssmc, &copy;2004,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version   3.0.0b1
     * @.safety   guarded (inherited)
     * @.group    impl,helper
     */
    private static class Interpreter implements PropertyHelper.PropertyEvaluator
    {
        private final Project m_project;
        private NestedPropertyAnalyzer m_npHelper;
        private long m_deadTime = -1L;

        /**
         * Initializes a new funcut interpreter AND a new nested
         * property resolver (since JWare/AntXtras 2.0.0).
         */
        Interpreter(Project project, Requester owner) {
            m_project = project;
            m_npHelper = new NestedPropertyAnalyzer(project,owner);
        }

        /**
         * Removes the nested property resolver we'd installed as PH.
         * @since JWare/AntXtras 3.0.0
         */
        void uninstall(Requester owner, long deadTime) {
            m_npHelper.uninstall(owner);
            m_deadTime = deadTime;
        }

        /**
         * Returns <i>true</i> if this interpreter has not been 
         * uninstalled. Due to issues w/ Ant 1.8 using unmodifiable
         * delegate sets-- we cannot be removed once installed (YIKES).
         * @since JWare/AntXtras 3.0.0
         **/
        boolean isAlive() {
            return m_deadTime<0L;
        }

        /**
         * Filters the incoming value through our fixture examiner.
         * If terminated does nothing.
         **/
        public Object evaluate(String name, PropertyHelper fromPH) {
            return isAlive() ? FixtureExaminer.findValue(m_project,name,null) : null;
        }
    }



    private boolean isVerbose()
    {
        //NB:undef => is quiet (don't warn)
        return !FeedbackLevel.isQuietish(getFeedbackLevel(),true,true);
    }



}

/* end-of-ManageFuncutsTask.java */