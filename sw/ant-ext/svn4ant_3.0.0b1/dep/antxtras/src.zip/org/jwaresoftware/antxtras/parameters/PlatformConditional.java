/**
 * $Id: PlatformConditional.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for a component that is only valid if certain
 * platform-dependent criteria are met.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2007-2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 **/

public interface PlatformConditional
{
    /**
     * Adds an if-os-matches condition to this component.
     * The supplied string can contain a comma-delimited
     * selection list in the form: <i>family,name,arch,version</i>.
     * To omit a field, put a "<span class="src">*</span>"
     * in that location like: "<span class="src">*,Linux,i686,*</span>".
     * If the field is at the end of the list, you can just
     * omit the field altogether like:
     * "<span class="src">unix,Linux</span>".
     * @param choice os selection string (non-null)
     **/
    void setIfOS(String choice);


    /**
     * Adds an unless-os-matches condition to this component.
     * See {@linkplain #setIfOS setIfOS(&#8230;)} for a
     * description of the <span class="src">choice</span>
     * string's format.
     * @param choice os selection string (non-null)
     **/
    void setUnlessOS(String choice);


    /**
     * Adds an if-ant-version-matches condition to this
     * component. The value returned by the Ant runtime's
     * "<span class="src">ant.version</span>" property
     * is what the condition tests against.
     * @param versionRE regular expression for version
     **/
    void setIfAntLike(String versionRE);


    /**
     * Adds an unless-ant-version-matches condition to this
     * component. The value returned by the Ant runtime's
     * "<span class="src">ant.version</span>" property is
     * what the condition tests against.
     * @param versionRE regular expression for version
     **/
    void setUnlessAntLike(String versionRE);
}

/* end-of-PlatformConditional.java */
