/**
 * $Id: ShareableConditionUser.java 799 2009-06-26 11:06:01Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.Location;

/**
 * Caller-specific attributes used by a shared build rule during an evaluation.
 * Build rules are shareable entities that can be evaluated from multiple
 * threads concurrently. To ensure that each thread can define and mutate its own
 * update information, a thread-specific "packet" of information is maintained
 * by every {@linkplain ShareableCondition} implementation.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 * @see      RuleSet
 * @see      ShareableCondition
 **/

public interface ShareableConditionUser
{
    /**
     * Returns the caller's msgid.
     **/
    String getMsgId();


    /**
     * Returns the caller's location.
     **/
    Location getLocation();


    /**
     * Returns the property to be updated if condition is <i>false</i>.
     **/
    String getUpdateProperty();


    /**
     * Returns the variable to be updated if condition is <i>false</i>.
     **/
    String getUpdateVariable();


    /**
     * Returns value to use to update either or both the update property
     * and the update variable.
     * @see #getUpdateProperty
     * @see #getUpdateVariable
     **/
    String getUpdateValue();
}

/* end-of-ShareableConditionUser.java */
