/**
 * $Id: Scope.java 1034 2010-03-20 15:05:26Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.EnumSkeleton;

/**
 * A fixture attribute's range of influence. Three options: 
 * <i>everything</i> (or all), <i>thread</i>, or <i>project</i>.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   api,helper
 * @see      Variables
 **/

public final class Scope extends EnumSkeleton
{
    /** Index of {@linkplain #EVERYTHING EVERYTHING} scope. **/
    public final int EVERYTHING_INDEX = 0;
    /** Index of {@linkplain #THREAD THREAD} scope. **/
    public final int THREAD_INDEX = EVERYTHING_INDEX+1;
    /** Index of {@linkplain #PROJECT PROJECT} scope. **/
    public final int PROJECT_INDEX = THREAD_INDEX+1;


    /**
     * VM-shareable instance of <i>thread</i> scope.
     **/
    public static final Scope THREAD = new Scope("thread");

    /**
     * VM-shareable instance of <i>project</i> scope.
     **/
    public static final Scope PROJECT = new Scope("project");

    /**
     * VM-shareable instance of <i>everything</i> scope.
     **/
    public static final Scope EVERYTHING = new Scope("all");
    public static final Scope ALL = EVERYTHING;



    /**
     * Required void constructor for Ant's introspector.
     **/
    public Scope()
    {
        super();
    }


    /**
       Private constructor to create our own singletons.
    **/
    private Scope(String v)
    {
        super(v);
    }


    /**
     * Returns copy of all possible values as ordered string
     * array. Ordering must be same as the _INDEX constants.
     **/
    public String[] getValues()
    {
        return new String[]{"all","thread","project"};
    }



    /**
     * The default scope used by all exporting tasks
     * within AntXtras.
     **/
    public static final Scope DEFAULT_SCOPE= Scope.THREAD;



    /**
     * Updates a modifiable fixture attribute with given value
     * depending on the specified scope.
     * @param S the value's scope (null => {@linkplain #DEFAULT_SCOPE})
     * @param P the active project (must be non-null if scope != THREAD)
     * @param name the fixture attribute's name (non-null)
     * @param value the attribute's value (non-null)
     * @param erase <i>true</i> if an empty value should 
     *        remove an attribute
     * @param clnt [optional] diagnostics callback
     **/
    public static void setTheValue(Scope S, Project P,
                                   String name, String value,
                                   boolean erase, Requester clnt)
    {
        if (S==null) {
            S= Scope.DEFAULT_SCOPE;
        }
        if (erase) {
            erase = value.length()==0;//NB: only vars can be zapped (ssmc)
        }
        if (Scope.THREAD.equals(S)) {
            if (erase) {
                Variables.delete(name,clnt);
            } else {
                Variables.set(name,value,clnt);
            }
        }
        else {
            if (P==null) {
                throw new IllegalArgumentException
                    ("Scope.setTheValue- nonNULL project required");
            }
            if (Scope.PROJECT.equals(S)) {
                P.addReference(name,value);
            }
            else {
                P.setInheritedProperty(name,value);
            }
        }
    }


    /**
     * Returns a modifiable fixture attribute's current value 
     * given its declared scope. Will return <i>null</i> if attribute
     * was never set. Uses a strict {@linkplain Stringifier} if a 
     * non-string reference is specified.
     * @param S the attribute's scope (<i>null</i> => {@linkplain #DEFAULT_SCOPE})
     * @param P the active project (must be non-null if scope != THREAD)
     * @param name the attribute's name (non-null)
     **/
    public static String getTheValue(Scope S, Project P, String name)
    {
        if (S==null) {
            S= Scope.DEFAULT_SCOPE;
        }
        if (Scope.THREAD.equals(S)) {
            return Variables.readstring(name);
        }
        if (P==null) {
            throw new IllegalArgumentException
                ("Scope.getTheValue- nonNULL project required");
        }
        if (Scope.PROJECT.equals(S)) {
            return Stringifier.get(false).stringFrom(P.getReference(name),P);
        }
        return P.getProperty(name);
    }




    /**
     * Helper that converts a scalar to a known scope. Returns 
     * <i>null</i> if value does not match any of expected indices.
     * @param i the index to be matched
     * @since JWare/AntX 0.5
     **/
    public static Scope from(int i)
    {
        if (i==ALL.index)     { return ALL; }
        if (i==PROJECT.index) { return PROJECT; }
        if (i==THREAD.index)  { return THREAD; }
        return null;
    }



    /**
     * Same as {@linkplain #from(int) from(int)} but with a
     * default value if value does not match any known indices.
     * @param i the index to be matched
     * @param dflt the default scope if necessary
     * @since JWare/AntX 0.5
     **/
    public static Scope from(int i, Scope dflt)
    {
        Scope xs= from(i);
        return (xs==null) ? dflt : xs;
    }



    /**
     * Helper that converts a string to a known Scope singleton.
     * Returns <i>null</i> if string unrecognized. String can be
     * either Scope's symbolic name or its index.
     * @since JWare/AntX 0.5
     **/
    public static Scope from(String s)
    {
        if (s!=null && s.length()>0) {
            s = Tk.lowercaseFrom(s);
            if (Character.isDigit(s.charAt(0))) {
                try { return from(Integer.parseInt(s)); }
                catch(Exception nfx) {/*burp*/}
            } else {
                if ("default".equals(s))     { return DEFAULT_SCOPE; }
                if (PROJECT.value.equals(s)) { return PROJECT; }
                if (THREAD.value.equals(s))  { return THREAD; }
                if (ALL.value.equals(s))     { return ALL;}
                if ("system".equals(s))      { return EVERYTHING;}
                if ("everything".equals(s))  { return EVERYTHING; }
            }
        }
        return null;
    }


    /**
     * Same as {@linkplain #from(java.lang.String) from(String)} 
     * but with a default value if value does not match any known
     * Scope's name.
     * @param s the symbolic name to be matched
     * @param dflt the default Scope if necessary
     * @since JWare/AntX 0.5
     **/
    public static Scope from(String s, Scope dflt)
    {
        Scope xs= from(s);
        return (xs==null) ? dflt : xs;
    }
}

/* end-of-Scope.java */
