/**
 * $Id: FunctionShortcutSkeleton.java 1038 2010-03-20 19:03:33Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.starters;

import  java.util.List;
import  java.util.ListIterator;

import  org.apache.tools.ant.Project;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.FunctionShortcut;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.Empties;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Common start for function shortcuts that do not provide default values.
 * Subclasses must still supply a public void constructor and an
 * implementation for the <span class="src">valueFrom</span> method.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    impl,helper
 **/

public abstract class FunctionShortcutSkeleton implements FunctionShortcut
{
    /**
     * Initializes a new shortcut instance.
     **/
    protected FunctionShortcutSkeleton()
    {
    }


    /**
     * Returns <i>null</i> always.
     **/
    public String getDefaultValue(String fullUri, Requester clnt)
    {
        return null;
    }


    /**
     * Returns <i>true</i> if funcut should fail if unable to resolve
     * or other error occurs. Usually just returns <i>null</i>.
     * @param clnt [optional] if resolve, caller information to resolve wrt.
     **/
    public boolean isHaltIfError(Requester clnt)
    {
        boolean flag;
        if (this.haltIfErrorFlag!=null) {
            flag = this.haltIfErrorFlag.booleanValue();
        } else {
            Project P = clnt!=null ? clnt.getProject() : null;
            if (P!=null) {
                flag = Iteration.defaultdefaults().isHaltIfError("funcuts",P);
            } else {
                flag = Iteration.defaultdefaults().isHaltIfError("funcuts");
            }
        }
        return flag;
    }


    /**
     * Tells this shortcut whether to fail explicitly. Overrides
     * environment only for this instance.
     * @param flag <i>true</i> or <i>false</i> to fail.
     * @since JWare/AntXtras 2.0.0
     **/
    public void setHaltIfError(boolean flag)
    {
        this.haltIfErrorFlag = Boolean.valueOf(flag);
    }


    /**
     * From a parameter fragment extract out the list of individual
     * parameters. Will return an empty list if fragment is empty.
     * @param fragment the funcut URI fragment
     * @param resolve <i>true</i> if source resolve extracted arguments
     * @param clnt [optional] if resolve, caller information to resolve wrt.
     * @return argument list (empty list if fragment empty)
     * @since JWare/AntXtras 2.0.0
     **/
    protected List splitArgs(String fragment, boolean resolve, Requester clnt)
    {
        int i = -1;
        if (fragment!=null) {
            i = fragment.indexOf(PARAMS_DELIMITER);
        }
        List args = Empties.LIST;
        if (i>=0) {
            args = Tk.splitList(fragment,PARAMS_DELIMITER);
            if (resolve) {
                final Project P = clnt.getProject();
                for (ListIterator itr= args.listIterator();itr.hasNext();) {
                    String arg = (String)itr.next();
                    arg = Tk.resolveString(P,arg,true);
                    itr.set(arg);
                }
            }
        }
        return args;
    }

    protected Boolean haltIfErrorFlag;
}

/* end-of-FunctionShortcutSkeleton.java */