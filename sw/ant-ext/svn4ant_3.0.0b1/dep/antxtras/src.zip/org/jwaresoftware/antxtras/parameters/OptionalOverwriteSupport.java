/**
 * $Id: OptionalOverwriteSupport.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for any control item that creates fixture items that
 * might or might not replace existing items. This interface forces the
 * control item to support the "<span class="src">haltifexists=[yes|no]</span>"
 * and "<span class="src">overwrite=[yes|no]</span>" control
 * parameters.
 *
 * @since     JWare/AntX 0.6
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    api,helper
 **/

public interface OptionalOverwriteSupport
{
    /**
     * Tells this item whether if it should signal an error if an item
     * matching the destination item's id already exists.
     * @param halt <i>true</i> to signal error.
     **/
    void setHaltIfExists(boolean halt);


    /**
     * Returns this item's haltiferror option setting. Will return
     * <i>null</i> if never set explicitly.
     **/
    Boolean getHaltIfExistsFlag();


    /**
     * Tells this item whether if it can replace an existing item with
     * the new information. Only important if the haltifexists option
     * is disabled.
     * @param overwrite <i>true</i> if ok to automatically overwrite.
     **/
    void setOverwrite(boolean overwrite);


    /**
     * Returns this item's overwrite option setting. Will return
     * <i>null</i> if never set explicitly.
     **/
    Boolean getOverwriteFlag();
}

/* end-of-OptionalOverwriteSupport.java */
