/**
 * $Id: IsFile.java 851 2009-11-15 02:28:39Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  java.io.File;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.Available;
import  org.apache.tools.ant.taskdefs.condition.Condition;
import  org.apache.tools.ant.types.Path;

import  org.jwaresoftware.antxtras.core.AssertableProjectComponent;
import  org.jwaresoftware.antxtras.helpers.Strings;

/**
 * Adapter that allows &lt;available file="&#46;&#46;&#46;" type="file"/&gt;
 * to be inlined  in boolean rules as &lt;require isfile="&#46;&#46;&#46;"/&gt;.
 * Delegates to a private <span class="src">Available</span> condition.
 * <p/>
 * <b>Example Usage:</b><pre>
 *   &lt;assert message="Meta files not present"&gt;
 *     &lt;isfile location="${meta.d}/meta.emma"/&gt;
 *     &lt;isfile location="${meta.d}/meta.findbugs"/&gt;
 *   &lt;/assert&gt;
 * </pre>
 *
 * @since    JWare/AntXtras 2.0.0
 * @author   ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single (see Available)
 * @.group   impl,helper
 * @.pattern GoF.Adapter
 **/

public final class IsFile extends AssertableProjectComponent
    implements Condition, URIable
{
    /**
     * Creates new IsFile condition.
     **/
    public IsFile()
    {
        m_impl = new Available();
        Available.FileDir type = new Available.FileDir();
        type.setValue("file");
        m_impl.setType(type);
    }


    /**
     * Creates a new pre-initialized IsFile condition.
     * @param myproject owning project (non-null)
     * @param location location to be checked.
     * @see #setLocation
     **/
    public IsFile(Project myproject, String location)
    {
        this();
        setProject(myproject);
        setLocation(location);
    }


    /**
     * Sets this condition's project; updates underlying available
     * condition too.
     **/
    public void setProject(Project p)
    {
        super.setProject(p);
        m_impl.setProject(p);
    }


    /**
     * Sets the name of the file to be checked.
     * @param location location to be checked (non-null)
     **/
    public void setLocation(String location)
    {
        require_(location!=null,"setLoc- nonzro location");
        m_impl.setFile(new File(location));
    }


    /**
     * Set the filepath to be used when searching for the file.
     * @param filepath a search path (non-null)
     */
    public void setFilepath(Path filepath)
    {
        require_(filepath!=null,"setFilepath- nonzro path");
        m_impl.setFilepath(filepath);
    }



    /**
     * Sets whether the location's parents should be searched
     * (for basename items).
     * @param search <i>true</i> to search parents
     * @since JWare/AntXtras 2.0.0
     **/
    public void setParents(boolean search)
    {
        m_impl.setSearchParents(search);
    }



    /**
     * Sets property name updated by <i>true</i> evaluation.
     * @param property the property's name (non-null)
     **/
    public void setTrueProperty(String property)
    {
        require_(property!=null,"setTrueProp- nonzro name");
        m_updateProperty = property;//NB:don't use available's property
    }



    /**
     * Returns property name updated by evaluation method. Returns
     * <i>null</i> if never set or value is an exported property.
     **/
    public final String getTrueProperty()
    {
        return m_updateProperty;
    }



    /**
     * Sets this condition's location as part of a function shortcut.
     * @param fragment the function shortcut URI (non-null)
     */
    public void xsetFromURI(String fragment)
    {
        setLocation(fragment);
    }



    /**
     * Checks whether given location is a readable file or not.
     * @throws BuildException if incomplete set or unable to check condition
     **/
    public boolean eval() throws BuildException
    {
        verifyInProject_("eval");

        boolean istrue = m_impl.eval();

        if (istrue && m_updateProperty!=null) {
            log("IsFile was true; setting true-property '"+m_updateProperty+
                "' property",  Project.MSG_DEBUG);
            getProject().setNewProperty(m_updateProperty,Strings.TRUE);
        }

        return istrue;
    }


    private Available m_impl;
    private String m_updateProperty;
}

/* end-of-IsFile.java */
