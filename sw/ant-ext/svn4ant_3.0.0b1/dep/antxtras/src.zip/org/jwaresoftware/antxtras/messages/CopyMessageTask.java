/**
 * $Id: CopyMessageTask.java 766 2009-04-11 13:08:49Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/
package org.jwaresoftware.antxtras.messages;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.AntLibFriendly;
import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.Scope;
import  org.jwaresoftware.antxtras.core.FlexString;
import  org.jwaresoftware.antxtras.parameters.FlexValueSupport;
import  org.jwaresoftware.antxtras.starters.ShowTask;

/**
 * Helper task that copies a resource bundle based parameterized
 * message to an Ant fixture element like a property or variable.
 * <p>
 * <b>Example Usage</b>:<pre>
 *   &lt;copymessage messageid="msg.helloworld"
 *     property="default.greeting" arg0="${TODAY}"/&gt;
 *   &lt;copymessage messageid="defaults.copyleft"
 *     variable="copyleft"/&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2005,2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,helper
 **/

public final class CopyMessageTask extends ShowTask
    implements FlexValueSupport, AntLibFriendly
{
    /**
     * The default scope used by all CopyMessageTasks.
     **/
    public static final Scope DEFAULT_SCOPE= Scope.THREAD;



    /**
     * Initializes a new CopyMessageTask.
     **/
    public CopyMessageTask()
    {
        super(AntX.messages+"CopyMessageTask:");
    }



    /**
     * Setup this copy task to update the specified property
     * with generated message.
     * @param property name of property (non-null)
     **/
    public void setProperty(String property)
    {
        require_(property!=null, "setProperty- nonzro name");
        checkNewCopyTarget();
        m_value.set(property);
        m_value.setIsProperty(true);
    }



    /**
     * Setup this copy task to update the specified exported
     * property with generated message.
     * @param property name of exported property (non-null)
     **/
    public void setVariable(String property)
    {
        require_(property!=null, "setVar- nonzro name");
        checkNewCopyTarget();
        m_value.set(property);
        m_value.setIsVariable(true);
    }



    /**
     * Sets a variable property's scope. Defaults to the
     * <i>THREAD</i> scope if undefined.
     **/
    public void setScope(Scope scope)
    {
        require_(scope!=null,"setScope- nonzro");
        m_scope = scope;
    }



    /**
     * Returns this task's to-be-created variable's scope.
     * Never returns <i>null</i>; defaults to <i>THREAD</i>.
     **/
    public final Scope getScope()
    {
        return m_scope;
    }



    /**
     * Setup this copy task to update the specified project
     * reference with generated message.
     * @param refid name of (new) reference (non-null)
     **/
    public void setReference(String refid)
    {
        require_(refid!=null, "setReference- nonzro refid");
        checkNewCopyTarget();
        m_value.set(refid);
        m_value.setIsReference(true);
    }



    /**
     * Copies this item's generated message to its target.
     **/
    public void execute()
    {
        verifyCanExecute_("execute");

        if (executeAllowed()) {
            String what = getMsg();
            String key  = m_value.get();
            Project P   = getProject();

            if (m_value.isProperty()) {
                if (Scope.ALL.equals(getScope())) {
                    P.setInheritedProperty(key,what);
                } else {
                    P.setNewProperty(key,what);
                }
            }
            else if (m_value.isVariable())  {
                Scope.setTheValue(getScope(),P, key,what,false,
                        new Requester.ForComponent(this));
            }
            else if (m_value.isReference()) {
                P.addReference(key,what);
            }
        }
    }



    /**
     * Verifies that one of the three target holders has been
     * specified.
     * @throws BuildException if a target has not been specified
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);

        String error = null;
        if (m_value.isLiteral()) {
            error = Errs.NeedsThisAttribute(getTaskName(),
                                 "property|reference|variable");
        } else if (getMessageId()==null && getDefaultMessage().length()==0) {
            error = Errs.NeedsThisAttribute(getTaskName(),
                                 "messageid|message");
        }
        if (error!=null) {
            log(error,Project.MSG_ERR);
            throw new BuildException(error,getLocation());
        }
    }



    /**
     * Ensures that a new 'set' isn't going to overwrite a previously
     * set copy target (only one permitted).
     * @throws BuildException if a copy target has already been specified
     **/
    private void checkNewCopyTarget()
    {
        if (m_copytargets>0) {
            String error = Errs.TooManyFlexibleAttributes();
            log(error,Project.MSG_ERR);
            throw new BuildException(error,getLocation());
        }
        m_copytargets++;
    }



    private FlexString m_value  = new FlexString();
    private Scope m_scope = Scope.DEFAULT_SCOPE;
    private int m_copytargets;
}

/* end-of-CopyMessageTask.java */
