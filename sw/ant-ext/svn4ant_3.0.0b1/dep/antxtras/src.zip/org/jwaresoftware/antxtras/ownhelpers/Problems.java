/**
 * $Id: Problems.java 408 2008-04-19 20:16:08Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.ownhelpers;

import  org.apache.tools.ant.Location;
import  org.apache.tools.ant.Task;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.behaviors.ScriptLocatable;

/**
 * Administers problem handlers and other error-related fixture information. Usually
 * a default fixture problem handler is installed by an early initialization build
 * target. Local (scoped) problem handlers are not addressed because the application
 * can install scoped handlers via the AntX <span class="src">&lt;protect&gt;</span>
 * flowcontrol taskset.
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2002-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  guarded
 * @.group   impl,infra
 * @see      org.jwaresoftware.antxtras.behaviors.Responses
 **/

public class Problems
{
    /**
     * Returns the location of a helper component or its client if
     * helper has no location. Never returns <i>null</i>.
     * @param calr requester (non-null)
     * @param impl helper's location if known
     * @since JWare/AntX 0.5
     **/
    public static final Location getHelperLocation(Task impl, Requester calr)
    {
        Location l = impl.getLocation();
        if (l==Location.UNKNOWN_LOCATION) {
            l = calr.getLocation();
        }
        return l==null ? Location.UNKNOWN_LOCATION : l;
    }



    /**
     * Returns the location of a calling client or the service if
     * client is anonymous. Never returns <i>null</i>.
     * @param impl the helper (non-null)
     * @param calr the client (non-null)
     * @since JWare/AntX 0.5
     **/
    public static final Location getCallerLocation(Requester calr, ScriptLocatable impl)
    {
        Location l = calr.getLocation();
        if (l==Location.UNKNOWN_LOCATION) {
            l = impl.getLocation();
        }
        return l==null ? Location.UNKNOWN_LOCATION : l;
    }

    

    /** Disallow; only public static utility methods. **/
    private Problems()
    { }
}

/* end-of-Problems.java */
