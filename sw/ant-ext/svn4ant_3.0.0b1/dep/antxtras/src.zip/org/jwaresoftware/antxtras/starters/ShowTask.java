/**
 * $Id: ShowTask.java 800 2009-08-08 13:42:20Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.starters;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.DynamicAttribute;
import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Errs;
import  org.jwaresoftware.antxtras.core.MsgGetter;
import  org.jwaresoftware.antxtras.core.NoiseLevel;
import  org.jwaresoftware.antxtras.go.Iff;
import  org.jwaresoftware.antxtras.go.Unless;
import  org.jwaresoftware.antxtras.helpers.InnerString;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.Conditional;

/**
 * Simple task that displays <i>messageid</i>-based messages. By default behaves
 * like the standard Ant '<i>echo</i>' task only using property-based resource 
 * bundles. If undefined, the message noise-level is whatever the AntXtras's
 * runtime default is defined to be.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;<b>show</b> messageid="msg.helloworld"/&gt;
 *   &lt;<b>show</b> messageid="msg.byeworld" level="verbose"/&gt;
 *   &lt;<b>show</b> messageid="msg.youarehere" arg2="Compiling" level="debug"/&gt;
 *   &lt;<b>show</b> messageid="err.no.jdk15" unless="jdk15.present"&gt;
 *      &lt;defaultmessage&gt;Need J2SE 1.5 or later&lt;/defaultmessage&gt;
 *   &lt;/show&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,helper
 **/

public class ShowTask extends AssertableTask implements Conditional, DynamicAttribute
{
    /**
     * Initializes a new task instance.
     **/
    public ShowTask()
    {
        super(AntX.starters+"ShowTask:");
    }


    /**
     * Initializes a new task subclass instance.
     * @param iam CV-label (non-null)
     **/
    public ShowTask(String iam)
    {
        super(iam);
    }


    /**
     * Initializes a new task subclass instance with a predefined
     * default message.
     * @param iam CV-label (non-null)
     * @param defaultMsg default message (non-null)
     **/
    public ShowTask(String iam, String defaultMsg)
    {
        super(iam);
        require_(defaultMsg!=null,"ctor- nonzro dfltMsg");
        m_defaultMessage = defaultMsg;
    }



    /**
     * Adds an if-condition to this echo task.
     * @since JWare/AntX 0.2
     **/
    public void setIf(String property)
    {
        m_ifProperty = (property==null) ? "" : property;
    }


    /**
     * Returns this task's (raw) if-condition if any. Returns
     * empty string if condition never set.
     * @since JWare/AntX 0.2
     **/
    public String getIfProperty()
    {
        return m_ifProperty;
    }



    /**
     * Adds an unless-condition to this echo task.
     * @since JWare/AntX 0.2
     **/
    public void setUnless(String property)
    {
        m_unlessProperty = (property==null) ? "" : property;
    }


    /**
     * Returns this task's (raw) unless-condition if any. Returns
     * empty string if condition never set.
     * @since JWare/AntX 0.2
     **/
    public String getUnlessProperty()
    {
        return m_unlessProperty;
    }



    /**
     * Sets this task's preferred message noise level.
     * @param level new level (non-null)
     * @see #getPreferredNoiseLevel getPreferredNoiseLevel()
     **/
    public void setLevel(NoiseLevel level)
    {
        require_(level!=null,"setLvl- nonzro lvl");
        m_preferredNoiseLevel = level;
    }


    /**
     * Returns this task's preferred message noise level. Returns
     * <i>null</i> if never set. For the message level used when
     * showing message, see {@linkplain #getNoiseLevel getNoiseLevel()}.
     **/
    public final NoiseLevel getPreferredNoiseLevel()
    {
        return m_preferredNoiseLevel;
    }


    /**
     * Returns this task's <em>effective</em> message noise level. If
     * this task's preferred msg level never set, this method returns
     * the default message level set at either the project, system, or
     * AntX-defaults levels. Never returns <i>null</i>.
     * @see AssertableTask#getDefaultNoiseLevel
     **/
    public final NoiseLevel getNoiseLevel()
    {
        NoiseLevel nl= getPreferredNoiseLevel();
        if (nl==null) {
            nl= getDefaultNoiseLevel();
        }
        return nl;
    }



    /**
     * <em>Replaces</em> the default message string associated with
     * this task. Usually only specified if it is acceptable for 
     * resource bundles to be missing at build-time.
     * @see #getDefaultMessage
     **/
    public void addConfiguredDefaultMessage(InnerString defaultMsgStr)
    {
        require_(defaultMsgStr!=null,"addDfltMsg- nonzro str");
        m_defaultMessage= defaultMsgStr.toString(getProject());
    }


    /**
     * Returns this task's default message string if any. Never
     * returns <i>null</i> but will return the empty string if this
     * element never defined.
     **/
    public final String getDefaultMessage()
    {
        return m_defaultMessage;
    }



    /**
     * Sets the inlined string message emitted by this task. 
     * Same as nesting a default message.
     * @param string the message (non-null)
     **/
    public void setMessage(String string)
    {
        require_(string!=null,"setMsg- nonzro string");
        addConfiguredDefaultMessage(new InnerString(string));
    }



    /**
     * Adds an arbitrary message argument for use with final message.
     * Argument parameters must begin with 'arg' and end with the zero-based
     * index for the message template; for example 'arg0' for template
     * item '{0}'.
     * @param name condition name (no namespace)
     * @param value parameter's actual value (non-null)
     * @since JWare/AntXtras 2.0.0
     * @throws BuildException if attribute's name is not a recognized
     *         message argument
     **/
    public void setDynamicAttribute(final String name, String value)
    {
        require_(name!=null, "setArgX- nonzro arg name");
        require_(value!=null,"setArgX- nonzro arg valu");

        String lname = Tk.lowercaseFrom(name.trim());
        if (!setDynamicMessageArgs(lname,value)) {
            String err = getAntXMsg(Errs.TUA,getTaskName(),name);
            log(err,Project.MSG_ERR);
            throw new BuildException(err,getLocation());
        }
    }



    /**
     * Work method for extracting dynamic message arguments. If
     * parameter not recognized as a message template argument (begins
     * with 'arg' and ends with an index 0-9), returns <i>false</i>.
     * @param lname normalized parameter name (non-null)
     * @param value parameter value (non-null)
     * @return true if accepted as a message template argument.
     **/
    protected final boolean setDynamicMessageArgs(final String lname, String value)
    {
        boolean ok = false;
        if (lname.length()>=4 && lname.startsWith("arg")) {
            String indexstring = lname.substring(3);
            int index = Tk.integerFrom(indexstring,-1);
            if (index>=0 && index<10) {
                ok = true;
                if (m_args==null) {
                    m_args = new String[10];
                    for (int i=0;i<m_args.length;i++) { m_args[i]= ""; }
                    super.getUISMArgs(m_args);
                }
                m_args[index] = value;
            }
        }
        return ok;
    }



    /**
     * Returns this task's dynamically defined message template arguments.
     * Can return <i>null</i> if no arguments defined.
     * @since JWare/AntXtras 2.0.0
     **/
    protected final String[] getDynamicMessageArgs()
    {
        return m_args;
    }



    /**
     * Extension of inherited '<i>getMsg</i>' that will return this
     * task's default message string if its messageid is undefined.
     **/
    public String getMsg()
    {
        String  msg = null;

        if (m_args!=null) {
            msg = getMsg(new MsgGetter() {
                public String get(final String msgId) {
                    return getUISM().mget(msgId,m_args);
                }
            });
        } else {
            msg = super.getMsg();
        }

        String dfltMsg = getDefaultMessage();
        if (Tk.isWhitespace(msg)) {
            msg = dfltMsg;
        } else if (msg.equals(getMessageId()) && !Tk.isWhitespace(dfltMsg)) {
            msg = dfltMsg;
        }

        return msg;
    }



    /**
     * Tests whether or not this task's "if" condition resolves
     * to a an existing property.
     * @return <i>true</i>if the "if" property is defined
     * @since JWare/AntX 0.2
     **/
    protected final boolean testIfCondition()
    {
        return Iff.allowed(getIfProperty(), getProject());
    }


    /**
     * Tests whether or not this task's "unless" condition resolves
     * to an existing property.
     * @return <i>true</i> if the "unless" property is not defined
     * @since JWare/AntX 0.2
     **/
    protected final boolean testUnlessCondition()
    {
        return Unless.allowed(getUnlessProperty(),getProject());
    }


    /**
     * Work like the default '<i>echo</i>' Ant task except 
     * using UIStringManager underneath if can.
     * @see #executeAllowed() guard condition
     **/
    public void execute()
    {
        verifyCanExecute_("execute");

        if (executeAllowed()) {
            log(getMsg(), getNoiseLevel().getNativeIndex());
        }
    }


    /**
     * Returns <i>true</i> if this task's make function can go
     * ahead. By default just checks the 'if' and 'unless' 
     * conditions, subclasses can additional checks. Call after
     * verified execution parameters.
     * @since JWare/AntXtras 2.0.0
     **/
    protected boolean executeAllowed()
    {
        return testIfCondition() && testUnlessCondition();
    }


    private NoiseLevel m_preferredNoiseLevel;
    private String m_defaultMessage="";
    String[] m_args;//NB: lazy-inited to 10 long on first use
    private String m_ifProperty="";
    private String m_unlessProperty="";
}


/* end-of-ShowTask.java */
