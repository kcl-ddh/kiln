/**
 * $Id: PropertyFactoryMethod.java 965 2010-01-18 13:57:38Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.behaviors;

import  java.util.Iterator;
import  java.util.List;
import  java.util.Map;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.internal.fixture.SystemFixture;

/**
 * Mixin interface for any object that can produce a property value.
 *
 * @since     JWare/AntXtras 2.0.0
 * @author    ssmc, &copy;2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    impl,helper
 **/

public interface PropertyFactoryMethod
{
    /**
     * Given a property name (non-null,non-whitespace), returns
     * the matching value or <i>null</i> if no value.
     * @param propertyname name of property (non-null)
     * @return value
     **/
    String getProperty(String propertyname);


    /**
     * Default implementation of a property factory method that
     * returns a constant value for <em>every</em> queried property
     * unconditionally. Meant for use during a pre-flight or test
     * for references in a string <em>without</em> doing actual
     * lookups.
     * @since    JWare/AntXtras 3.0.0
     * @author   ssmc, &copy;2010 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  multiple
     * @.group   impl,helper
     */
    public static final class ForConstant implements PropertyFactoryMethod {
        private final String m_matchValue;
        public ForConstant(String matchValue) {
            m_matchValue = matchValue;
        }
        public String getProperty(String propertyname) {
            return m_matchValue;
        }
    }



    /**
     * Default implementation of a property factory method that
     * reads property from a standard Ant project.
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  guarded (underlying Project)
     * @.group   impl,helper
     */
    public static final class FromProject implements PropertyFactoryMethod {
        private final Project m_project;
        public FromProject(Project p) {
            m_project = p;
        }
        public String getProperty(String propertyname) {
            return m_project.getProperty(propertyname);
        }
    }



    /**
     * Default implementation of a property factory method that
     * reads property from a snapshot of an Ant project's property set.
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  guarded (underlying Properties)
     * @.group   impl,helper
     */
    public static final class FromExaminer implements PropertyFactoryMethod {
        private final Map m_values;
        public FromExaminer(Project p) {
            m_values = p.getProperties();
        }
        public String getProperty(String propertyname) {
            Object o = m_values.get(propertyname);
            return (o==null) ? null : Tk.stringFrom(o, null);
        }
    }



    /**
     * Default implementation of a property factory method that
     * reads property from a standard Java Map object.
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  guarded (underlying Properties)
     * @.group   impl,helper
     */
    public static final class FromMap implements PropertyFactoryMethod {
        private final Map m_values;
        public FromMap(Map m) {
            m_values = m;
        }
        public String getProperty(String propertyname) {
            Object o = m_values.get(propertyname);
            return (o==null) ? null : Tk.stringFrom(o, null);
        }
    }



    /**
     * Default implementation of a property factory method that
     * delegates request to a series of other factory methods (in order).
     * @since    JWare/AntXtras 2.0.0
     * @author   ssmc, &copy;2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class FromChainOfMethods implements PropertyFactoryMethod {
        private final List m_chain = SystemFixture.newList(4);
        public FromChainOfMethods() {
        }
        public void addFactoryMethod(PropertyFactoryMethod next) {
            if (next==null) { 
                throw new IllegalArgumentException("Non-null method required");
            }
            m_chain.add(next);
        }
        public String getProperty(String propertyname) {
            String value = null;
            for (Iterator itr=m_chain.iterator();itr.hasNext();) {
                PropertyFactoryMethod next = (PropertyFactoryMethod)itr.next();
                value = next.getProperty(propertyname);
                if (value!=null) {
                    break;
                }
            }
            return value;
        }
    }
}

/* end-of-PropertyFactoryMethod.java */
