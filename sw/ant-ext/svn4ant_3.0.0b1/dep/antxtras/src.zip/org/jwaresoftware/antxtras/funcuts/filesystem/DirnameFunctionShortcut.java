/**
 * $Id: DirnameFunctionShortcut.java 936 2010-01-02 14:01:17Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.filesystem;

import  java.io.File;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that is an inline version of the standard Ant 
 * &lt;dirname&gt; task. The general format of the URI is:
 * <span class="src">$dirname:path</span>. The path will be 
 * resolved relative to the URI's owning project if necessary and 
 * like the &lt;dirname&gt; task and empty path string is 
 * interpreted as the project's base directory.
 * <p>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;parameter name="root" 
 *      value="${<b>$dirname:</b>${etc.d}}"/&gt;
 *
 * <b>2)</b> -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="dirname"
 *             value="${ojaf}.filesystem.DirnameFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntXtras 2.1.0
 * @author    ssmc, &copy;2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class DirnameFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new dirname shortcut handler.
     **/
    public DirnameFunctionShortcut()
    {
        super();
    }


    /**
     * Extracts the directory name from a passed in filesystem path.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        final Project P = clnt.getProject();
        String path = Tk.resolveString(P,uriFragment,true);
        return dirFrom(path,clnt);
    }



    /**
     * Extracts the parent directory name of given filesystem path.
     * @param inpath path as passed in uri fragment
     * @param clnt call controls (non-null)
     * @return directory name (never <i>null</i>)
     **/
    private String dirFrom(String inpath, Requester clnt)
    {
        File file;
        if (inpath.length()==0) {
            file = clnt.getProject().getBaseDir();
            if (file==null) {
                return null;
            }
        } else {
            file = clnt.getProject().resolveFile(inpath);
        }
        String dirpath = file.getParent();
        return dirpath!=null ? dirpath : file.getPath();
    }
}

/* end-of-DirnameFunctionShortcut.java */