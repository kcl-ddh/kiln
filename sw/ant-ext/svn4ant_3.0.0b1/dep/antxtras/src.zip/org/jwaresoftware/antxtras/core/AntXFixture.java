/**
 * $Id: AntXFixture.java 535 2008-12-17 17:09:12Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  java.util.Iterator;
import  java.util.List;
import  java.util.Map;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.util.FileUtils;

import  org.jwaresoftware.antxtras.behaviors.BuildError;
import  org.jwaresoftware.antxtras.behaviors.ProblemHandler;
import  org.jwaresoftware.internal.fixture.SystemFixture;

/**
 * The AntXtras global fixture. The AntXFixture serves as a factory for standard
 * Java and Ant data types as well as a controller that resets (or re-creates)
 * various core AntXtras fixture components in between execution iterations. Every
 * administrator of fixture data must define a iteration-bound clean-up method
 * by supplying a {@linkplain KillMethod} callback.
 * <p/>
 * The AntXFixture differs from the {@linkplain Iteration} in that it is global,
 * always exists, and is <em>independent</em> of any particular execution iteration.
 * For instance, kill methods are registered at the class level, not the iteration
 * level. Multiple iterations will use the same kill method to reset certain
 * components.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004-2005,2007-2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  guarded
 * @.group   impl,infra
 * @.pattern GoF.Facade
 * @see      Iteration
 **/

public final class AntXFixture extends SystemFixture implements FixtureCore
{
    private static final String IAM_= "AntX.Fixture:";



    /**
     * Returns a shareable <span class="src">FileUtils</span>
     * helper instance.
     * @since JWare/AntX 0.4
     **/
    public static FileUtils fileUtils()
    {
        return FileUtils.getFileUtils();
    }



    /**
     * Returns the kill method associated with target. Will return
     * <i>null</i> if nothing registered for target.
     **/
    static KillMethod getKillMethod(String target)
    {
        return (KillMethod)m_killMethods.get(target);
    }



    /**
     * Defines the fixture cleanup method for a specific administrator.
     * This method is used by the fixture component class when it is loaded.
     * @param component fixture administrator or component (non-null)
     * @param method cleanup method (non-null)
     * @throws BuildError if component already installed
     **/
    public static void setKillMethod(String component, KillMethod method)
    {
        AntX.require_(component!=null,IAM_,"setKillMeth- nonzro id");
        AntX.require_(method!=null,IAM_,"setKillMeth- nonzro method");

        KillMethod method0 = getKillMethod(component);
        if (method0!=null) {
            throw new BuildError
                (AntX.uistrs().get("fixture.cleanup.instald",component));
        }

        m_killMethods.put(component,method);
        m_FXIDs.add(component);
    }



    /**
     * Resets a particular aspect of a fixture component. If there is
     * no cleanup for the component registered, this method will return
     * <i>true</i>.
     * @param component fixture component to be reset (non-null)
     * @param aspect aspect to be reset
     * @param from controlling task or test (non-null)
     * @return <i>false</i> if there was a problem with the cleanup
     **/
    public static boolean reset(String component, String aspect,
                                ProblemHandler from)
    {
        AntX.require_(from!=null,IAM_,"reset- nonzro source");
        AntX.require_(component!=null,IAM_,"reset- nonzro id");

        KillMethod method0 = getKillMethod(component);
        if (method0!=null) {
            boolean ok = method0.kill(aspect, from);
            if (!ok) {
                String warning = AntX.uistrs().get
                    ("fixture.errs.killin.comp.aspect", component,aspect);
                from.problem(warning, Project.MSG_WARN);
            }
            return ok;
        }
        return true;
    }



    /**
     * Resets <em>all</em> fixture components. Your application should
     * never use this method directly unless it is part of a execution
     * harness system. Call this method before resetting the iteration
     * to a new instance.
     * @param from controlling task or test (non-null)
     **/
    public static void reset(ProblemHandler from)
    {
        AntX.require_(from!=null,IAM_,"reset- nonzro source");

        List l= SystemFixture.newListCopy(m_FXIDs);

        Iterator itr= l.iterator();
        while (itr.hasNext()) {
            String component = itr.next().toString();
            KillMethod method = getKillMethod(component);
            if (!method.kill(from)) {
                String warning = AntX.uistrs().get
                    ("fixture.errs.killin.comp", component);
                from.problem(warning, Project.MSG_WARN);
            }
        }

        l=null;
    }


    /**
     * Permits tests to clear out specific test kill methods to ensure
     * we don't corrup entire harness for other tests.
     * @param component fixture component to remove (non-null)
     * @since JWare/AntXtras 2.0.0
     **/
    static final void clearKillMethod(String component) 
    {
        AntX.require_(component!=null,IAM_,"clrKillMeth- nonzro id");
        m_killMethods.remove(component);
        m_FXIDs.remove(component);
    }



    /**
     * Disallow; only public static utility methods.
     **/
    private AntXFixture()
    {
    }


    private static final List m_FXIDs= SystemFixture.newSynchronizedList();
    private static final Map m_killMethods= SystemFixture.newSynchronizedMap();
}

/* end-of-AntXFixture.java */
