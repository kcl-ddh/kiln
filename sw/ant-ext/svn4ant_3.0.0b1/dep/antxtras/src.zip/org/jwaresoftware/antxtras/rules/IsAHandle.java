/**
 * $Id: IsAHandle.java 418 2008-04-26 18:25:00Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.jwaresoftware.antxtras.parameters.IsA;

/**
 * Little struct that tracks a dangling "isa" parameter.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,helper
 * @see      ShortHandHelper
 * @.pattern JWare.Luggage
 **/

final class IsAHandle
{
    IsAHandle()
    {
    }

    IsAHandle(IsA value)
    {
        set(value);
    }

    IsA get()
    {
        return m_value;
    }


    void set(IsA value)
    {
        m_value= value;
    }

    private IsA m_value= IsA.LITERAL;
}

/* end-of-IsAHandle.java */
