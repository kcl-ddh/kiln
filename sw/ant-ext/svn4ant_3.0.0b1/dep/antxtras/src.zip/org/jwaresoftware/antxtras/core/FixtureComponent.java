/**
 * $Id: FixtureComponent.java 1034 2010-03-20 15:05:26Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

/**
 * Marker interface for a data element that can be included in an execution
 * cycle's fixture definition through application-supplied instructions like
 * a build or test script.
 * <p/>
 * Fixture components are fundamentally different from {@linkplain FixtureCore}
 * elements because they are created in response to an application request only;
 * if the application doesn't want them, they are not included in the iteration's
 * fixture. FixtureCore items are not data elements usually and exist as long 
 * as the execution cycle does.
 * <p/>
 * The term fixture component can include anything from data objects to task
 * instances to fixture administrators. When included, fixture components and
 * their particular states help make one particular execution cycle unique 
 * from another.
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 * @see      FixtureAdministrator
 * @see      FixtureCore
 **/

public interface FixtureComponent
{
}

/* end-of-FixtureComponent.java */
