/**
 * $Id: FunctionShortcut.java 963 2010-01-16 15:18:09Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.core;

import  org.jwaresoftware.antxtras.behaviors.Requester;

/**
 * Interface for an AntXtras function shortcut (or set of shortcuts). 
 * You must explicitly install most shortcuts including those built into 
 * AntXtras; see
 * {@linkplain org.jwaresoftware.antxtras.funcuts.ManageFuncutsTask} 
 * for more information.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004,2008-2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    api,infra
 **/

public interface FunctionShortcut
{
    /** The delimiter that separates scheme from rest of URI. **/
    public final static String SCHEME_DELIMITER= "?";

    /** Length of {@linkplain #SCHEME_DELIMITER}. **/
    public final static int SCHEME_DELIMITER_LEN = SCHEME_DELIMITER.length();


    /** The delimiter that separates URI query parameters. **/
    public final static String PARAMS_DELIMITER= ",,";

    /** Length of {@linkplain #PARAMS_DELIMITER}. **/
    public final static int PARAMS_DELIMITER_LEN = PARAMS_DELIMITER.length();


    /**
     * Returns this shortcuts's default value when incoming script
     * identifier does not match any fixture data or identifier is
     * malformed.
     * @param fullUri [optional] the script-facing shortcut URI
     * @param clnt caller location and problem handler (non-null)
     * @return default value for this type of funcut or <i>null</i>
     **/
    String getDefaultValue(String fullUri, Requester clnt);



    /**
     * Returns the current value represented by this function shortcut.
     * @param uriFragment resource information from URI (non-null)
     * @param fullUri full script-facing shortcut URI (non-null)
     * @param clnt caller location and problem handler (non-null)
     * @return stringified from of resource identified by URI
     **/
    String valueFrom(String uriFragment, String fullUri, Requester clnt);



    /**
     * Null proxy class used by function shortcut factories. Instances
     * of this class never resolve any supplied URI (always returns <i>null</i>).
     * @since     JWare/AntX 0.5
     * @author    ssmc, &copy;2004,2009 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version   3.0.0b1
     * @.safety   multiple
     * @.group    impl,helper
     **/
    public static final class None implements FunctionShortcut
    {
        /** Initialize a new no-op proxy instance. **/
        public None() {
        }
        /** Returns <i>null</i> always. **/
        public String getDefaultValue(String fullURI, Requester clnt) {
            return null;
        }
        /** Returns <i>null</i> always. **/
        public String valueFrom(String fragment, String full, Requester clnt) {
            return null;
        }
    }
}

/* end-of-FunctionShortcut.java */