/**
 * $Id: TempLocator.java 951 2010-01-06 02:53:37Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.filesystem;

import  java.io.File;

import  org.apache.tools.ant.util.FileUtils;

/**
 * Helper that locates suitable scratch or temporary directories into which
 * scratch files can be safely dumped. Helper for other filesystem classes.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2007-2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  guarded
 * @.group   impl,helper
 **/

public final class TempLocator
{
    /**
     * Tries to determine the OS-specific temporary directory. Not as nice
     * as the JWare TempLocator but fixed to work with Ant's own tempfile
     * factory as a fallback.
     **/
    static final File TMPDIR;
    static {
        File f=null;
        try {
            f = File.createTempFile("qat",null);
            f.deleteOnExit();
            f = f.getParentFile();
            f = f.getCanonicalFile();
        } catch(Exception anyX) {//hmm...this is bad...ok...make Ant do it...
            FileUtils fu= FileUtils.getFileUtils();
            f = fu.createTempFile("qat",".tmp",null,false,false);
            try {
                f = f.getParentFile().getCanonicalFile();
            } catch (Exception ioX) {
                f = new File("_will_die_on_first_use");
            }
        }
        TMPDIR= f;
    }

    /**
     * Returns the OS-specific temp directory. Never returns <i>null</i>.
     **/
    public final static File getSystemTempDir()
    {
        return TMPDIR;//?expose
    }
}

/* end-of-TempLocator.java */
