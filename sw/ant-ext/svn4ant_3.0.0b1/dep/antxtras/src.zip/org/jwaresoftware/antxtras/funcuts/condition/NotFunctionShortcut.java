/**
 * $Id: NotFunctionShortcut.java 757 2009-04-04 19:58:49Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.condition;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.FlexString;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.antxtras.parameters.IsA;
import  org.jwaresoftware.antxtras.starters.FunctionShortcutSkeleton;

/**
 * Function shortcut that returns the logical not of the incoming source 
 * value. Allows properties, variables, and reference values (lenient 
 * stringifier used) using a single '?' modifier that identifies an "is-a"
 * type. By default assumes a literal value to be interpreted. Returned
 * result is normalized to either the "<span class="src">true</span>"
 * or the "<span class="src">false</span>" string for easy matching.
 * <p/>
 * <b>Example Usage:</b><pre>
 * <b>1)</b> &lt;do true="${<b>$not:</b>${scrub&#46;disabled}}"&gt;&#8230;
 * <b>2)</b> &lt;property name="smoke.enabled" value="${<b>$not:</b>fullregress.enabled?p}"/&gt;
 * <b>3)</b> &lt;do true="${$iszero:${i}|<b>$not:</b>}"&gt;&#8230;
 *
 * <b>4)</b> -- To Install and Enable --
 *    &lt;managefuncuts action="install"&gt;
 *       &lt;parameter name="not"
 *             value="${ojaf}.condition.NotFunctionShortcut"/&gt;
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    api,helper
 **/

public final class NotFunctionShortcut extends FunctionShortcutSkeleton
{
    /**
     * Initializes a new not function shortcut.
     **/
    public NotFunctionShortcut()
    {
        super();
    }


    /**
     * Returns the logical not of the source boolean value. If the source
     * is not a valid boolean, returns <i>null</i>.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        FlexString source = new FlexString();
        source.set(uriFragment);

        IsA isa= IsA.LITERAL;
        int i = uriFragment.lastIndexOf("?");
        if (i>0) {
            source.set(uriFragment.substring(0,i++));
            if (i<uriFragment.length()) {
                String isaName = uriFragment.substring(i);
                isa = IsA.from(isaName,isa);
           }
        }

        source.set(Tk.resolveString(clnt.getProject(),source.get(),true));

        switch (isa.getIndex()) {
            case IsA.VARIABLE_INDEX: {
                source.setIsVariable(true);
                break;
            }
            case IsA.REFERENCE_INDEX:{
                source.setIsReference(true);
                break;
            }
            case IsA.PROPERTY_INDEX: {
                source.setIsProperty(true);
                break;
            }
            default: {
                source.setIsLiteral();
            }
        }

        String value = source.getValue(clnt.getProject());
        if (value!=null) {
            Boolean interpreted= Tk.string2PosBool(value);
            if (interpreted!=null) {//null=>whitespace(SSMC)
                if (interpreted.booleanValue()) {
                    return Strings.FALSE;
                }
                interpreted = Tk.string2NegBool(value);
                if (!interpreted.booleanValue()) {
                    return Strings.TRUE;
                }
            }
        }

        return getDefaultValue(fullUri,clnt);
    }
}

/* end-of-NotFunctionShortcut.java */