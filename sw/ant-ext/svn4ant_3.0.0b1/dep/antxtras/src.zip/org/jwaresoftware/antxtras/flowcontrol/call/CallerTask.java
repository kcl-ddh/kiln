/**
 * $Id: CallerTask.java 610 2009-02-15 00:21:26Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.call;

import  java.util.Iterator;
import  java.util.List;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.Task;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AssertableTask;
import  org.jwaresoftware.antxtras.core.Variables;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.ownhelpers.TaskExaminer;
import  org.jwaresoftware.antxtras.parameters.RecoveryEnabled;

/**
 * Superclass of any task that can run either a set of nested tasks or a set
 * of top level targets . Whether the targets are run from an isolated
 * sub-project is subclass dependent. For simplicity in our documentation we
 * refer to both top-level targets and nested tasks as "targets". The
 * CallerTask class implements basic support for the following common behavior:<ul>
 *   <li>Target verification (ensure top-level targets or macros actually exist).</li>
 *   <li>The default fixture passthru options (like 'inheritRefs', and 'inheritAll').</li>
 *   <li>Implementation for basic property-based overlay instructions.</li>
 *   <li>The standard execution of named targets in order. The support is based on
 *       the {@linkplain TargetCaller} interface. Whether targets are nested or
 *       top-level is subclass defined.</li>
 *   <li>Problem handling when a called target generates an error. This support
 *       is based on the 'haltiferror' and 'tryeach' options. </li>
 * </ul>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,infra
 * @see      TargetCaller
 **/

public abstract class CallerTask extends AssertableTask
    implements RecoveryEnabled
{
    /**
     * Initializes a new caller task instance.
     **/
    protected CallerTask()
    {
        super(AntX.flowcontrol+"CallerTask:");
    }



    /**
     * Iniitializes a new, custom caller task instance.
     * @param iam CV-label
     **/
    protected CallerTask(String iam)
    {
        super(iam);
    }


    /**
     * Optionally delays configuration of nested tasks until they're
     * executed (like standard '<i>sequential</i>' task).
     * @see TaskExaminer#ignoreConfigure TaskExaminer.ignoreConfigure(&#8230;)
     * @since JWare/AntX 0.4
     **/
    public void maybeConfigure()
        throws BuildException
    {
        if (!TaskExaminer.ignoreConfigure(this)) {//@since AntX0.4+Ant1.6
            super.maybeConfigure();
        }
    }


// ---------------------------------------------------------------------------------------
// Script-facing Parameters:
// ---------------------------------------------------------------------------------------

    /**
     * Sets name of a property to update in event any target fails.
     * @param property the property's name (non-null)
     **/
    public void setFailProperty(String property)
    {
        require_(property!=null,"setFailProperty- nonzro name");
        m_failProperty = property;
    }


    /**
     * Returns name of a property to update in event any caller
     * fails. Returns <i>null</i> if never set.  This property is set
     * irregardless of this task's "haltiferror" setting.
     **/
    public final String getFailProperty()
    {
        return m_failProperty;
    }


    /**
     * Sets the name of a variable to update in event any
     * target caller fails.
     * @see #setFailValue
     * @since JWare/AntX 0.3
     **/
    public void setFailVariable(String variable)
    {
        require_(variable!=null,"setFailVariable- nonzro name");
        m_failVariable = variable;
    }



    /**
     * Returns name of the variable to update in event
     * any target caller fails. Returns <i>null</i> if never set.
     * @since JWare/AntX 0.3
     **/
    public final String getFailVariable()
    {
        return m_failVariable;
    }


    /**
     * Sets value used for {@linkplain #setFailProperty failproperty}
     * and/or {@linkplain #setFailVariable failvariable}
     * in event of failure.
     * @param value the value to be used (non-null)
     **/
    public void setFailValue(String value)
    {
        require_(value!=null,"setFailValu- nonzro valu");
        m_failValue = value;
    }


    /**
     * Returns value used for {@linkplain #setFailProperty failproperty}
     * and/or {@linkplain #setFailVariable failvariable}
     * in event of failure. Defaults to the string "true".
     **/
    public final String getFailValue()
    {
        return m_failValue;
    }



    /**
     * Sets whether this task will continue to unwind the call
     * stack and eventually fail with a top-level build exception.
     * Defaults to <i>true</i>.
     **/
    public void setHaltIfError(boolean balk)
    {
        m_haltIfError = balk;
    }


    /**
     * Returns <i>true</i> if this task will propagate any
     * build exceptions unconditionally. Defaults to <i>true</i>.
     **/
    public final boolean isHaltIfError()
    {
        return m_haltIfError;
    }


    /**
     * Sets whether this task will ignore any target failures
     * and continue executing subsequent targets.
     **/
    public void setTryEach(boolean tryEach)
    {
        m_tryEach = tryEach;
    }


    /**
     * Returns whether this task will ignore any target failures
     * and continue executing subsequent targets. Defaults to
     * <i>false</i>.
     **/
    public final boolean isTryEach()
    {
        return m_tryEach;
    }


//  ---------------------------------------------------------------------------------------
//  Execution:
//  ---------------------------------------------------------------------------------------


    /**
     * Returns this task's overlay instructions tracker. Never returns
     * <i>null</i>. Must be called after this task initialized.
     * @since JWare/AntX 0.4
     **/
    protected OverlayParametersHelper getParametersKeeper()
    {
        if (m_paramsHelper==null) {
            m_paramsHelper= new OverlayParametersHelper(getProject());
        }
        return m_paramsHelper;
    }



    /**
     * Returns <i>true</i> if this task has been assigned
     * specific overlay instructions.
     * @since JWare/AntX 0.4
     **/
    protected final boolean haveOverlayParameters()
    {
        if (m_paramsHelper==null) {
            return false;
        }
        return !m_paramsHelper.getParameters().isEmpty();
    }



    /**
     * Copies this task's fixture configuration instructions to the
     * target caller's environment.
     * @since JWare/AntX 0.4
     **/
    protected final void transferOverlayParameters(TargetCaller caller)
    {
        if (m_paramsHelper!=null) {
            m_paramsHelper.transferParameters(caller);
        }
    }



    /**
     * Factory-method that returns an ordered, filtered list of
     * configured target callers. Subclasses must provide. Never
     * returns <i>null</i> but can return an empty list. Caller
     * assumes ownership of the returned list.
     * @throws BuildException if unable to determine targets.
     **/
    protected abstract List copyOfOrderedTargetCallers()
        throws BuildException;



    /**
     * Template-method that executes this caller's targets in natural order.
     * @param selector [optional] callback to select which run method to use
     * @see #copyOfOrderedTargetCallers
     * @throws BuildException if unable to determine targets or any target
     *         does and "haltiferror" is <i>false</i>
     **/
    protected void runTargetCallers(TargetCaller.RunSelector selector)
        throws BuildException
    {
        List callers = copyOfOrderedTargetCallers();
        verify_(callers!=null,"runcalrs- nonzro calrs to run");

        if (!callers.isEmpty()) {
            Iterator itr= callers.listIterator();
            boolean started=false;
            TargetCaller caller=null;

            while (itr.hasNext()) {
                caller = (TargetCaller)itr.next();
                try {

                    callerStarted(caller);
                    started=true;
                    log("Caller for '"+callerName(caller)+
                        "' about to run.",Project.MSG_DEBUG);

                    if (selector!=null) {
                        selector.run(caller);
                    } else {
                        caller.run();
                    }

                    started=false;
                    callerFinished(caller,null);

                } catch(RuntimeException rtX) {
                    callerFailed(caller, rtX, callers);
                    if (started) {
                        callerFinished(caller,rtX);
                    }
                    if (isHaltIfError()) {
                        throw rtX;
                    } else if (!isTryEach()) {
                        break;
                    }
                }
            }//foreach

            callers.clear();

        }//!=0
    }



    /**
     * Generates a series of (possibly partitioned) calls to either
     * a set of top-level targets or a set of nested steps. By default
     * just calls {@linkplain #runTargetCallers runTargetCallers}.
     * @throws BuildException if any caller does.
     **/
    public void execute() throws BuildException
    {
        verifyCanExecute_("execute");
        runTargetCallers(null);
    }



    /**
     * Called before a target caller is executed. By default
     * does nothing.
     * @param caller the verified (about-to-be)started caller (non-null)
     **/
    protected void callerStarted(TargetCaller caller)
    {
        //do-nothing
    }



    /**
     * Called after a target caller returns (successfully or
     * not). By default does nothing. Note: if caller failed this
     * method is called <em>after</em> the callerFailed method.
     * @param caller the finished caller (non-null)
     * @param cause [optional] if non-null caller aborted with this
     **/
    protected void callerFinished(TargetCaller caller, Throwable cause)
    {
        //do-nothing
    }



    /**
     * Called if this caller catches a runtime exception while
     * executing a sequence of target callers. By default logs an
     * error and updates failproperty and/or failvariable if either
     * was requested.
     * @param caller the target caller that failed (non-null)
     * @param failure the barfage (non-null)
     * @param callers list of all targets being executed (non-null)
     **/
    protected void callerFailed(TargetCaller caller, Throwable failure,
                                List callers)
    {
        String targetName = callerName(caller);

        if (getMessageId()!=null) {
            log(getMsg(newMsgGetter(targetName)), Project.MSG_ERR);
        } else {
            log(uistrs().get("flow.runsteps.failure",getTaskName(),targetName),
                Project.MSG_ERR);
        }

        String what = getFailValue();

        if (getFailProperty()!=null) {
            checkIfProperty_(getFailProperty(),true);
            getProject().setNewProperty(getFailProperty(), what);
        }
        if (getFailVariable()!=null) {
            Variables.set(getFailVariable(), what, new Requester.ForComponent(this));
        }
    }


// ---------------------------------------------------------------------------------------
// Determining(sp?) Call Targets:
// ---------------------------------------------------------------------------------------


    /**
     * Returns <i>true</i> if the named Ant target exists within
     * this task's project. Does not work for macrodefs!
     * @param targetName the name of candidate project target (non-null)
     **/
    protected boolean targetExists(String targetName)
    {
        return getProject().getTargets().get(targetName)!=null;
    }


    /**
     * Returns a new list of all possible tasks-- not just steps. By
     * default returns task list of enclosing target. Never returns
     * <i>null</i>. Caller assumes ownership of returned array. Returned
     * list can include task placeholders (UnknownElements).
     **/
    protected Task[] getAllPossibleTasks()
    {
        return getOwningTarget().getTasks();
    }



    /**
     * Utility method to get a useful name for caller.
     * @param caller the caller in question (non-null)
     **/
    static final String callerName(TargetCaller caller)
    {
        String name = caller.getTargetName();
        if (name==null) {
            name = "n/d";
        }
        return name;
    }



    OverlayParametersHelper m_paramsHelper;//NB: lazy-inited
    private boolean m_haltIfError= true;  /* NB: unrolls and barfs by default */
    private boolean m_tryEach=false;      /* NB: abort if any task fails */
    private String  m_failProperty, m_failVariable;
    private String  m_failValue = Strings.TRUE;
}

/* end-of-CallerTask.java */
