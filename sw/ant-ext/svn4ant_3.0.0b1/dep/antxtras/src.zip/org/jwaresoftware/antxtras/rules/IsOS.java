/**
 * $Id: IsOS.java 1019 2010-03-13 16:13:19Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.taskdefs.condition.Condition;

import  org.jwaresoftware.antxtras.core.ProjectDependentSkeleton;
import  org.jwaresoftware.antxtras.go.IffOs;

/**
 * AntXtras shorthand for the standard <span class="src">&lt;os&gt;</span> 
 * condition that accepts our selector string format. Used to implement 
 * inlined 'os' parameters.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008,2010 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,helper
 **/

final class IsOS extends ProjectDependentSkeleton implements Condition
{
    IsOS(Project P)
    {
        setProject(P);
    }

    void setSelector(String selector)
    {
        m_selector = selector;
    }

    String getSelector()
    {
        return m_selector;
    }

    public boolean eval()
    {
        return IffOs.pass(getSelector(),getProjectNoNull(),false);
    }


    private String m_selector;
}

/* end-of-IsOS.java */
