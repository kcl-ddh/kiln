/**
 * $Id: AllSet.java 415 2008-04-22 02:08:37Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.condition;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.core.AntX;

/**
 * Shortcut condition that returns <i>true</i> if all of the nested items
 * (properties, variables, references, etc.) are set in the project's
 * environment. Can be setup to set a project property "<i>true</i>" on
 * <i>true</i> evaluation.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;assert msgid="msg.stuff.missing"&gt;
 *     &lt;<b>allset</b> whitespace="ignore"&gt;
 *       &lt;property  name="module.id/&gt;
 *       &lt;property  name="module.basedir/&gt;
 *       &lt;reference name="module.classpath/&gt;
 *     &lt;/allset&gt;
 *   &lt;/assert&gt;
 *
 *   &lt;fixturecheck msgid="msg.stuff.missing"&gt;
 *     &lt;<b>allset</b> malformed="reject"&gt;
 *       &lt;property name="module.id/&gt;
 *       &lt;properties prefix="mybuild." ignorecase="yes"/&gt;
 *     &lt;/allset&gt;
 *   &lt;/fixturecheck&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,infra
 * @see      IsNotSet
 * @see      NoneSet
 **/

public class AllSet extends CheckSetCondition implements URIable
{
    /**
     * Initializes new AllSet condition; defaults to returning <i>false</i>.
     **/
    public AllSet()
    {
        super(AntX.rules+"allset");
    }


    /**
     * Initializes new CV-labeled AllSet condition; defaults to
     * returning <i>false</i>.
     * @param iam CV-label (non-null)
     **/
    public AllSet(String iam)
    {
        super(iam);
    }


    /**
     * Initializes a CV-labeled filled in AllSet instance.
     * @param iam CV-label (non-null)
     * @param properties comma-delimited list of properties
     * @param P condition's project
     **/
    protected AllSet(String iam, String properties, final Project P)
    {
        super(iam);
        setProject(P);
        setProperties(properties);
    }


    /**
     * Initializes a filled in AllSet instance.
     * @param properties comma-delimited list of properties
     * @param P condition's project
     **/
    public AllSet(String properties, final Project P)
    {
        this(AntX.rules+"allset",properties,P);
    }



    /**
     * Sets this condition's list of properties as part of
     * a value URI.
     * @param fragment the value uri bits (non-null)
     * @since JWare/AntX 0.5
     */
    public void xsetFromURI(String fragment)
    {
        xsetFromURIFragment(fragment);
    }



    /**
     * Tells this set check to look for items with a positive
     * boolean string as a value.
     * @param allTrue <i>true</i> to force boolean check.
     * @since JWare/AntX 0.5
     **/
    public final void setAllTrue(boolean allTrue)
    {
        if (allTrue) {
            setTruesOnly();
        }
    }
}

/* end-of-AllSet.java */
