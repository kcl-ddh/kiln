/**
 * $Id: Conditional.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for a component that supports standard if/unless conditional
 * execution. A Conditional's execution is determined by the <em>combination</em>
 * of its <i>if</i>  and <i>unless</i> conditions.
 * <p>
 * <b>Examples:</b><pre>
 *      &lt;stop if="..." msgid="..."/&gt;
 *      &lt;show msgid="..." unless="..."/&gt;
 *      &lt;do iftrue="..." unless="..."&gt;...
 *      &lt;print if="..."&gt;...
 * </pre>
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 * @see      org.jwaresoftware.antxtras.go.Iff Iff
 * @see      org.jwaresoftware.antxtras.go.Unless Unless
 **/

public interface Conditional
{
    /**
     * Adds an if-condition to this component.
     **/
    void setIf(String property);


    /**
     * Returns this components's (raw) if-condition if any. Returns
     * empty string if condition never set.
     **/
    String getIfProperty();


    /**
     * Adds an unless-condition to this component.
     **/
    void setUnless(String property);


    /**
     * Returns this component's (raw) unless-condition if any.
     * Returns empty string if condition never set.
     **/
    String getUnlessProperty();
}

/* end-of-Conditional.java */
