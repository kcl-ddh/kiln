/**
 * $Id: IffAll.java 407 2008-04-19 16:52:08Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.go;

import  java.util.Iterator;
import  java.util.List;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Implementation of the general <i>ifAll</i> and <i>ifAllTrue</i> tests for all
 * conditional components. The <span class="src">IffAll</span> criteria passes if
 * all of the named properties in a list exist within a specified project.
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,helper
 * @.pattern GoF.Strategy
 * @see      Go
 * @see      Iff
 * @see      UnlessAll
 **/

public final class IffAll
{
    /**
     * Returns <i>true</i> if all of the named properties in given
     * list exist in project.
     * @param list comma-delimited list of property names
     * @param P project from which properties read
     * @param onlyIfTrue <i>true</i> if each property must also be
     *        a valid positive boolean string
     **/
    public static boolean pass(String list, Project P, boolean onlyIfTrue)
    {
        if (Tk.isWhitespace(list)) {
            return false;
        }
        list = Tk.resolveString(P,list);
        List l= Tk.splitList(list);
        Iterator itr= l.iterator();
        while (itr.hasNext()) {
            if (!Iff.allowed(itr.next().toString(),P,onlyIfTrue)) {
                return false;
            }
        }
        return true;
    }


    /**
     * Execute test for an "if-all" conditional parameter. Null
     * name lists are not allowed.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class Exists extends Go.TestSkeleton {
        public Exists() {
        }
        public Exists(String list) {
            super(list);
        }
        public boolean pass(Project P) {
            verifyInited();
            return IffAll.pass(getParameter(),P,false);
        }
        public String getParameterName() {
            return "ifAll";
        }
    }


    /**
     * Execute test for an "unless-all" conditional parameter.
     * Null name lists are not allowed.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     * @see      UnlessAll
     **/
    public static final class NotExists extends Go.TestSkeleton {
        public NotExists() {
        }
        public NotExists(String list) {
            super(list);
        }
        public boolean pass(Project P) {
            verifyInited();
            return UnlessAll.pass(getParameter(),P,false);
        }
        public String getParameterName() {
            return "unlessAll";
        }
    }


    /**
     * Execute test for an "if-all-true" conditional parameter.
     * Null name lists are not allowed.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsTrue extends Go.TestSkeleton {
        public IsTrue() {
        }
        public IsTrue(String list) {
            super(list);
        }
        public boolean pass(Project P) {
            verifyInited();
            return IffAll.pass(getParameter(),P,true);
        }
        public String getParameterName() {
            return "ifAllTrue";
        }
    }


    /**
     * Execute test for an "if-all-true" conditional parameter.
     * Null name lists are not allowed.
     * @since    JWare/AntX 0.4
     * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
     * @version  3.0.0b1
     * @.safety  single
     * @.group   impl,helper
     **/
    public static final class IsNotTrue extends Go.TestSkeleton {
        public IsNotTrue() {
        }
        public IsNotTrue(String list) {
            super(list);
        }
        public boolean pass(Project P) {
            verifyInited();
            return UnlessAll.pass(getParameter(),P,true);
        }
        public String getParameterName() {
            return "unlessAllTrue";
        }
    }


    /**
     * Prevent; only helpers public.
     **/
    private IffAll() {
    }
}

/* end-of-IffAll.java */
