/**
 * $Id: DefaultStringManager.java 618 2009-02-21 15:02:31Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.messages;

import  java.text.MessageFormat;

import  org.jwaresoftware.antxtras.core.UISMContext;
import  org.jwaresoftware.internal.apis.UIStringManager;

/**
 * UIStringManager that delegates all requests to the currently installed
 * AntXtras default context string manager (see {@linkplain UISMContext}}. 
 * Note that if the iteration's default string manager changes during 
 * this object's lifetime, it automatically starts to use that newer manager.
 *
 * @since     JWare/AntX 0.6
 * @author    ssmc, &copy;2005,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   special (as threadsafe as the underlying default string manager)
 * @.group    impl,helper
 * @.pattern  GoF.Adapter
 * @see       UISMContext
 **/

public final class DefaultStringManager implements UIStringManager
{
    /**
     * VM-shareable instance of a string manager for the
     * default. Note that this singleton acts as a envelope
     * to a potentially changing "real" fallback string manager. 
     */
    public static final DefaultStringManager INSTANCE=
        new DefaultStringManager();


    /**
     * Initializes a new default string redirector.
     **/
    public DefaultStringManager()
    {
        super();
    }



    public String mget(String arg0, Object[] arg1)
    {
        return UISMContext.getDefaultStringManager().mget(arg0,arg1);
    }



    public String mget(String arg0, Object[] arg1, String arg2)
    {
        return UISMContext.getDefaultStringManager().mget(arg0,arg1,arg2);
    }



    public String mget(MessageFormat arg0, String arg1, Object[] arg2, String arg3)
    {
        return UISMContext.getDefaultStringManager().mget(arg0,arg1,arg2,arg3);
    }



    public String get(String arg0)
    {
        return UISMContext.getDefaultStringManager().get(arg0);
    }



    public String dget(String arg0, String arg1)
    {
        return UISMContext.getDefaultStringManager().dget(arg0,arg1);
    }



    public String get(String arg0, Object arg1)
    {
        return UISMContext.getDefaultStringManager().get(arg0,arg1);
    }



    public String dget(String arg0, Object arg1, String arg2)
    {
        return UISMContext.getDefaultStringManager().dget(arg0,arg1,arg2);
    }



    public String get(String arg0, Object arg1, Object arg2)
    {
        return UISMContext.getDefaultStringManager().get(arg0,arg1,arg2);
    }



    public String dget(String arg0, Object arg1, Object arg2, String arg3)
    {
        return UISMContext.getDefaultStringManager().dget(arg0,arg1,arg2,arg3);
    }



    public String get(String arg0, Object arg1, Object arg2, Object arg3)
    {
        return UISMContext.getDefaultStringManager().get(arg0,arg1,arg2,arg3);
    }



    public String dget(String arg0, Object arg1, Object arg2, Object arg3, String arg4)
    {
        return UISMContext.getDefaultStringManager().dget(arg0,arg1,arg2,arg3,arg4);
    }



    public String getDefaultString()
    {
        return UISMContext.getDefaultStringManager().getDefaultString();
    }

}

/* end-of-DefaultStringManager.java */
