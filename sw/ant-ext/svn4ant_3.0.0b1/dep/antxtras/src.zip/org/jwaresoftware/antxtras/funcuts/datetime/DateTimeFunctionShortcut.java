/**
 * $Id: DateTimeFunctionShortcut.java 857 2009-11-15 17:35:56Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.funcuts.datetime;

import  java.text.Format;
import  java.text.SimpleDateFormat;
import  java.util.Map;

import  org.apache.tools.ant.Project;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.AntXFixture;
import  org.jwaresoftware.antxtras.core.FunctionShortcut;
import  org.jwaresoftware.antxtras.helpers.DateTimeFormat;
import  org.jwaresoftware.antxtras.helpers.DurationFormat;
import  org.jwaresoftware.antxtras.helpers.Tk;

/**
 * Function shortcut that converts simple datetime queries into formatted
 * date and time strings. In addition to the final datetime string format
 * (reflected in shortcut's name), you must specify the timestamp in one
 * of three ways: use the '$now:' shortcut, use the string "now" for the
 * timestamp passed into function, use the piped result of another function
 * shortcut, or declare the timestamp number value itself as a string.
 * <p/>
 * To specify a custom format string use the function shortcut's fragment 
 * bits after the "&#63;" like: <span class="src">${$PS:now?'['h:mm:ss']$ '}</span>.
 * <p/>
 * <b>Example Usage:</b><pre>
 *  1) &lt;echo message="Now in milliseconds: ${<b>$now:</b>}"/&gt;
 *     &lt;echo message="Current GMT datetime is: ${<b>$gmtdatetime:now</b>}"/&gt;
 *     &lt;echo message="Current ISO datetime is: ${<b>$isodatetime:now</b>}"/&gt;
 *
 *  2) &lt;echo message="My time prompt: ${<b>$now:'['h:mm:ss']: '</b>}"/&gt;
 *
 *  3) &lt;assign var="starttime" op="now"/&gt;
 *     &lt;show messageid="start.work.at" arg0="${$var:starttime|<b>$datetime:</b>}"/&gt;
 *     <i>[...work work work...]</i>
 *     &lt;show messageid="ended.work.at" arg0="${<b>$datetime:</b>}"/&gt;
 *
 *  4) &lt;assign var="timing" op="now"/&gt;
 *     <i>[...work work work...]</i>
 *     &lt;assign var="timing" op="-now"/&gt;
 *     &lt;echo message="It Took: ${$var:timing|<b>$duration:</b>}"/&gt;
 *
 *   -- To Install and Enable --
 *    &lt;managefuncuts action="enable"&gt;
 *       &lt;parameter name="datetime"
 *             value="${ojaf}.datetime.DateTimeFunctionShortcut"/&gt;
 *       &lt;parameter name="shortdatetime"
 *             value="${ojaf}.datetime.DateTimeFunctionShortcut"/&gt;
 *       ...<i>[All other standard names and your own custom ones if desired]</i>
 *    &lt;/managefuncuts&gt;
 * </pre>
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2007-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @see       NowFunctionShortcut
 * @.safety   multiple
 * @.group    api,helper
 * @.caveat   You must use one of the expected scheme names to get the default
 *            formats; otherwise you must manually map your scheme name to this
 *            handler and <em>always</em> provide a format string.
 **/

public final class DateTimeFunctionShortcut implements FunctionShortcut
{
    private static final Map LINKS = AntXFixture.newMap();
    static {
        //NB: long-winded and uglee but obvious. Also not
        //    likely to grow dramatically...[expanded for 2.0.0]
        LINKS.put("$longdatetime:",DateTimeFormat.STANDARD);
        LINKS.put("$longtime:",DateTimeFormat.STANDARD_TIME);
        LINKS.put("$longdate:",DateTimeFormat.STANDARD_DATE);
        LINKS.put("$longdatetimestrict:", DateTimeFormat.STANDARD_STRICT);
        LINKS.put("$gmt:",DateTimeFormat.GMT);
        LINKS.put("$gmtdatetime:",DateTimeFormat.GMT);
        LINKS.put("$gmtdate:",DateTimeFormat.GMT_DATE);
        LINKS.put("$gmttime:",DateTimeFormat.GMT_TIME);
        LINKS.put("$shortdatetime:",DateTimeFormat.ABBREV);
        LINKS.put("$shorttime:",DateTimeFormat.ABBREV_TIME);
        LINKS.put("$shortdate:",DateTimeFormat.ABBREV_DATE);
        LINKS.put("$shortdatetimestrict:", DateTimeFormat.ABBREV_STRICT);
        LINKS.put("$datetime:",DateTimeFormat.STANDARD);
        LINKS.put("$time:",DateTimeFormat.STANDARD_TIME);
        LINKS.put("$date:",DateTimeFormat.STANDARD_DATE);
        LINKS.put("$datetimestrict:",DateTimeFormat.STANDARD_STRICT);
        LINKS.put("$timestrict:",DateTimeFormat.STANDARD_TIME_STRICT);
        LINKS.put("$duration:",DurationFormat.INSTANCE);
        LINKS.put("$changelogdate:",DateTimeFormat.CHANGELOG);
        LINKS.put("$cvsdate:",DateTimeFormat.CHANGELOG);
        LINKS.put("$svndate:",DateTimeFormat.SVNLOG);
        LINKS.put("$iso:",DateTimeFormat.ISO_STRICT);
        LINKS.put("$isodatetime:",DateTimeFormat.ISO_STRICT);
        LINKS.put("$isotime:", DateTimeFormat.ISO_TIME_STRICT);
        LINKS.put("$isodate:", DateTimeFormat.ISO_DATE_STRICT);
        LINKS.put("$longiso:",DateTimeFormat.ISO);
        LINKS.put("$longisodatetime:",DateTimeFormat.ISO);
        LINKS.put("$isomillis:",DateTimeFormat.ISO_MILLIS_STRICT);
    }



    /**
     * Initializes a new datetime funcut handler.
     **/
    public DateTimeFunctionShortcut()
    {
    }



    /**
     * Returns the best fit formatter for the format directive
     * embedded in a given date value uri.
     * @param fullUri the full uri (including the '$protocol:' prefix)
     * @param clnt problem handler (non-null)
     * @return the formatter or <i>null</i> if no match found.
     **/
    public static Format defaultFormatter(String fullUri, Requester clnt)
    {
        Format dfmt= null;
        int i= fullUri.indexOf(':');
        if (i>0) {
            String which= fullUri.substring(0,++i);
            dfmt = (Format)LINKS.get(which);
            if (dfmt==null && (i=fullUri.indexOf("?",i))>0) {
                i++;
                if (i<fullUri.length()-1) {
                    String fmtstr = fullUri.substring(i);
                    fmtstr = Tk.resolveString(clnt.getProject(),fmtstr,true);
                    try {
                        dfmt = new SimpleDateFormat(fmtstr);
                    } catch(IllegalArgumentException mfX) {
                        clnt.problem(mfX.getMessage(),Project.MSG_WARN);
                    }
                }
            }
        }
        return dfmt;
    }



    /**
     * Returns a snapshot of the current set of uri scheme name to
     * format mappings. Never returns <i>null</i>. The returned map
     * is disassociated from this class; modifications to it are not
     * reflected back to this class.
     * @.impl Used for testing this class.
     **/
    public static Map copyOfMappings()
    {
        synchronized(LINKS) {
            return AntXFixture.newMapCopy(LINKS);
        }
    }



    /**
     * Tries to determine if the named scheme is a timestamp based
     * format or a duration format. Duration formats expect delta
     * for the timestamp parameter; timestamp format expect well
     * timestamps.
     * @param scheme name of uri scheme
     * @return Boolean.TRUE or Boolean.FALSE if can determine one
     *        way or other from name; otherwise returns <i>null</i>.
     **/
    public static Boolean isTimestampScheme(String scheme)
    {
        Boolean yes = null;
        if (scheme!=null) {
            scheme = Tk.lowercaseFrom(scheme);
            if (scheme.indexOf("date")>=0 || scheme.indexOf("time")>=0) {
                yes = Boolean.TRUE;
            } else if (scheme.indexOf("iso")>=0) {
                yes = Boolean.TRUE;
            } else if (scheme.indexOf("gmt")>=0) {
                yes = Boolean.TRUE;
            } else if (scheme.indexOf("duration")>=0) {
                yes = Boolean.FALSE;
            }
        }
        return yes;
    }



    /**
     * Utility to format the given timestamp according a date value
     * URI format directive.
     * @param time the timestamp to use
     * @param fullUri the format informaton uri (non-null)
     * @param clnt problem handler (non-null)
     * @return formatted string or <i>null</i> if no formatter
     *      match found.
     **/
    public String format(long time, String fullUri, Requester clnt)
    {
        Format dfmt= defaultFormatter(fullUri,clnt);
        if (dfmt!=null) {
            return DateTimeFormat.format(time,dfmt);
        }
        return null;
    }



    /**
     * Returns a formatted datetime string for "now" URI. Any
     * other timestamp returns <i>null</i>.
     **/
    public String getDefaultValue(String fullUri, Requester clnt)
    {
        final long NOW = now();
        if (fullUri.endsWith(":now")) {
            return format(NOW,fullUri,clnt);
        }
        if (fullUri.indexOf(":now?")>1) {
            return format(NOW,fullUri,clnt);
        }
        return null;
    }



    /**
     * The uri fragment can be one of three things: either the string
     * "now" for the current system time, or a <em>single</em> redirect
     * to a reference or variable that contains the timestamp, or the
     * timestamp value itself as a string.
     **/
    public String valueFrom(String uriFragment, String fullUri, Requester clnt)
    {
        String timestring = uriFragment;
        int i = uriFragment.indexOf('?');
        if (i>=0) {
            timestring = uriFragment.substring(0,i++);
        }
        timestring = Tk.resolveString(clnt.getProject(),timestring,true);

        if (timestring.length()==0 || "now".equals(timestring)) {
            return format(now(),fullUri,clnt);
        }

        long timestamp = Tk.longFrom(timestring,-1L);
        if (timestamp>0L) {
            return format(timestamp,fullUri,clnt);
        }

        return null;
    }


    /**
     * Tells this handler what "now" means. Never used from live uri
     * handling mechanism; only for testing and stubs.
     * @param timestamp the required value of "now" (>=0L)
     * @.impl Used for testing this class.
     **/
    public void setNow(long timestamp)
    {
        AntX.require_(timestamp>=0L,AntX.utilities+"DateTimeFunctionShortcut:",
                      "setnow- valid timstamp");
        m_nowTS = timestamp;
    }


    private long now()
    {
        return m_nowTS<0L ? System.currentTimeMillis() : m_nowTS;
    }


    private long m_nowTS = -1L;
}

/* end-of-DateTimeFunctionShortcut.java */