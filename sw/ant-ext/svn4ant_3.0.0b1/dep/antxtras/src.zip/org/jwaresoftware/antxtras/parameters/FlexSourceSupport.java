/**
 * $Id: FlexSourceSupport.java 392 2008-03-30 21:09:58Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.parameters;

/**
 * Mixin interface for a component that supports setters/getters for
 * the common kinds of data sources: files, resources, urls.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  n/a
 * @.group   api,infra
 * @.impl    All inputs are simple strings to support locations that are relative
 *           to something other than the project. Gives implementors a chance to
 *           implement differently.
 **/

public interface FlexSourceSupport
{
    /**
     * Sets this item's data source location as a URL.
     * @param urlstr URL string representation (non-null)
     **/
    void setURL(String urlstr);


    /**
     * Sets this item's data source location as a file.
     * @param filepath the readable file's path (non-null)
     **/
    void setFile(String filepath);


    /**
     * Sets this item's data source location as a classpath-based
     * resource name.
     **/
    void setResource(String rsrc);
}

/* end-of-FlexSourceSupport.java */
