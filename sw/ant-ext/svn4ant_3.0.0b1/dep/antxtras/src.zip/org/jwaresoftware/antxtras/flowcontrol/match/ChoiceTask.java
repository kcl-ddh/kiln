/**
 * $Id: ChoiceTask.java 697 2009-03-07 19:51:29Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.flowcontrol.match;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.Task;
import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.antxtras.helpers.TaskHandle;
import  org.jwaresoftware.antxtras.parameters.FlexValueSupport;
import  org.jwaresoftware.antxtras.starters.Quiet;
import  org.jwaresoftware.antxtras.starters.StrictInnerTaskSet;

/**
 * Required superclass for any nested choice selector task. This class defines
 * the required evaluation and filtering methods for all choice task sets.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,infra
 * @see      DoMatchTaskSet
 **/

public abstract class ChoiceTask extends StrictInnerTaskSet
    implements Quiet, FlexValueSupport
{
    /**
     * Initializes new choice task.
     **/
    protected ChoiceTask(String iam)
    {
        super(iam);
    }



    /**
     * Initializes new choice task with custom delay configuration.
     * @param iam CV-label
     * @param delayConfiguration <i>true</i> if delay nested task configuration
     **/
    protected ChoiceTask(String iam, boolean delayConfiguration)
    {
        super(iam,delayConfiguration);
    }



    /**
     * Returns this choice's underlying match value (as-is).
     * @since JWare/AntX 0.2
     **/
    public abstract String getFlexValue();



    /**
     * Returns <i>true</i> if this choice has not been defined properly.
     **/
    public abstract boolean isUndefined();



    /**
     * Returns the actual value used in this choice's comparision. Returns
     * <i>null</i> if value never defined or determined value doesn't
     * exist; for example, if the named reference doesn't exist in project.
     **/
    public abstract String getVUT();



    /**
     * Returns <i>true</i> if task is not another choice task
     * definition. Cannot nest choices directly into one another.
     **/
    protected boolean includeTask(TaskHandle taskH)
    {
        Task task = candidateTask(taskH,COI_);
        return (task!=null) && !(task instanceof ChoiceTask);
    }



    /**
     * Evaluates this choice's condition for a hit. Returns
     * <i>true</i> if this choice's criteria are met by the incoming
     * value under consideration.
     * @param vut value under test (vut-vut)
     * @param context [optional] evaluation context
     * @throws BuildException if this task isn't nested properly
     **/
    public abstract boolean eval(String vut, Reference context)
        throws BuildException;



    /**
     * Ensure this choice has had its match value assigned and exists
     * within a valid block task.
     **/
    protected void verifyCanExecute_(String calr)
    {
        super.verifyCanExecute_(calr);

        if (isUndefined()) {
            String ermsg = uistrs().get("flow.switch.needs.value",getTaskName());
            log(ermsg, Project.MSG_ERR);
            throw new BuildException(ermsg,getLocation());
        }
    }



    /**
     * Controls the amount of peek-under for UnknownElement placeholders
     * nested inside task containers.
     * @since JWare/AntX 0.4
     **/
    private static final Class[] COI_= {
        ChoiceTask.class
    };
}

/* end-of-ChoiceTask.java */
