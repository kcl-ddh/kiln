/**
 * $Id: LogInterpreter.java 1007 2010-03-11 13:23:42Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.interpret;

import  java.io.Reader;

import  org.apache.tools.ant.BuildException;

/**
 * Strategy interface for a utility that interprets a particular Ant tool's logged
 * feedback to determine whether the tools succeeded or not (and to what degree).
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   n/a
 * @.group    impl,helper
 * @.pattern  GoF.Strategy
 * @see       InterpretLoggedTask
 **/

public interface LogInterpreter
{
    /** Symbolic value returned if no problems are detected in log stream. **/
    public static final String CLEAN   = "CLEAN";

    /** Symbolic value returned if at least one problem is detected in log stream. **/
    public static final String PROBLEM = "PROBLEM";

    /** Symbolic value returned if too many problems are detected in log stream. **/
    public static final String FAILURE = "FAILURE";


    /**
     * Do whatever is necessary to interpret an Ant tool's logged output as either
     * clean, problematic, or a total failure.
     * @param inputr logged information (a log file, a log stream, etc&#46;)
     * @param clnt calling context (non-null)
     * @return the interpretation as a simple clean,problem,failure flag. See
     *          {@linkplain #CLEAN}, {@linkplain #PROBLEM}, and {@linkplain #FAILURE}.
     * @throws BuildException if unable to read logged information.
     **/
    String interpret(Reader inputr, InterpretParameters clnt)
        throws BuildException;
}

/* end-of-ToolLogInterpreter.java */