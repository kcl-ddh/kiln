/**
 * $Id: RulesTk.java 578 2009-02-01 02:23:11Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.rules;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.Project;
import  org.apache.tools.ant.TaskAdapter;
import  org.apache.tools.ant.taskdefs.condition.Condition;

import  org.jwaresoftware.antxtras.behaviors.Requester;
import  org.jwaresoftware.antxtras.core.Iteration;
import  org.jwaresoftware.antxtras.helpers.Strings;

/**
 * Collection of rule evaluation related utility methods.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2004-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version   3.0.0b1
 * @.safety   multiple
 * @.group    impl,helper
 **/

public final class RulesTk
{
    private RulesTk()
    {
        //only utility methods from us!
    }


    /**
     * Returns <i>true</i> if the named condition evaluates true.
     * Uses the standard condition value URI handler to do the
     * heavy lifting.
     * @param clnt caller (non-null)
     * @param testId reference of condition to evaluate (non-null)
     * @return <i>true</i> if evaluated true.
     * @since JWare/AntX 0.5
     **/
    public static boolean evalTest(String testId, Requester clnt)
    {
        RuleFunctionShortcut runner = new RuleFunctionShortcut();
        String result = runner.valueFrom(testId,"$test:"+testId, clnt);
        return Strings.TRUE.equals(result);
    }



    /**
     * Check that the given reference points to a condition-like
     * object.
     * @param refid the referenced object (non-null)
     * @param clnt error handler (non-null)
     * @throws IllegalArgumentException if either parameter is <i>null</i>.
     * @throws BuildException if the referred-to thing does not
     *      exist or is of an incompatible class.
     * @since JWare/AntX 0.5
     **/
    public static void verifyTest(String refid, Requester clnt)
    {
        if (refid==null || clnt==null) {
            throw new IllegalArgumentException();
        }
        String error = null;
        Object ref = clnt.getProject().getReference(refid);
        if (ref==null) {
            error = Iteration.uistrs().get("task.missing.refid",refid);
        } else {
            if (ref instanceof TaskAdapter) {
                ref = ((TaskAdapter)ref).getProxy();
            }
            if (!(ref instanceof Condition) && !(ref instanceof ShareableCondition)) {
                error = Iteration.uistrs().get("task.bad.refid",refid,
                    Condition.class.getName(), ref.getClass().getName());
            }
        }

        if (error!=null) {
            clnt.problem(error, Project.MSG_ERR);
            throw new BuildException(error, clnt.getLocation());
        }
    }
}

/* end-of-RulesTk.java */