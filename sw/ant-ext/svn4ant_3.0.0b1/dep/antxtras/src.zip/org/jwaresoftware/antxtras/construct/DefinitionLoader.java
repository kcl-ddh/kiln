/**
 * $Id: DefinitionLoader.java 421 2008-04-26 23:40:44Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.construct;

import  org.apache.tools.ant.taskdefs.AntlibDefinition;

import  org.jwaresoftware.antxtras.core.AntX;

/**
 * Default implementation of a ClassLoader factory method for AntXtras
 * Antlib definitions. We assume that AntXtras definitions do not load
 * tasks or types directly (only resources).
 *
 * @since    JWare/AntX 0.4
 * @author   ssmc, &copy;2004,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   impl,infra
 **/

public final class DefinitionLoader implements CustomLoaderFactoryMethod
{
    private static final String IAM_= "DefinitionLoader:";


    /**
     * Initializes this adapter for an existing definition.
     * @param defn existing Antlib definition (non-null)
     **/
    public DefinitionLoader(AntlibDefinition defn)
    {
        AntX.require_(defn!=null,IAM_,"ctor- nonzro definition");
        m_def= defn;
        m_spi= null;
    }



    /**
     * Initializes this adapter for an existing definition that also
     * supports instance-level customization.
     * @param defn existing Antlib definition (non-null)
     * @param next next loader after definitions (non-null)
     **/
    public DefinitionLoader(AntlibDefinition defn, CustomLoaderFactoryMethod next)
    {
        AntX.require_(defn!=null,IAM_,"ctor- nonzro definition");
        AntX.require_(next!=null,IAM_,"ctor- nonzro delegate");
        m_def= defn;
        m_spi= next;
    }



    /**
     * Returns the underlying definitions class loader. Can return
     * <i>null</i>.
     * @.safety single
     **/
    public ClassLoader getClassLoader()
    {
        if (m_cL==null) {
            ClassLoader cL= m_def.getAntlibClassLoader();
            if (cL==null && m_spi!=null) {
                cL = m_spi.getClassLoader();
            }
            m_cL = cL;
        }
        return m_cL;
    }


    private ClassLoader m_cL;//cached
    private final AntlibDefinition m_def;//NB:required
    private final CustomLoaderFactoryMethod m_spi;//NB:optional
}

/* end-of-DefinitionLoader.java */
