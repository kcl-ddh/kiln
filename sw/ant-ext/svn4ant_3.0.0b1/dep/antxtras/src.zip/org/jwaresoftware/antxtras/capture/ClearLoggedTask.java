/**
 * $Id: ClearLoggedTask.java 1007 2010-03-11 13:23:42Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.capture;

import  org.jwaresoftware.antxtras.core.AntX;

/**
 * Helper task the clears the nearest {@linkplain LogsRecorder}. This task
 * is most often used to reset a top-level
 * &lt;{@linkplain CaptureStreamsTask captureoutput}&gt;
 * so that the next &lt;copylogged&gt; captures a scoped subset of all generated output.
 * <p>
 * <b>Example Usage:</b><pre>
 *   &lt;captureoutput&gt;
 *      &lt;...<i>Some Tasks Here</i>&gt;
 *      &lt;copylogged from="stdio" important="no" tofile="..."/&gt;
 *      &lt;...<i>More Tasks Here</i>&gt;
 *      &lt;<b>clearlogged</b>/&gt;
 *      &lt;...<i>More Tasks Here</i>&gt;
 *      &lt;copylogged from="stdio" toproperty="..."/&gt;
 *   &lt;/captureoutput&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.3
 * @author   ssmc, &copy;2003-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  guarded
 * @.group   api,helper
 * @see      CaptureLogsTask
 * @see      CaptureStreamsTask
 **/

public final class ClearLoggedTask extends LogsUsingTask
{
    /**
     * Initializes a new ClearLoggedTask instance.
     **/
    public ClearLoggedTask()
    {
        this(AntX.capture+"ClearLoggedTask:");
    }


    /**
     * Initializes a CV-labeled ClearLoggedTask instance.
     * @param iam CV-label (non-null)
     **/
    public ClearLoggedTask(String iam)
    {
        super(iam);
        setReset(true);
        setImportant(false);
    }


    /**
     * Clears the current thread's nearest logs recorder (if one
     * is installed). Does nothing if there is no recorder.
     **/
    public void execute()
    {
        LogsRecorder r = getRecorder(true);
        if (r!=null) {
            r.clearLogs();
        }
    }
}

/* end-of-ClearLoggedTask.java */
