/**
 * $Id: MkTempFile.java 428 2008-04-27 13:12:32Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.filesystem;

import  java.io.File;

import  org.apache.tools.ant.BuildException;
import  org.apache.tools.ant.types.PropertySet;
import  org.apache.tools.ant.types.Reference;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.helpers.InnerString;
import  org.jwaresoftware.antxtras.starters.StringItemListHandle;

/**
 * Task that creates temporary files. Note temporary files <em>are</em>
 * marked for automatic deletion when the VM exits. Unlike the
 * builtin Ant '<i>tempfile</i>' task, this command produces a real 
 * file-system entity. Prototype lines (as specified with the &lt;line&gt; 
 * or &lt;lines&gt; elements) are only applied to new empty files. If a
 * prototype copy file (or resource) has been defined, these lines are
 * <em>not</em> included to the new file.
 * <p/>
 * <b> Example Usage:</b><pre>
 *   &lt;<b>newtempfile</b> prefix="tst-" copyresource="/testfiles/broken-build.xml"
 *                pathproperty="bad.buildxml"/&gt;
 *
 *   &lt;<b>newtempfile</b> prefix="vrz-" suffix=".sql" copyresource="getrev.sql"
 *                pathproperty="getrev.file"&gt;
 *      &lt;filterset refid="rev.sql.copyfilters"/&gt;
 *   &lt;/newtempfile&gt;
 *
 *   &lt;<b>newtempfile</b> pathproperty="test.file"&gt;
 *      &lt;line value="hello"/&gt;
 *      &lt;line value="there"/&gt;
 *      &lt;line value="world"/&gt;
 *   &lt;/newtempfile&gt;
 * </pre>
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2005,2008 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  single
 * @.group   api,helper
 **/

public final class MkTempFile extends MkTempObject
{
    /**
     * Create a new mktempfile task.
     **/
    public MkTempFile()
    {
        super(AntX.filesystem+"MkTempFile:");
    }


    /**
     * Adds a new prototype line to include in new file.
     * @param line the line information (non-null)
     * @since JWare/AntX 0.3
     **/
    public void addLine(InnerString line)
    {
        require_(line!=null,"addLn- nonzro ln");
        getPrototypeLinesNoNull().add(line);
    }


    /**
     * Adds a reference to prototype lines to include in new file.
     * @param lines the line information (non-null)
     * @since JWare/AntX 0.3
     **/
    public void addLines(StringItemListHandle lines)
    {
        require_(lines!=null,"addLns- nonzro lns");
        getPrototypeLinesNoNull().add(lines);
    }


    /**
     * Shortcut for {@linkplain #addLines addLines()}. The
     * refered-to list is <em>added</em> to this task's prototype
     * lines.
     * @param ref the itemlist's reference (non-null)
     * @since JWare/AntX 0.3
     **/
    public final void setLines(Reference ref)
    {
        StringItemListHandle lines = new StringItemListHandle(ref);
        getPrototypeLinesNoNull().add(lines);
    }


    /**
     * Adds a new property set to include in new temporary file.
     * @param propertyset new propertyset line (non-null)
     * @since JWare/AntX 0.4
     **/
    public void addConfiguredPropertySet(PropertySet propertyset)
    {
        require_(propertyset!=null,"addPropSet- nonzro pset");
        getPrototypeLinesNoNull().add(propertyset);
    }


    /**
     * Creates a new temporary file. If executed multiple times, will not
     * produce the same named file within a single VM instance. If either a prototype
     * source or  prototype lines were defined, the new file's contents will
     * match the prototype information.
     **/
    public void execute() throws BuildException
    {
        verifyInProject_("exec");

        File newFile = createFile(getInDir());

        saveFinalPath(newFile,true);
    }
}

/* end-of-MkTempFile.java */
