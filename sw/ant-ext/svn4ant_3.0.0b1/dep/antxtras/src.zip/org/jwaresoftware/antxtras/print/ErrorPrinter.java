/**
 * $Id: ErrorPrinter.java 697 2009-03-07 19:51:29Z ssmc $
 * Copyright (c) 2002-2010 Sandbox Software MC. All Rights Reserved.
 *
 * Originally written by Sandbox Software MC (SSMC) for release into the public domain. 
 * This library, source form and binary form, is free software; you can redistribute it 
 * and/or modify it under the terms of the GNU Lesser General Public License (LGPL) as 
 * published by the Free Software Foundation; version 2.1 of the License.
 *
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://antxtras.sf.net/          EMAIL- antxtras[@]users[.]sf[.]net
 *----------------------------------------------------------------------------------------*
 **/

package org.jwaresoftware.antxtras.print;

import  java.io.IOException;
import  java.io.OutputStream;
import  java.io.PrintStream;
import  java.util.List;
import  java.util.Properties;

import  org.jwaresoftware.antxtras.core.AntX;
import  org.jwaresoftware.antxtras.core.ErrorSnapshot;
import  org.jwaresoftware.antxtras.helpers.Strings;
import  org.jwaresoftware.antxtras.helpers.Tk;
import  org.jwaresoftware.internal.apis.UIStringManager;

/**
 * Default strategy for printing an {@linkplain ErrorSnapshot ErrorSnapshot}
 * or a Throwable to an output stream. Basically dumps a big ol' Properties
 * object containing all snapshot's information as fields.
 *
 * @since    JWare/AntX 0.2
 * @author   ssmc, &copy;2002-2003,2008-2009 <a href="http://antxtras.sf.net/">SSMC</a>
 * @version  3.0.0b1
 * @.safety  multiple
 * @.group   impl,helper
 * @see      PrintErrorTask
 **/

public final class ErrorPrinter implements DisplayStrategy
{
    /**
     * Initializes a new ErrorPrinter.
     **/
    public ErrorPrinter()
    {
    }


    /**
     * Prints out an error snapshot's header fields.
     * @param id the display name of the request (non-null)
     * @param es the error snapshot (non-null)
     * @param out the print stream to use (non-null)
     **/
    private void printHeader(String id, ErrorSnapshot es, PrintStream out)
    {
        /** Include Header information as Property=Value entries **/
        Object thrown = es.getThrown();
        if (thrown==null) { thrown = ""; }
        PropertiesPrinter.header(uistrs().get("snapshot.print.thrown",id),thrown,out);
        PropertiesPrinter.header(uistrs().get("snapshot.print.location",id),es.getLocation(),out);
        PropertiesPrinter.header(uistrs().get("snapshot.print.task",id),es.getTaskName(),out);
        PropertiesPrinter.header(uistrs().get("snapshot.print.target",id),es.getTargetName(),out);
        PropertiesPrinter.header(uistrs().get("snapshot.print.comment",id),es.getComment(),out);
    }


    /**
     * Produces the appropriate set of captured properties. Will return
     * <i>null</i> if no properties requested.
     * @param id the display name of the request (non-null)
     * @param es the error snapshot (non-null)
     * @param list list of properties to display (non-null)
     * @param out the print stream to use (non-null)
     **/
    private void printEnv(String id, ErrorSnapshot es, String list, PrintStream out)
    {
        String ll= Tk.lowercaseFrom(list);
        if (ll.length()==0 || Strings.NONE.equals(ll)) {
            return;
        }

        /** Start with the entire universe captured by the snapshot **/
        Properties allP = es.copyOfProperties();

        /** Filter to only the properties requested (can be all) **/
        if (!Strings.ALL.equals(ll)) {
            List wanted = Tk.splitList(list,",");
            allP.keySet().retainAll(wanted);

            if (wanted.size()>allP.size()) {//insert "null" strings
                for (int i=0,N=wanted.size();i<N;i++) {
                    String key = (String)wanted.get(i);
                    if (allP.getProperty(key)==null) {
                        allP.setProperty(key,Strings.NULL);
                    }
                }
            }
            wanted=null;
        }

        PropertiesPrinter.print(allP, out);
    }


    /**
     * Generates an ErrorSnapshot as a big ol' Properties listing
     * to the given output stream.
     * @param info display information (non-null)
     * @param os the output stream (non-null)
     * @throws IOException if any I/O error occurs
     **/
    public void print(final DisplayRequest info, OutputStream os)
        throws IOException
    {
        Object target = info.getObjectToBeDisplayed();

        /** Ignore nulls (do nada), only do ErrorSnapshots **/
        if (target instanceof ErrorSnapshot) {

            ErrorSnapshot es = (ErrorSnapshot)target;
            String id = info.getName();
            if (id==null) {
                id = es.getName();
                if (id==null) {
                    id = Strings.NULL;
                }
            }

            /** Always ensure header information is first. **/
            PrintStream ps = new PrintStream(os);
            ps.println("########");
            printHeader(id,es,ps);
            ps.println("########");

            /** Write the requested environment stuff next. **/
            String list = info.getFilter();
            if (list==null) {
                list = Strings.ALL;
            }
            printEnv(id,es,list,ps);
        }
        /** Ignore nulls (do nada), only do Throwables **/
        else if (target instanceof Throwable ) {

            Throwable thrown = (Throwable)target;
            PrintStream ps = new PrintStream(os);

            ps.println("########");
            ps.print("#");
            ps.println(uistrs().get("thrown.print.header",Tk.leafNameFrom(thrown.getClass())));
            ps.print("#");
            ps.println(new java.util.Date());
            thrown.printStackTrace(ps);
            ps.flush();
            ps=null;
        }
    }


    private UIStringManager uistrs()
    {
        return AntX.uistrs();
    }
}

/* end-of-ErrorPrinter.java */
